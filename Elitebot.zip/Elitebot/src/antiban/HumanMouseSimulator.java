package antiban;

import org.dreambot.api.input.Mouse;
import org.dreambot.api.utilities.Logger;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class HumanMouseSimulator {
    
    private final Random random = ThreadLocalRandom.current();
    
    // Mouse movement characteristics
    private final double mouseSpeed;
    private final double precision;
    private final double jitterFactor;
    private final double accelerationFactor;
    
    // Movement history
    private final List<Point> movementHistory = new ArrayList<>();
    private final Queue<MouseEvent> recentMovements = new LinkedList<>();
    private Point lastPosition;
    private long lastMovementTime;
    
    // Human-like movement patterns
    private final Map<String, Double> movementPatterns = new HashMap<>();
    private final List<Double> speedVariations = new ArrayList<>();
    
    private final MouseHeatmap mouseHeatmap;
    
    public HumanMouseSimulator(MouseHeatmap mouseHeatmap) {
        this.mouseHeatmap = mouseHeatmap;
        
        // Initialize mouse characteristics
        this.mouseSpeed = 0.6 + random.nextDouble() * 0.4; // 0.6 - 1.0
        this.precision = 0.7 + random.nextDouble() * 0.3; // 0.7 - 1.0
        this.jitterFactor = 0.02 + random.nextDouble() * 0.08; // 0.02 - 0.1
        this.accelerationFactor = 0.8 + random.nextDouble() * 0.2; // 0.8 - 1.0
        
        initializeMovementPatterns();
        Logger.log("Human mouse simulator initialized with speed: " + mouseSpeed + ", precision: " + precision);
    }
    
    private void initializeMovementPatterns() {
        // Initialize movement patterns
        movementPatterns.put("straight_line_preference", 0.3 + random.nextDouble() * 0.4);
        movementPatterns.put("curve_preference", 0.2 + random.nextDouble() * 0.6);
        movementPatterns.put("overshoot_tendency", 0.1 + random.nextDouble() * 0.3);
        movementPatterns.put("correction_frequency", 0.05 + random.nextDouble() * 0.15);
        movementPatterns.put("pause_frequency", 0.02 + random.nextDouble() * 0.08);
        
        // Initialize speed variations
        for (int i = 0; i < 100; i++) {
            speedVariations.add(0.8 + random.nextDouble() * 0.4); // 0.8 - 1.2
        }
    }
    
    public List<Point> generateHumanTrajectory(Point start, Point end) {
        List<Point> trajectory = new ArrayList<>();
        
        // Calculate distance and direction
        double distance = start.distance(end);
        double angle = Math.atan2(end.y - start.y, end.x - start.x);
        
        // Determine movement type based on distance
        if (distance < 10) {
            // Short distance - direct movement with micro-adjustments
            trajectory = generateDirectTrajectory(start, end);
        } else if (distance < 50) {
            // Medium distance - slight curve with natural acceleration
            trajectory = generateCurvedTrajectory(start, end, 0.1);
        } else {
            // Long distance - more pronounced curve with multiple phases
            trajectory = generateComplexTrajectory(start, end);
        }
        
        // Add human-like variations
        trajectory = addHumanVariations(trajectory);
        
        // Add natural jitter
        trajectory = addNaturalJitter(trajectory);
        
        return trajectory;
    }
    
    private List<Point> generateDirectTrajectory(Point start, Point end) {
        List<Point> trajectory = new ArrayList<>();
        double distance = start.distance(end);
        
        // Calculate number of steps based on distance and precision
        int steps = Math.max(3, (int)(distance / (5 * precision)));
        
        for (int i = 0; i <= steps; i++) {
            double progress = (double) i / steps;
            
            // Linear interpolation with slight variation
            int x = (int)(start.x + (end.x - start.x) * progress);
            int y = (int)(start.y + (end.y - start.y) * progress);
            
            // Add micro-variations
            if (i > 0 && i < steps) {
                x += random.nextInt(3) - 1;
                y += random.nextInt(3) - 1;
            }
            
            trajectory.add(new Point(x, y));
        }
        
        return trajectory;
    }
    
    private List<Point> generateCurvedTrajectory(Point start, Point end, double curveIntensity) {
        List<Point> trajectory = new ArrayList<>();
        double distance = start.distance(end);
        
        // Calculate control point for curve
        Point midPoint = new Point(
            (start.x + end.x) / 2,
            (start.y + end.y) / 2
        );
        
        // Add curve offset
        double perpendicularAngle = Math.atan2(end.y - start.y, end.x - start.x) + Math.PI / 2;
        double curveOffset = distance * curveIntensity * (random.nextDouble() - 0.5);
        
        Point controlPoint = new Point(
            (int)(midPoint.x + Math.cos(perpendicularAngle) * curveOffset),
            (int)(midPoint.y + Math.sin(perpendicularAngle) * curveOffset)
        );
        
        // Generate curved trajectory using quadratic Bezier
        int steps = Math.max(5, (int)(distance / (3 * precision)));
        
        for (int i = 0; i <= steps; i++) {
            double t = (double) i / steps;
            
            // Quadratic Bezier curve
            int x = (int)(Math.pow(1 - t, 2) * start.x + 
                         2 * (1 - t) * t * controlPoint.x + 
                         Math.pow(t, 2) * end.x);
            int y = (int)(Math.pow(1 - t, 2) * start.y + 
                         2 * (1 - t) * t * controlPoint.y + 
                         Math.pow(t, 2) * end.y);
            
            trajectory.add(new Point(x, y));
        }
        
        return trajectory;
    }
    
    private List<Point> generateComplexTrajectory(Point start, Point end) {
        List<Point> trajectory = new ArrayList<>();
        double distance = start.distance(end);
        
        // Multi-phase movement: acceleration, constant speed, deceleration
        int accelerationSteps = (int)(distance * 0.2 / precision);
        int constantSteps = (int)(distance * 0.6 / precision);
        int decelerationSteps = (int)(distance * 0.2 / precision);
        
        // Phase 1: Acceleration
        trajectory.addAll(generateAccelerationPhase(start, accelerationSteps));
        
        // Phase 2: Constant speed
        Point phase2Start = trajectory.get(trajectory.size() - 1);
        trajectory.addAll(generateConstantPhase(phase2Start, constantSteps, end));
        
        // Phase 3: Deceleration
        Point phase3Start = trajectory.get(trajectory.size() - 1);
        trajectory.addAll(generateDecelerationPhase(phase3Start, decelerationSteps, end));
        
        return trajectory;
    }
    
    private List<Point> generateAccelerationPhase(Point start, int steps) {
        List<Point> trajectory = new ArrayList<>();
        double angle = Math.atan2(lastPosition != null ? lastPosition.y - start.y : 0, 
                                 lastPosition != null ? lastPosition.x - start.x : 0);
        
        for (int i = 0; i < steps; i++) {
            double progress = (double) i / steps;
            double speedMultiplier = Math.pow(progress, accelerationFactor);
            
            int x = (int)(start.x + Math.cos(angle) * (i * 2 * speedMultiplier));
            int y = (int)(start.y + Math.sin(angle) * (i * 2 * speedMultiplier));
            
            trajectory.add(new Point(x, y));
        }
        
        return trajectory;
    }
    
    private List<Point> generateConstantPhase(Point start, int steps, Point end) {
        List<Point> trajectory = new ArrayList<>();
        double angle = Math.atan2(end.y - start.y, end.x - start.x);
        double stepDistance = start.distance(end) / steps;
        
        for (int i = 0; i < steps; i++) {
            int x = (int)(start.x + Math.cos(angle) * (i * stepDistance));
            int y = (int)(start.y + Math.sin(angle) * (i * stepDistance));
            
            trajectory.add(new Point(x, y));
        }
        
        return trajectory;
    }
    
    private List<Point> generateDecelerationPhase(Point start, int steps, Point end) {
        List<Point> trajectory = new ArrayList<>();
        double angle = Math.atan2(end.y - start.y, end.x - start.x);
        double totalDistance = start.distance(end);
        
        for (int i = 0; i < steps; i++) {
            double progress = (double) i / steps;
            double speedMultiplier = Math.pow(1 - progress, accelerationFactor);
            
            int x = (int)(start.x + Math.cos(angle) * (totalDistance * progress * speedMultiplier));
            int y = (int)(start.y + Math.sin(angle) * (totalDistance * progress * speedMultiplier));
            
            trajectory.add(new Point(x, y));
        }
        
        return trajectory;
    }
    
    private List<Point> addHumanVariations(List<Point> trajectory) {
        List<Point> variedTrajectory = new ArrayList<>();
        
        for (int i = 0; i < trajectory.size(); i++) {
            Point point = trajectory.get(i);
            
            // Add natural variations based on position in trajectory
            double variationFactor = 1.0;
            if (i > 0 && i < trajectory.size() - 1) {
                // Middle points get more variation
                variationFactor = 1.0 + random.nextDouble() * 0.3;
            }
            
            // Add micro-adjustments
            int x = point.x + (int)((random.nextDouble() - 0.5) * 2 * variationFactor);
            int y = point.y + (int)((random.nextDouble() - 0.5) * 2 * variationFactor);
            
            variedTrajectory.add(new Point(x, y));
        }
        
        return variedTrajectory;
    }
    
    private List<Point> addNaturalJitter(List<Point> trajectory) {
        List<Point> jitteredTrajectory = new ArrayList<>();
        
        for (Point point : trajectory) {
            // Add natural jitter
            if (random.nextDouble() < jitterFactor) {
                int jitterX = random.nextInt(3) - 1;
                int jitterY = random.nextInt(3) - 1;
                
                jitteredTrajectory.add(new Point(point.x + jitterX, point.y + jitterY));
            } else {
                jitteredTrajectory.add(point);
            }
        }
        
        return jitteredTrajectory;
    }
    
    public void executeHumanClick(Point target) {
        // Generate human-like click sequence
        Point currentPos = Mouse.getPosition();
        
        // Generate trajectory to target
        List<Point> trajectory = generateHumanTrajectory(currentPos, target);
        
        // Execute movement with natural timing
        for (Point point : trajectory) {
            Mouse.move(point);
            
            // Natural movement timing
            int delay = (int)(10 + random.nextDouble() * 20);
            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        
        // Natural click behavior
        if (random.nextDouble() < 0.1) {
            // Occasional double-click (human error)
            Mouse.click(target);
            try {
                Thread.sleep(50 + random.nextInt(100));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        Mouse.click(target);
        
        // Update movement history
        updateMovementHistory(target);
        
        if (mouseHeatmap != null) mouseHeatmap.recordClick(target);
    }
    
    public void executeHumanHover(Point target) {
        // Generate human-like hover behavior
        Point currentPos = Mouse.getPosition();
        List<Point> trajectory = generateHumanTrajectory(currentPos, target);
        
        // Execute movement
        for (Point point : trajectory) {
            Mouse.move(point);
            try {
                Thread.sleep(5 + random.nextInt(10));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        
        // Natural hover behavior
        if (random.nextDouble() < 0.3) {
            // Slight movement while hovering
            Point hoverVariation = new Point(
                target.x + random.nextInt(5) - 2,
                target.y + random.nextInt(5) - 2
            );
            Mouse.move(hoverVariation);
        }
        
        Mouse.move(target);
        
        updateMovementHistory(target);
        
        if (mouseHeatmap != null) mouseHeatmap.recordMove(target);
    }
    
    private void updateMovementHistory(Point position) {
        movementHistory.add(position);
        if (movementHistory.size() > 100) {
            movementHistory.remove(0);
        }
        
        lastPosition = position;
        lastMovementTime = System.currentTimeMillis();
        
        // Record movement event
        MouseEvent event = new MouseEvent(
            System.currentTimeMillis(),
            position,
            "movement"
        );
        recentMovements.offer(event);
        
        // Keep only recent movements
        while (recentMovements.size() > 50) {
            recentMovements.poll();
        }
    }
    
    // Getters for external access
    public double getMouseSpeed() { return mouseSpeed; }
    public double getPrecision() { return precision; }
    public Point getLastPosition() { return lastPosition; }
    public long getLastMovementTime() { return lastMovementTime; }
    public List<Point> getMovementHistory() { return new ArrayList<>(movementHistory); }
    
    public Point getHeatmapBiasedClick(Rectangle area) {
        if (mouseHeatmap != null) return mouseHeatmap.getBiasedClick(area);
        // fallback: center of area
        return new Point(area.x + area.width / 2, area.y + area.height / 2);
    }
    
    public void moveMouse(Point p) {
        Mouse.move(p);
    }
    
    // Inner class for mouse events
    private static class MouseEvent {
        final long timestamp;
        final Point position;
        final String type;
        
        MouseEvent(long timestamp, Point position, String type) {
            this.timestamp = timestamp;
            this.position = position;
            this.type = type;
        }
    }
} 