package antiban;

import org.dreambot.api.utilities.Logger;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.wrappers.interactive.Player;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;

import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public class ProfileEvolutionEngine {
    
    private final Random random = ThreadLocalRandom.current();
    
    // Evolution characteristics
    private final Map<String, Double> personalityTraits = new ConcurrentHashMap<>();
    private final Map<String, Double> learningRates = new ConcurrentHashMap<>();
    private final Map<String, Double> adaptationFactors = new ConcurrentHashMap<>();
    
    // Evolution tracking
    private final List<EvolutionEvent> evolutionHistory = new ArrayList<>();
    private final Map<String, List<Double>> traitHistory = new ConcurrentHashMap<>();
    private final Queue<LearningEvent> learningEvents = new LinkedList<>();
    
    // Advanced evolution mechanisms
    private final Map<String, EvolutionStrategy> evolutionStrategies = new HashMap<>();
    private final List<String> activeEvolutionMethods = new ArrayList<>();
    private final Set<String> evolvedTraits = new HashSet<>();
    
    // Behavioral adaptation
    private final Map<String, Double> behavioralAdaptations = new ConcurrentHashMap<>();
    private final List<Long> adaptationTimestamps = new ArrayList<>();
    private final Map<String, Integer> adaptationFrequency = new ConcurrentHashMap<>();
    
    // Learning algorithms
    private final Map<String, LearningAlgorithm> learningAlgorithms = new HashMap<>();
    private final List<Double> learningProgress = new ArrayList<>();
    private final Map<String, Double> skillProgression = new ConcurrentHashMap<>();
    
    // State variables
    private long lastEvolutionCheck;
    private int evolutionCounter;
    private double currentEvolutionRate;
    private boolean isEvolutionActive;
    private double overallAdaptationLevel;
    
    public ProfileEvolutionEngine() {
        initializePersonalityTraits();
        initializeLearningRates();
        initializeAdaptationFactors();
        initializeEvolutionStrategies();
        initializeLearningAlgorithms();
        
        Logger.log("Profile evolution engine initialized with advanced learning algorithms");
    }
    
    private void initializePersonalityTraits() {
        // Initialize personality traits
        personalityTraits.put("reaction_speed", 0.5 + random.nextDouble() * 0.5);
        personalityTraits.put("precision", 0.3 + random.nextDouble() * 0.7);
        personalityTraits.put("patience", 0.2 + random.nextDouble() * 0.8);
        personalityTraits.put("curiosity", 0.1 + random.nextDouble() * 0.9);
        personalityTraits.put("efficiency", 0.4 + random.nextDouble() * 0.6);
        personalityTraits.put("social_tendency", random.nextDouble());
        personalityTraits.put("risk_tolerance", random.nextDouble());
        personalityTraits.put("learning_style", random.nextDouble());
        personalityTraits.put("perfectionism", 0.3 + random.nextDouble() * 0.7);
        personalityTraits.put("adaptability", 0.4 + random.nextDouble() * 0.6);
        personalityTraits.put("creativity", 0.2 + random.nextDouble() * 0.8);
        personalityTraits.put("consistency", 0.5 + random.nextDouble() * 0.5);
        personalityTraits.put("impulsiveness", random.nextDouble());
        personalityTraits.put("analytical_thinking", 0.3 + random.nextDouble() * 0.7);
        personalityTraits.put("emotional_stability", 0.4 + random.nextDouble() * 0.6);
        
        // Initialize trait history
        for (String trait : personalityTraits.keySet()) {
            traitHistory.put(trait, new ArrayList<>());
        }
    }
    
    private void initializeLearningRates() {
        // Initialize learning rates for different aspects
        learningRates.put("skill_learning", 0.05 + random.nextDouble() * 0.1);
        learningRates.put("behavioral_adaptation", 0.03 + random.nextDouble() * 0.08);
        learningRates.put("pattern_recognition", 0.04 + random.nextDouble() * 0.09);
        learningRates.put("environmental_learning", 0.06 + random.nextDouble() * 0.12);
        learningRates.put("social_learning", 0.02 + random.nextDouble() * 0.06);
        learningRates.put("risk_assessment", 0.04 + random.nextDouble() * 0.08);
        learningRates.put("efficiency_optimization", 0.05 + random.nextDouble() * 0.1);
        learningRates.put("creativity_development", 0.03 + random.nextDouble() * 0.07);
    }
    
    private void initializeAdaptationFactors() {
        // Initialize adaptation factors
        adaptationFactors.put("environmental_pressure", 0.1 + random.nextDouble() * 0.2);
        adaptationFactors.put("success_rate", 0.05 + random.nextDouble() * 0.15);
        adaptationFactors.put("failure_rate", 0.08 + random.nextDouble() * 0.18);
        adaptationFactors.put("competition_level", 0.03 + random.nextDouble() * 0.12);
        adaptationFactors.put("resource_availability", 0.06 + random.nextDouble() * 0.14);
        adaptationFactors.put("goal_achievement", 0.04 + random.nextDouble() * 0.16);
        adaptationFactors.put("social_feedback", 0.02 + random.nextDouble() * 0.08);
        adaptationFactors.put("internal_motivation", 0.07 + random.nextDouble() * 0.13);
    }
    
    private void initializeEvolutionStrategies() {
        // Initialize evolution strategies
        evolutionStrategies.put("gradual_adaptation", new GradualAdaptationStrategy());
        evolutionStrategies.put("punctuated_equilibrium", new PunctuatedEquilibriumStrategy());
        evolutionStrategies.put("convergent_evolution", new ConvergentEvolutionStrategy());
        evolutionStrategies.put("divergent_evolution", new DivergentEvolutionStrategy());
        evolutionStrategies.put("coevolution", new CoevolutionStrategy());
        evolutionStrategies.put("adaptive_radiation", new AdaptiveRadiationStrategy());
        evolutionStrategies.put("genetic_drift", new GeneticDriftStrategy());
        evolutionStrategies.put("selection_pressure", new SelectionPressureStrategy());
    }
    
    private void initializeLearningAlgorithms() {
        // Initialize learning algorithms
        learningAlgorithms.put("reinforcement_learning", new ReinforcementLearning());
        learningAlgorithms.put("supervised_learning", new SupervisedLearning());
        learningAlgorithms.put("unsupervised_learning", new UnsupervisedLearning());
        learningAlgorithms.put("deep_learning", new DeepLearning());
        learningAlgorithms.put("genetic_algorithm", new GeneticAlgorithm());
        learningAlgorithms.put("neural_network", new NeuralNetwork());
        learningAlgorithms.put("bayesian_learning", new BayesianLearning());
        learningAlgorithms.put("evolutionary_strategy", new EvolutionaryStrategy());
    }
    
    public void evolveProfile() {
        // Update evolution rate
        updateEvolutionRate();
        
        // Execute evolution strategies
        if (shouldEvolve()) {
            String strategy = selectEvolutionStrategy();
            if (strategy != null) {
                executeEvolutionStrategy(strategy);
            }
        }
        
        // Update personality traits
        evolvePersonalityTraits();
        
        // Execute learning algorithms
        executeLearningAlgorithms();
        
        // Update adaptation level
        updateAdaptationLevel();
        
        // Update evolution history
        updateEvolutionHistory();
        
        // Increment evolution counter
        evolutionCounter++;
    }
    
    private void updateEvolutionRate() {
        // Calculate current evolution rate based on various factors
        double evolutionRate = 0.0;
        
        // Factor 1: Environmental pressure
        evolutionRate += adaptationFactors.get("environmental_pressure") * 0.3;
        
        // Factor 2: Success/failure rates
        double successRate = adaptationFactors.get("success_rate");
        double failureRate = adaptationFactors.get("failure_rate");
        evolutionRate += successRate * 0.2;
        evolutionRate += failureRate * 0.3; // Failure drives evolution more
        
        // Factor 3: Competition level
        evolutionRate += adaptationFactors.get("competition_level") * 0.2;
        
        // Factor 4: Internal motivation
        evolutionRate += adaptationFactors.get("internal_motivation") * 0.15;
        
        // Factor 5: Random variation
        evolutionRate += random.nextDouble() * 0.1;
        
        // Normalize evolution rate
        currentEvolutionRate = Math.max(0.0, Math.min(1.0, evolutionRate));
        
        // Update evolution status
        isEvolutionActive = currentEvolutionRate > 0.3;
    }
    
    private boolean shouldEvolve() {
        // Determine if evolution should occur
        if (isEvolutionActive) {
            return random.nextDouble() < currentEvolutionRate;
        }
        
        // Base probability for evolution
        double baseProbability = 0.02;
        
        // Add adaptation factors
        baseProbability += adaptationFactors.get("goal_achievement") * 0.1;
        baseProbability += adaptationFactors.get("resource_availability") * 0.08;
        baseProbability += adaptationFactors.get("social_feedback") * 0.05;
        
        // Add learning factors
        baseProbability += learningRates.get("behavioral_adaptation") * 0.15;
        baseProbability += learningRates.get("pattern_recognition") * 0.12;
        
        return random.nextDouble() < baseProbability;
    }
    
    private String selectEvolutionStrategy() {
        // Select evolution strategy based on current state
        List<String> availableStrategies = new ArrayList<>();
        List<Double> weights = new ArrayList<>();
        
        for (Map.Entry<String, EvolutionStrategy> entry : evolutionStrategies.entrySet()) {
            String strategy = entry.getKey();
            EvolutionStrategy evolutionStrategy = entry.getValue();
            
            if (evolutionStrategy.canExecute()) {
                double weight = evolutionStrategy.getWeight();
                availableStrategies.add(strategy);
                weights.add(weight);
            }
        }
        
        if (availableStrategies.isEmpty()) {
            return null;
        }
        
        // Normalize weights
        double totalWeight = weights.stream().mapToDouble(Double::doubleValue).sum();
        for (int i = 0; i < weights.size(); i++) {
            weights.set(i, weights.get(i) / totalWeight);
        }
        
        // Select based on weights
        double randomValue = random.nextDouble();
        double cumulativeWeight = 0.0;
        
        for (int i = 0; i < availableStrategies.size(); i++) {
            cumulativeWeight += weights.get(i);
            if (randomValue <= cumulativeWeight) {
                return availableStrategies.get(i);
            }
        }
        
        return availableStrategies.get(random.nextInt(availableStrategies.size()));
    }
    
    private void executeEvolutionStrategy(String strategy) {
        EvolutionStrategy evolutionStrategy = evolutionStrategies.get(strategy);
        if (evolutionStrategy != null) {
            Logger.log("Executing evolution strategy: " + strategy);
            
            evolutionStrategy.execute();
            activeEvolutionMethods.add(strategy);
            
            // Record evolution event
            EvolutionEvent event = new EvolutionEvent(
                System.currentTimeMillis(),
                strategy,
                "strategy_executed"
            );
            evolutionHistory.add(event);
        }
    }
    
    private void evolvePersonalityTraits() {
        // Evolve personality traits based on learning rates
        for (Map.Entry<String, Double> entry : personalityTraits.entrySet()) {
            String trait = entry.getKey();
            double currentValue = entry.getValue();
            
            // Calculate evolution amount
            double learningRate = getLearningRateForTrait(trait);
            double evolution = (random.nextDouble() - 0.5) * learningRate;
            
            // Apply evolution
            double newValue = currentValue + evolution;
            newValue = Math.max(0.0, Math.min(1.0, newValue));
            
            personalityTraits.put(trait, newValue);
            
            // Update trait history
            traitHistory.get(trait).add(newValue);
            if (traitHistory.get(trait).size() > 100) {
                traitHistory.get(trait).remove(0);
            }
            
            // Mark as evolved
            evolvedTraits.add(trait);
        }
    }
    
    private double getLearningRateForTrait(String trait) {
        // Get learning rate for specific trait
        switch (trait) {
            case "reaction_speed":
                return learningRates.get("skill_learning") * 0.8;
            case "precision":
                return learningRates.get("skill_learning") * 1.2;
            case "patience":
                return learningRates.get("behavioral_adaptation") * 0.9;
            case "curiosity":
                return learningRates.get("creativity_development") * 1.1;
            case "efficiency":
                return learningRates.get("efficiency_optimization") * 1.0;
            case "social_tendency":
                return learningRates.get("social_learning") * 0.7;
            case "risk_tolerance":
                return learningRates.get("risk_assessment") * 1.3;
            case "learning_style":
                return learningRates.get("pattern_recognition") * 1.1;
            default:
                return learningRates.get("behavioral_adaptation") * 1.0;
        }
    }
    
    private void executeLearningAlgorithms() {
        // Execute learning algorithms
        for (Map.Entry<String, LearningAlgorithm> entry : learningAlgorithms.entrySet()) {
            String algorithm = entry.getKey();
            LearningAlgorithm learningAlgorithm = entry.getValue();
            
            if (random.nextDouble() < 0.3) { // 30% chance per algorithm
                Logger.log("Executing learning algorithm: " + algorithm);
                
                double progress = learningAlgorithm.learn();
                learningProgress.add(progress);
                
                // Record learning event
                LearningEvent event = new LearningEvent(
                    System.currentTimeMillis(),
                    algorithm,
                    progress
                );
                learningEvents.offer(event);
                
                // Keep only recent progress
                if (learningProgress.size() > 50) {
                    learningProgress.remove(0);
                }
                
                // Keep only recent events
                while (learningEvents.size() > 100) {
                    learningEvents.poll();
                }
            }
        }
    }
    
    private void updateAdaptationLevel() {
        // Calculate overall adaptation level
        double adaptationLevel = 0.0;
        
        // Factor 1: Trait evolution
        for (Map.Entry<String, Double> entry : personalityTraits.entrySet()) {
            adaptationLevel += entry.getValue() * 0.05;
        }
        
        // Factor 2: Learning progress
        if (!learningProgress.isEmpty()) {
            double averageProgress = learningProgress.stream()
                .mapToDouble(Double::doubleValue)
                .average()
                .orElse(0.0);
            adaptationLevel += averageProgress * 0.3;
        }
        
        // Factor 3: Evolution activity
        adaptationLevel += (evolutionCounter / 100.0) * 0.2;
        
        // Factor 4: Environmental adaptation
        adaptationLevel += adaptationFactors.get("environmental_pressure") * 0.25;
        
        // Normalize adaptation level
        overallAdaptationLevel = Math.max(0.0, Math.min(1.0, adaptationLevel));
    }
    
    private void updateEvolutionHistory() {
        // Update evolution history
        adaptationTimestamps.add(System.currentTimeMillis());
        
        // Keep only recent history
        if (evolutionHistory.size() > 100) {
            evolutionHistory.remove(0);
        }
        
        if (adaptationTimestamps.size() > 200) {
            adaptationTimestamps.remove(0);
        }
        
        // Keep only recent active methods
        if (activeEvolutionMethods.size() > 20) {
            activeEvolutionMethods.remove(0);
        }
        
        // Update last check time
        lastEvolutionCheck = System.currentTimeMillis();
    }
    
    // Getters for external access
    public double getCurrentEvolutionRate() { return currentEvolutionRate; }
    public boolean isEvolutionActive() { return isEvolutionActive; }
    public int getEvolutionCounter() { return evolutionCounter; }
    public double getOverallAdaptationLevel() { return overallAdaptationLevel; }
    public Map<String, Double> getPersonalityTraits() { return new HashMap<>(personalityTraits); }
    public List<String> getActiveEvolutionMethods() { return new ArrayList<>(activeEvolutionMethods); }
    public Set<String> getEvolvedTraits() { return new HashSet<>(evolvedTraits); }
    public Map<String, Double> getLearningRates() { return new HashMap<>(learningRates); }
    public Map<String, Double> getAdaptationFactors() { return new HashMap<>(adaptationFactors); }
    
    // Inner interfaces and classes
    private interface EvolutionStrategy {
        boolean canExecute();
        double getWeight();
        void execute();
    }
    
    private interface LearningAlgorithm {
        double learn();
    }
    
    // Evolution strategy implementations
    private class GradualAdaptationStrategy implements EvolutionStrategy {
        @Override
        public boolean canExecute() {
            return evolutionCounter > 10;
        }
        
        @Override
        public double getWeight() {
            return 0.3;
        }
        
        @Override
        public void execute() {
            // Gradual adaptation of traits
            for (Map.Entry<String, Double> entry : personalityTraits.entrySet()) {
                String trait = entry.getKey();
                double currentValue = entry.getValue();
                
                double adaptation = (random.nextDouble() - 0.5) * 0.1;
                double newValue = Math.max(0.0, Math.min(1.0, currentValue + adaptation));
                
                personalityTraits.put(trait, newValue);
            }
        }
    }
    
    private class PunctuatedEquilibriumStrategy implements EvolutionStrategy {
        @Override
        public boolean canExecute() {
            return evolutionCounter % 50 == 0;
        }
        
        @Override
        public double getWeight() {
            return 0.15;
        }
        
        @Override
        public void execute() {
            // Major evolutionary change
            String[] traits = personalityTraits.keySet().toArray(new String[0]);
            String targetTrait = traits[random.nextInt(traits.length)];
            
            double currentValue = personalityTraits.get(targetTrait);
            double evolution = (random.nextDouble() - 0.5) * 0.5; // Large change
            double newValue = Math.max(0.0, Math.min(1.0, currentValue + evolution));
            
            personalityTraits.put(targetTrait, newValue);
        }
    }
    
    private class ConvergentEvolutionStrategy implements EvolutionStrategy {
        @Override
        public boolean canExecute() {
            return personalityTraits.size() > 5;
        }
        
        @Override
        public double getWeight() {
            return 0.2;
        }
        
        @Override
        public void execute() {
            // Traits converge toward similar values
            double targetValue = 0.5 + (random.nextDouble() - 0.5) * 0.3;
            
            for (Map.Entry<String, Double> entry : personalityTraits.entrySet()) {
                String trait = entry.getKey();
                double currentValue = entry.getValue();
                
                double convergence = (targetValue - currentValue) * 0.1;
                double newValue = Math.max(0.0, Math.min(1.0, currentValue + convergence));
                
                personalityTraits.put(trait, newValue);
            }
        }
    }
    
    private class DivergentEvolutionStrategy implements EvolutionStrategy {
        @Override
        public boolean canExecute() {
            return personalityTraits.size() > 3;
        }
        
        @Override
        public double getWeight() {
            return 0.15;
        }
        
        @Override
        public void execute() {
            // Traits diverge from each other
            String[] traits = personalityTraits.keySet().toArray(new String[0]);
            String trait1 = traits[random.nextInt(traits.length)];
            String trait2 = traits[random.nextInt(traits.length)];
            
            if (!trait1.equals(trait2)) {
                double value1 = personalityTraits.get(trait1);
                double value2 = personalityTraits.get(trait2);
                
                double divergence = (random.nextDouble() - 0.5) * 0.2;
                personalityTraits.put(trait1, Math.max(0.0, Math.min(1.0, value1 + divergence)));
                personalityTraits.put(trait2, Math.max(0.0, Math.min(1.0, value2 - divergence)));
            }
        }
    }
    
    private class CoevolutionStrategy implements EvolutionStrategy {
        @Override
        public boolean canExecute() {
            return true;
        }
        
        @Override
        public double getWeight() {
            return 0.1;
        }
        
        @Override
        public void execute() {
            // Coevolution of related traits
            String[] relatedTraits = {"reaction_speed", "precision", "efficiency"};
            
            for (String trait : relatedTraits) {
                if (personalityTraits.containsKey(trait)) {
                    double currentValue = personalityTraits.get(trait);
                    double coevolution = (random.nextDouble() - 0.5) * 0.15;
                    double newValue = Math.max(0.0, Math.min(1.0, currentValue + coevolution));
                    personalityTraits.put(trait, newValue);
                }
            }
        }
    }
    
    private class AdaptiveRadiationStrategy implements EvolutionStrategy {
        @Override
        public boolean canExecute() {
            return evolutionCounter > 20;
        }
        
        @Override
        public double getWeight() {
            return 0.05;
        }
        
        @Override
        public void execute() {
            // Rapid diversification of traits
            for (Map.Entry<String, Double> entry : personalityTraits.entrySet()) {
                String trait = entry.getKey();
                double currentValue = entry.getValue();
                
                double radiation = (random.nextDouble() - 0.5) * 0.3;
                double newValue = Math.max(0.0, Math.min(1.0, currentValue + radiation));
                
                personalityTraits.put(trait, newValue);
            }
        }
    }
    
    private class GeneticDriftStrategy implements EvolutionStrategy {
        @Override
        public boolean canExecute() {
            return random.nextDouble() < 0.1;
        }
        
        @Override
        public double getWeight() {
            return 0.03;
        }
        
        @Override
        public void execute() {
            // Random genetic drift
            String[] traits = personalityTraits.keySet().toArray(new String[0]);
            String randomTrait = traits[random.nextInt(traits.length)];
            
            double currentValue = personalityTraits.get(randomTrait);
            double drift = (random.nextDouble() - 0.5) * 0.4;
            double newValue = Math.max(0.0, Math.min(1.0, currentValue + drift));
            
            personalityTraits.put(randomTrait, newValue);
        }
    }
    
    private class SelectionPressureStrategy implements EvolutionStrategy {
        @Override
        public boolean canExecute() {
            return overallAdaptationLevel > 0.5;
        }
        
        @Override
        public double getWeight() {
            return 0.02;
        }
        
        @Override
        public void execute() {
            // Selection pressure on traits
            for (Map.Entry<String, Double> entry : personalityTraits.entrySet()) {
                String trait = entry.getKey();
                double currentValue = entry.getValue();
                
                // Apply selection pressure
                double pressure = (currentValue > 0.5) ? 0.05 : -0.05;
                double newValue = Math.max(0.0, Math.min(1.0, currentValue + pressure));
                
                personalityTraits.put(trait, newValue);
            }
        }
    }
    
    // Learning algorithm implementations
    private class ReinforcementLearning implements LearningAlgorithm {
        @Override
        public double learn() {
            // Reinforcement learning implementation
            double learningRate = 0.1;
            double reward = random.nextDouble();
            double progress = learningRate * reward;
            
            return Math.min(1.0, progress);
        }
    }
    
    private class SupervisedLearning implements LearningAlgorithm {
        @Override
        public double learn() {
            // Supervised learning implementation
            double learningRate = 0.08;
            double accuracy = 0.7 + random.nextDouble() * 0.3;
            double progress = learningRate * accuracy;
            
            return Math.min(1.0, progress);
        }
    }
    
    private class UnsupervisedLearning implements LearningAlgorithm {
        @Override
        public double learn() {
            // Unsupervised learning implementation
            double learningRate = 0.06;
            double discovery = random.nextDouble();
            double progress = learningRate * discovery;
            
            return Math.min(1.0, progress);
        }
    }
    
    private class DeepLearning implements LearningAlgorithm {
        @Override
        public double learn() {
            // Deep learning implementation
            double learningRate = 0.12;
            double complexity = 0.8 + random.nextDouble() * 0.2;
            double progress = learningRate * complexity;
            
            return Math.min(1.0, progress);
        }
    }
    
    private class GeneticAlgorithm implements LearningAlgorithm {
        @Override
        public double learn() {
            // Genetic algorithm implementation
            double learningRate = 0.09;
            double fitness = 0.6 + random.nextDouble() * 0.4;
            double progress = learningRate * fitness;
            
            return Math.min(1.0, progress);
        }
    }
    
    private class NeuralNetwork implements LearningAlgorithm {
        @Override
        public double learn() {
            // Neural network implementation
            double learningRate = 0.11;
            double activation = 0.7 + random.nextDouble() * 0.3;
            double progress = learningRate * activation;
            
            return Math.min(1.0, progress);
        }
    }
    
    private class BayesianLearning implements LearningAlgorithm {
        @Override
        public double learn() {
            // Bayesian learning implementation
            double learningRate = 0.07;
            double probability = 0.5 + random.nextDouble() * 0.5;
            double progress = learningRate * probability;
            
            return Math.min(1.0, progress);
        }
    }
    
    private class EvolutionaryStrategy implements LearningAlgorithm {
        @Override
        public double learn() {
            // Evolutionary strategy implementation
            double learningRate = 0.10;
            double evolution = currentEvolutionRate;
            double progress = learningRate * evolution;
            
            return Math.min(1.0, progress);
        }
    }
    
    // Inner classes for events
    private static class EvolutionEvent {
        final long timestamp;
        final String strategy;
        final String status;
        
        EvolutionEvent(long timestamp, String strategy, String status) {
            this.timestamp = timestamp;
            this.strategy = strategy;
            this.status = status;
        }
    }
    
    private static class LearningEvent {
        final long timestamp;
        final String algorithm;
        final double progress;
        
        LearningEvent(long timestamp, String algorithm, double progress) {
            this.timestamp = timestamp;
            this.algorithm = algorithm;
            this.progress = progress;
        }
    }
} 