package antiban;

import org.dreambot.api.utilities.Logger;
import org.dreambot.api.methods.input.Camera;
import org.dreambot.api.input.Mouse;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.wrappers.interactive.Player;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.methods.Calculations;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Advanced Behavioral Noise Generator
 * Creates sophisticated human-like behavioral patterns that surpass P2P AI detection
 */
public class BehavioralNoiseGenerator {
    
    private final Random random = ThreadLocalRandom.current();
    
    // Core noise generation system
    private final Map<String, Double> noiseProbabilities = new ConcurrentHashMap<>();
    private final List<NoiseEvent> noiseHistory = new ArrayList<>();
    private final Queue<BehavioralEvent> behavioralEvents = new LinkedList<>();
    
    // Advanced pattern management
    private final Map<String, NoisePattern> noisePatterns = new HashMap<>();
    private final List<String> activeNoiseTypes = new ArrayList<>();
    private final Set<String> generatedNoiseTypes = new HashSet<>();
    
    // Sophisticated state tracking
    private final Map<String, Long> lastNoiseTime = new ConcurrentHashMap<>();
    private final Map<String, Integer> noiseFrequency = new ConcurrentHashMap<>();
    private final List<Long> noiseTimestamps = new ArrayList<>();
    
    // Human-like behavioral characteristics
    private final Map<String, Double> humanNoiseFactors = new HashMap<>();
    private final List<Double> noiseIntensities = new ArrayList<>();
    private final Map<String, Double> contextualNoise = new HashMap<>();
    
    // Advanced state variables
    private long lastNoiseGeneration;
    private int totalNoiseEvents;
    private double currentNoiseLevel;
    private boolean isNoiseActive;
    private String currentContext;
    
    public BehavioralNoiseGenerator() {
        initializeNoiseProbabilities();
        initializeNoisePatterns();
        initializeHumanNoiseFactors();
        initializeContextualNoise();
        
        Logger.log("[BehavioralNoise] Advanced human-like noise generator initialized");
    }
    
    /**
     * Initialize sophisticated noise probabilities with personality-based variations
     */
    private void initializeNoiseProbabilities() {
        // Core noise types with realistic probabilities
        noiseProbabilities.put("micro_pause", 0.15 + random.nextDouble() * 0.1);
        noiseProbabilities.put("skill_check", 0.12 + random.nextDouble() * 0.08);
        noiseProbabilities.put("environmental_interaction", 0.10 + random.nextDouble() * 0.05);
        noiseProbabilities.put("inventory_management", 0.08 + random.nextDouble() * 0.06);
        noiseProbabilities.put("camera_movement", 0.10 + random.nextDouble() * 0.08);
        noiseProbabilities.put("mouse_jitter", 0.05 + random.nextDouble() * 0.03);
        noiseProbabilities.put("tab_switching", 0.08 + random.nextDouble() * 0.05);
        noiseProbabilities.put("npc_interaction", 0.06 + random.nextDouble() * 0.04);
        noiseProbabilities.put("object_examination", 0.07 + random.nextDouble() * 0.05);
        noiseProbabilities.put("combat_analysis", 0.09 + random.nextDouble() * 0.06);
        noiseProbabilities.put("prayer_check", 0.05 + random.nextDouble() * 0.03);
        noiseProbabilities.put("equipment_check", 0.06 + random.nextDouble() * 0.04);
        noiseProbabilities.put("chat_interaction", 0.03 + random.nextDouble() * 0.02);
        noiseProbabilities.put("minimap_interaction", 0.04 + random.nextDouble() * 0.03);
        noiseProbabilities.put("interface_exploration", 0.05 + random.nextDouble() * 0.04);
        
        // Initialize frequency tracking for each noise type
        for (String noiseType : noiseProbabilities.keySet()) {
            noiseFrequency.put(noiseType, 0);
            lastNoiseTime.put(noiseType, 0L);
        }
    }
    
    /**
     * Initialize advanced noise patterns with sophisticated implementations
     */
    private void initializeNoisePatterns() {
        noisePatterns.put("micro_pause", new MicroPausePattern());
        noisePatterns.put("skill_check", new SkillCheckPattern());
        noisePatterns.put("environmental_interaction", new EnvironmentalInteractionPattern());
        noisePatterns.put("inventory_management", new InventoryManagementPattern());
        noisePatterns.put("camera_movement", new CameraMovementPattern());
        noisePatterns.put("mouse_jitter", new MouseJitterPattern());
        noisePatterns.put("tab_switching", new TabSwitchingPattern());
        noisePatterns.put("npc_interaction", new NPCInteractionPattern());
        noisePatterns.put("object_examination", new ObjectExaminationPattern());
        noisePatterns.put("combat_analysis", new CombatAnalysisPattern());
        noisePatterns.put("prayer_check", new PrayerCheckPattern());
        noisePatterns.put("equipment_check", new EquipmentCheckPattern());
        noisePatterns.put("chat_interaction", new ChatInteractionPattern());
        noisePatterns.put("minimap_interaction", new MinimapInteractionPattern());
        noisePatterns.put("interface_exploration", new InterfaceExplorationPattern());
    }
    
    /**
     * Initialize human-like behavioral factors for realistic noise generation
     */
    private void initializeHumanNoiseFactors() {
        // Personality-based factors that influence noise generation
        humanNoiseFactors.put("attention_span", 0.6 + random.nextDouble() * 0.4);
        humanNoiseFactors.put("curiosity_level", 0.3 + random.nextDouble() * 0.7);
        humanNoiseFactors.put("efficiency_focus", 0.4 + random.nextDouble() * 0.6);
        humanNoiseFactors.put("distraction_tendency", 0.2 + random.nextDouble() * 0.8);
        humanNoiseFactors.put("learning_behavior", 0.5 + random.nextDouble() * 0.5);
        humanNoiseFactors.put("social_tendency", random.nextDouble());
        humanNoiseFactors.put("risk_tolerance", random.nextDouble());
        humanNoiseFactors.put("perfectionism", 0.3 + random.nextDouble() * 0.7);
        humanNoiseFactors.put("impatience", random.nextDouble());
        humanNoiseFactors.put("exploration_drive", 0.4 + random.nextDouble() * 0.6);
    }
    
    /**
     * Initialize contextual noise factors based on game situations
     */
    private void initializeContextualNoise() {
        contextualNoise.put("combat_context", 0.8 + random.nextDouble() * 0.2);
        contextualNoise.put("skilling_context", 0.6 + random.nextDouble() * 0.3);
        contextualNoise.put("questing_context", 0.7 + random.nextDouble() * 0.2);
        contextualNoise.put("exploration_context", 0.9 + random.nextDouble() * 0.1);
        contextualNoise.put("social_context", 0.5 + random.nextDouble() * 0.4);
        contextualNoise.put("efficiency_context", 0.4 + random.nextDouble() * 0.3);
        contextualNoise.put("learning_context", 0.8 + random.nextDouble() * 0.2);
        contextualNoise.put("casual_context", 0.7 + random.nextDouble() * 0.3);
        contextualNoise.put("danger_context", 0.6 + random.nextDouble() * 0.4);
        contextualNoise.put("boredom_context", 0.9 + random.nextDouble() * 0.1);
    }
    
    /**
     * Main noise generation method with sophisticated decision making
     */
    public void generateBehavioralNoise() {
        // Update current context and noise level
        updateContext();
        updateNoiseLevel();
        
        // Generate noise based on sophisticated algorithms
        if (shouldGenerateNoise()) {
            String noiseType = selectNoiseType();
            if (noiseType != null) {
                executeNoisePattern(noiseType);
            }
        }
        
        // Update tracking systems
        updateNoiseHistory();
        generateContextualNoise();
        
        // Increment event counter
        totalNoiseEvents++;
    }
    
    /**
     * Update current game context for contextual noise generation
     */
    private void updateContext() {
        Player localPlayer = Players.getLocal();
        if (localPlayer == null) {
            currentContext = "unknown";
            return;
        }
        
        if (localPlayer.isInCombat()) {
            currentContext = "combat";
        } else if (localPlayer.isMoving()) {
            currentContext = "exploration";
        } else {
            currentContext = "skilling";
        }
    }
    
    /**
     * Calculate sophisticated noise level based on multiple factors
     */
    private void updateNoiseLevel() {
        double noiseLevel = 0.0;
        
        // Factor 1: Time-based noise accumulation
        long timeSinceLastNoise = System.currentTimeMillis() - lastNoiseGeneration;
        if (timeSinceLastNoise > 30000) {
            noiseLevel += 0.3 + (timeSinceLastNoise / 60000.0) * 0.2;
        }
        
        // Factor 2: Human personality factors
        double attentionSpan = humanNoiseFactors.get("attention_span");
        double curiosityLevel = humanNoiseFactors.get("curiosity_level");
        double distractionTendency = humanNoiseFactors.get("distraction_tendency");
        double boredomFactor = humanNoiseFactors.get("impatience");
        
        noiseLevel += (1.0 - attentionSpan) * 0.25;
        noiseLevel += curiosityLevel * 0.2;
        noiseLevel += distractionTendency * 0.3;
        noiseLevel += boredomFactor * 0.15;
        
        // Factor 3: Contextual influence
        double contextualFactor = contextualNoise.getOrDefault(currentContext + "_context", 0.5);
        noiseLevel += contextualFactor * 0.2;
        
        // Factor 4: Random human variation
        noiseLevel += random.nextDouble() * 0.25;
        
        // Factor 5: Fatigue simulation
        if (totalNoiseEvents > 50) {
            noiseLevel += 0.1; // Slight increase in noise as session progresses
        }
        
        // Normalize and set noise level
        currentNoiseLevel = Math.max(0.0, Math.min(1.0, noiseLevel));
        isNoiseActive = currentNoiseLevel > 0.5;
    }
    
    /**
     * Sophisticated decision making for noise generation
     */
    private boolean shouldGenerateNoise() {
        if (isNoiseActive) {
            return random.nextDouble() < currentNoiseLevel;
        }
        
        // Base probability with contextual adjustments
        double baseProbability = 0.05;
        
        Player localPlayer = Players.getLocal();
        if (localPlayer != null) {
            if (localPlayer.isInCombat()) {
                baseProbability += contextualNoise.get("combat_context") * 0.15;
            } else if (currentContext.equals("exploration")) {
                baseProbability += contextualNoise.get("exploration_context") * 0.2;
            } else {
                baseProbability += contextualNoise.get("casual_context") * 0.1;
            }
        }
        
        // Add human factor influence
        baseProbability += humanNoiseFactors.get("curiosity_level") * 0.1;
        baseProbability += humanNoiseFactors.get("distraction_tendency") * 0.15;
        
        return random.nextDouble() < baseProbability;
    }
    
    /**
     * Advanced noise type selection with weighted probabilities
     */
    private String selectNoiseType() {
        Map<String, Double> weightedProbabilities = new HashMap<>();
        
        for (String noiseType : noiseProbabilities.keySet()) {
            double weight = noiseProbabilities.get(noiseType);
            
            // Time-based weight adjustment
            long timeSinceLast = System.currentTimeMillis() - lastNoiseTime.get(noiseType);
            long minInterval = getMinimumInterval(noiseType);
            
            if (timeSinceLast < minInterval) {
                weight *= 0.1; // Heavy penalty for frequent noise
            } else {
                weight *= 1.0 + (timeSinceLast / 60000.0) * 0.8; // Reward for infrequent noise
            }
            
            // Contextual weight adjustment
            weight += getContextualWeight(noiseType);
            
            // Frequency-based penalty
            weight -= getFrequencyWeight(noiseType);
            
            // Human factor influence
            weight += getHumanFactorWeight(noiseType);
            
            weightedProbabilities.put(noiseType, Math.max(0.01, weight));
        }
        
        // Weighted random selection
        double totalWeight = weightedProbabilities.values().stream().mapToDouble(Double::doubleValue).sum();
        double randomValue = random.nextDouble() * totalWeight;
        double currentWeight = 0;
        
        for (Map.Entry<String, Double> entry : weightedProbabilities.entrySet()) {
            currentWeight += entry.getValue();
            if (randomValue <= currentWeight) {
                return entry.getKey();
            }
        }
        
        return null;
    }
    
    /**
     * Get minimum interval between noise occurrences
     */
    private long getMinimumInterval(String noiseType) {
        switch (noiseType) {
            case "micro_pause":
                return 15000 + random.nextInt(10000); // 15-25 seconds
            case "skill_check":
                return 30000 + random.nextInt(15000); // 30-45 seconds
            case "camera_movement":
                return 10000 + random.nextInt(8000);  // 10-18 seconds
            case "mouse_jitter":
                return 5000 + random.nextInt(5000);   // 5-10 seconds
            case "tab_switching":
                return 20000 + random.nextInt(10000); // 20-30 seconds
            case "combat_analysis":
                return 8000 + random.nextInt(7000);   // 8-15 seconds
            default:
                return 45000 + random.nextInt(15000); // 45-60 seconds
        }
    }
    
    /**
     * Calculate contextual weight based on current game state
     */
    private double getContextualWeight(String noiseType) {
        double weight = 0.0;
        Player localPlayer = Players.getLocal();
        
        if (localPlayer != null) {
            if (localPlayer.isInCombat()) {
                if (noiseType.equals("combat_analysis")) weight += 0.4;
                if (noiseType.equals("prayer_check")) weight += 0.3;
                if (noiseType.equals("equipment_check")) weight += 0.2;
            } else {
                if (noiseType.equals("skill_check")) weight += 0.3;
                if (noiseType.equals("environmental_interaction")) weight += 0.2;
                if (noiseType.equals("inventory_management")) weight += 0.15;
            }
        }
        
        // Context-specific adjustments
        if (currentContext.equals("exploration")) {
            if (noiseType.equals("environmental_interaction")) weight += 0.3;
            if (noiseType.equals("object_examination")) weight += 0.25;
        }
        
        return weight;
    }
    
    /**
     * Calculate frequency-based weight penalty
     */
    private double getFrequencyWeight(String noiseType) {
        int frequency = noiseFrequency.get(noiseType);
        if (frequency > 10) return 0.4;
        if (frequency > 5) return 0.2;
        return 0.0;
    }
    
    /**
     * Calculate human factor influence on noise selection
     */
    private double getHumanFactorWeight(String noiseType) {
        double weight = 0.0;
        
        switch (noiseType) {
            case "skill_check":
                weight += humanNoiseFactors.get("learning_behavior") * 0.2;
                break;
            case "environmental_interaction":
                weight += humanNoiseFactors.get("curiosity_level") * 0.3;
                break;
            case "chat_interaction":
                weight += humanNoiseFactors.get("social_tendency") * 0.4;
                break;
            case "interface_exploration":
                weight += humanNoiseFactors.get("exploration_drive") * 0.25;
                break;
        }
        
        return weight;
    }
    
    /**
     * Execute noise pattern with error handling and logging
     */
    private void executeNoisePattern(String noiseType) {
        NoisePattern pattern = noisePatterns.get(noiseType);
        if (pattern != null) {
            try {
                pattern.execute();
                
                // Update tracking systems
                lastNoiseTime.put(noiseType, System.currentTimeMillis());
                noiseFrequency.put(noiseType, noiseFrequency.get(noiseType) + 1);
                lastNoiseGeneration = System.currentTimeMillis();
                
                // Record event
                noiseTimestamps.add(lastNoiseGeneration);
                if (noiseTimestamps.size() > 100) {
                    noiseTimestamps.remove(0);
                }
                
                // Add to active types
                if (!activeNoiseTypes.contains(noiseType)) {
                    activeNoiseTypes.add(noiseType);
                }
                generatedNoiseTypes.add(noiseType);
                
                Logger.log("[BehavioralNoise] Generated: " + noiseType);
                
            } catch (Exception e) {
                Logger.log("[BehavioralNoise] Error executing pattern '" + noiseType + "': " + e.getMessage());
            }
        }
    }
    
    /**
     * Generate contextual noise based on current game situation
     */
    private void generateContextualNoise() {
        Player localPlayer = Players.getLocal();
        if (localPlayer == null) return;
        
        if (localPlayer.isInCombat()) {
            if (random.nextDouble() < 0.25) {
                executeNoisePattern("combat_analysis");
            }
        } else if (currentContext.equals("exploration")) {
            if (random.nextDouble() < 0.15) {
                executeNoisePattern("environmental_interaction");
            }
        } else {
            if (random.nextDouble() < 0.1) {
                executeNoisePattern("skill_check");
            }
        }
    }
    
    /**
     * Update noise history and clean up old data
     */
    private void updateNoiseHistory() {
        // Prune old noise events
        if (noiseHistory.size() > 200) {
            noiseHistory.remove(0);
        }
        
        // Prune old behavioral events
        while (behavioralEvents.size() > 100) {
            behavioralEvents.poll();
        }
        
        // Prune old timestamps
        if (noiseTimestamps.size() > 200) {
            noiseTimestamps.remove(0);
        }
    }
    
    // Public getters for external access
    public double getCurrentNoiseLevel() { return currentNoiseLevel; }
    public boolean isNoiseActive() { return isNoiseActive; }
    public int getTotalNoiseEvents() { return totalNoiseEvents; }
    public List<String> getActiveNoiseTypes() { return new ArrayList<>(activeNoiseTypes); }
    public Map<String, Integer> getNoiseFrequency() { return new HashMap<>(noiseFrequency); }
    public Map<String, Double> getHumanNoiseFactors() { return new HashMap<>(humanNoiseFactors); }
    public String getCurrentContext() { return currentContext; }
    
    // --- Advanced Noise Pattern Implementations ---
    
    private interface NoisePattern {
        void execute();
    }
    
    /**
     * Micro-pause pattern with natural head movement simulation
     */
    private class MicroPausePattern implements NoisePattern {
        @Override
        public void execute() {
            int pauseDuration = 1000 + random.nextInt(3000);
            Logger.log("[BehavioralNoise] Micro-pause for " + pauseDuration + "ms");
            
            // Natural head movement during pause
            if (random.nextBoolean()) {
                int yawVariation = random.nextInt(30) - 15;
                Camera.rotateToYaw(Camera.getYaw() + yawVariation);
            }
            
            Sleep.sleep(pauseDuration);
        }
    }
    
    /**
     * Skill checking pattern with realistic tab switching
     */
    private class SkillCheckPattern implements NoisePattern {
        @Override
        public void execute() {
            Skill randomSkill = Skill.values()[random.nextInt(Skill.values().length)];
            Logger.log("[BehavioralNoise] Checking skill: " + randomSkill.getName());
            
            Tabs.open(Tab.SKILLS);
            Sleep.sleep(300 + random.nextInt(500), 800 + random.nextInt(400));
            
            // Natural tab switching behavior
            if (random.nextBoolean()) {
                Tab[] otherTabs = {Tab.INVENTORY, Tab.EQUIPMENT, Tab.PRAYER};
                Tab otherTab = otherTabs[random.nextInt(otherTabs.length)];
                Tabs.open(otherTab);
                Sleep.sleep(200 + random.nextInt(300), 500 + random.nextInt(300));
            }
        }
    }
    
    /**
     * Environmental interaction with realistic object examination
     */
    private class EnvironmentalInteractionPattern implements NoisePattern {
        @Override
        public void execute() {
            List<GameObject> nearbyObjects = new ArrayList<>(GameObjects.all(obj -> 
                obj != null && obj.distance() < 8 && obj.hasAction("Examine")));
            
            if (!nearbyObjects.isEmpty()) {
                GameObject randomObject = nearbyObjects.get(random.nextInt(nearbyObjects.size()));
                Logger.log("[BehavioralNoise] Interacting with: " + randomObject.getName());
                
                // TODO: Fix tile to screen conversion for DreamBot API update
                // Mouse.move(Calculations.tileToScreen(randomObject.getTile()));
                
                Sleep.sleep(200 + random.nextInt(300), 500 + random.nextInt(300));
                
                // Sometimes interact
                if (random.nextDouble() < 0.3) {
                    randomObject.interact("Examine");
                    Sleep.sleep(500 + random.nextInt(1000), 1500 + random.nextInt(1000));
                }
            }
        }
    }
    
    /**
     * Inventory management with realistic item examination
     */
    private class InventoryManagementPattern implements NoisePattern {
        @Override
        public void execute() {
            Logger.log("[BehavioralNoise] Managing inventory");
            
            Tabs.open(Tab.INVENTORY);
            Sleep.sleep(200 + random.nextInt(400), 600 + random.nextInt(400));
            
            // Simulate item examination
            if (random.nextBoolean()) {
                Sleep.sleep(300 + random.nextInt(500), 800 + random.nextInt(400));
            }
            
            // Switch to equipment tab
            Tabs.open(Tab.EQUIPMENT);
            Sleep.sleep(300 + random.nextInt(400), 800 + random.nextInt(400));
        }
    }
    
    /**
     * Camera movement with natural head motion simulation
     */
    private class CameraMovementPattern implements NoisePattern {
        @Override
        public void execute() {
            int yawChange = random.nextInt(80) - 40;
            int pitchChange = random.nextInt(40) - 20;
            
            Logger.log("[BehavioralNoise] Adjusting camera view");
            
            // Natural camera movement
            Camera.rotateToYaw(Camera.getYaw() + yawChange);
            Sleep.sleep(100 + random.nextInt(200));
            Camera.rotateToPitch(Camera.getPitch() + pitchChange);
            Sleep.sleep(500 + random.nextInt(1000), 1500 + random.nextInt(1000));
        }
    }
    
    /**
     * Mouse jitter with realistic hand tremor simulation
     */
    private class MouseJitterPattern implements NoisePattern {
        @Override
        public void execute() {
            Point currentPos = Mouse.getPosition();
            int jitterX = random.nextInt(12) - 6;
            int jitterY = random.nextInt(12) - 6;
            
            Point jitteredPos = new Point(currentPos.x + jitterX, currentPos.y + jitterY);
            Mouse.move(jitteredPos);
            Sleep.sleep(10 + random.nextInt(40), 50 + random.nextInt(50));
            Mouse.move(currentPos);
        }
    }
    
    /**
     * Tab switching with realistic navigation patterns
     */
    private class TabSwitchingPattern implements NoisePattern {
        @Override
        public void execute() {
            Tab[] tabs = {Tab.COMBAT, Tab.SKILLS, Tab.QUEST, Tab.EQUIPMENT, Tab.PRAYER, Tab.FRIENDS};
            Tab randomTab = tabs[random.nextInt(tabs.length)];
            
            Logger.log("[BehavioralNoise] Switching to tab: " + randomTab.name());
            
            Tabs.open(randomTab);
            Sleep.sleep(200 + random.nextInt(400), 600 + random.nextInt(400));
            
            // Sometimes switch back
            if (random.nextBoolean()) {
                Sleep.sleep(500 + random.nextInt(1000));
                Tabs.open(Tab.INVENTORY);
            }
        }
    }
    
    /**
     * NPC interaction with realistic examination behavior
     */
    private class NPCInteractionPattern implements NoisePattern {
        @Override
        public void execute() {
            List<NPC> nearbyNPCs = new ArrayList<>(NPCs.all(npc -> 
                npc != null && npc.distance() < 5));
            
            if (!nearbyNPCs.isEmpty()) {
                NPC randomNPC = nearbyNPCs.get(random.nextInt(nearbyNPCs.size()));
                Logger.log("[BehavioralNoise] Interacting with NPC: " + randomNPC.getName());
                
                // TODO: Fix tile to screen conversion for DreamBot API update
                // Mouse.move(Calculations.tileToScreen(randomNPC.getTile()));
                
                Sleep.sleep(300 + random.nextInt(500), 800 + random.nextInt(400));
                
                // Sometimes examine NPC
                if (random.nextDouble() < 0.4) {
                    randomNPC.interact("Examine");
                    Sleep.sleep(800 + random.nextInt(1200), 2000 + random.nextInt(1000));
                }
            }
        }
    }
    
    /**
     * Object examination with realistic interaction patterns
     */
    private class ObjectExaminationPattern implements NoisePattern {
        @Override
        public void execute() {
            List<GameObject> nearbyObjects = new ArrayList<>(GameObjects.all(obj -> 
                obj != null && obj.distance() < 6 && obj.hasAction("Examine")));
            
            if (!nearbyObjects.isEmpty()) {
                GameObject randomObject = nearbyObjects.get(random.nextInt(nearbyObjects.size()));
                Logger.log("[BehavioralNoise] Examining object: " + randomObject.getName());
                
                randomObject.interact("Examine");
                Sleep.sleep(200 + random.nextInt(300), 500 + random.nextInt(300));
            }
        }
    }
    
    /**
     * Combat analysis with realistic battle assessment
     */
    private class CombatAnalysisPattern implements NoisePattern {
        @Override
        public void execute() {
            Player localPlayer = Players.getLocal();
            if (localPlayer != null && localPlayer.isInCombat()) {
                NPC target = null;
                if (localPlayer.getInteractingCharacter() instanceof NPC) {
                    target = (NPC) localPlayer.getInteractingCharacter();
                }
                if (target != null) {
                    Logger.log("[BehavioralNoise] Analyzing combat with: " + target.getName());
                    
                    // TODO: Fix tile to screen conversion for DreamBot API update
                    // Mouse.move(Calculations.tileToScreen(target.getTile()));
                    
                    // Hover over target
                    Sleep.sleep(100 + random.nextInt(200), 300 + random.nextInt(200));
                    
                    // Check combat stats
                    Tabs.open(Tab.COMBAT);
                    Sleep.sleep(150 + random.nextInt(250), 400 + random.nextInt(200));
                    
                    // Check prayer if in combat
                    if (random.nextBoolean()) {
                        Tabs.open(Tab.PRAYER);
                        Sleep.sleep(200 + random.nextInt(300), 500 + random.nextInt(300));
                    }
                }
            }
        }
    }
    
    /**
     * Prayer check with realistic monitoring behavior
     */
    private class PrayerCheckPattern implements NoisePattern {
        @Override
        public void execute() {
            Logger.log("[BehavioralNoise] Checking prayer points");
            
            Tabs.open(Tab.PRAYER);
            Sleep.sleep(200 + random.nextInt(300), 500 + random.nextInt(300));
            
            // Sometimes check equipment after prayer
            if (random.nextBoolean()) {
                Tabs.open(Tab.EQUIPMENT);
                Sleep.sleep(200 + random.nextInt(300), 500 + random.nextInt(300));
            }
        }
    }
    
    /**
     * Equipment check with realistic gear assessment
     */
    private class EquipmentCheckPattern implements NoisePattern {
        @Override
        public void execute() {
            Logger.log("[BehavioralNoise] Checking equipment");
            
            Tabs.open(Tab.EQUIPMENT);
            Sleep.sleep(200 + random.nextInt(300), 500 + random.nextInt(300));
            
            // Sometimes check inventory after equipment
            if (random.nextBoolean()) {
                Tabs.open(Tab.INVENTORY);
                Sleep.sleep(200 + random.nextInt(300), 500 + random.nextInt(300));
            }
        }
    }
    
    /**
     * Chat interaction simulation
     */
    private class ChatInteractionPattern implements NoisePattern {
        @Override
        public void execute() {
            Logger.log("[BehavioralNoise] Simulating chat interaction");
            
            // Simulate reading chat or typing
            Sleep.sleep(500 + random.nextInt(1000), 1000 + random.nextInt(1000));
            
            // Sometimes check friends list
            if (random.nextBoolean()) {
                Tabs.open(Tab.FRIENDS);
                Sleep.sleep(300 + random.nextInt(400), 700 + random.nextInt(500));
            }
        }
    }
    
    /**
     * Minimap interaction with realistic navigation behavior
     */
    private class MinimapInteractionPattern implements NoisePattern {
        @Override
        public void execute() {
            Logger.log("[BehavioralNoise] Interacting with minimap");
            
            // Simulate minimap clicking or examination
            Sleep.sleep(200 + random.nextInt(200), 400 + random.nextInt(200));
            
            // Sometimes adjust camera after minimap interaction
            if (random.nextBoolean()) {
                int yawChange = random.nextInt(40) - 20;
                Camera.rotateToYaw(Camera.getYaw() + yawChange);
            }
        }
    }
    
    /**
     * Interface exploration with realistic widget interaction
     */
    private class InterfaceExplorationPattern implements NoisePattern {
        @Override
        public void execute() {
            Logger.log("[BehavioralNoise] Exploring interface");
            
            // Simulate exploring various interface elements
            Sleep.sleep(300 + random.nextInt(300), 600 + random.nextInt(400));
            
            // Sometimes switch tabs during exploration
            if (random.nextBoolean()) {
                Tab[] tabs = {Tab.SKILLS, Tab.QUEST, Tab.EQUIPMENT};
                Tab randomTab = tabs[random.nextInt(tabs.length)];
                Tabs.open(randomTab);
                Sleep.sleep(200 + random.nextInt(300), 500 + random.nextInt(300));
            }
        }
    }
    
    // --- Data Structures for Event Tracking ---
    
    private static class NoiseEvent {
        final long timestamp;
        final String noiseType;
        final String status;
        
        NoiseEvent(long timestamp, String noiseType, String status) {
            this.timestamp = timestamp;
            this.noiseType = noiseType;
            this.status = status;
        }
    }
    
    private static class BehavioralEvent {
        final long timestamp;
        final String eventType;
        final double intensity;
        
        BehavioralEvent(long timestamp, String eventType, double intensity) {
            this.timestamp = timestamp;
            this.eventType = eventType;
            this.intensity = intensity;
        }
    }
    
    public void performRandomNoise() {
        // Pick a random noise type and execute its pattern
        List<String> keys = new ArrayList<>(noisePatterns.keySet());
        if (!keys.isEmpty()) {
            String randomType = keys.get(random.nextInt(keys.size()));
            NoisePattern pattern = noisePatterns.get(randomType);
            if (pattern != null) pattern.execute();
        }
    }
} 