package antiban;

import org.dreambot.api.utilities.Logger;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Advanced Mouse Heatmap System
 * Tracks mouse movement patterns and generates human-like click distributions
 */
public class MouseHeatmap {
    
    // Heatmap data structure
    private final Map<Point, Integer> clickHeatmap = new ConcurrentHashMap<>();
    private final Map<Point, Integer> moveHeatmap = new ConcurrentHashMap<>();
    private final List<Point> clickHistory = new ArrayList<>();
    private final List<Point> moveHistory = new ArrayList<>();
    
    // Advanced heatmap features
    private final Map<String, HeatmapZone> heatmapZones = new HashMap<>();
    private final List<HeatmapEvent> heatmapEvents = new ArrayList<>();
    private final Queue<Point> recentClicks = new LinkedList<>();
    private final Queue<Point> recentMoves = new LinkedList<>();
    
    // Heatmap analysis
    private final Map<String, Double> clickPatterns = new ConcurrentHashMap<>();
    private final List<Double> clickDensities = new ArrayList<>();
    private final Map<String, Integer> zonePreferences = new HashMap<>();
    
    // Configuration
    private final Random random = ThreadLocalRandom.current();
    private final int heatmapResolution = 10; // Grid size for heatmap
    private final int maxHistorySize = 1000;
    private final double decayRate = 0.95; // Heat decay rate per update
    
    // State tracking
    private long lastHeatmapUpdate = 0;
    private int totalClicks = 0;
    private int totalMoves = 0;
    private Point lastClickPosition = null;
    private Point lastMovePosition = null;
    
    public MouseHeatmap() {
        initializeHeatmapZones();
        
        Logger.log("Mouse heatmap initialized with advanced tracking system");
    }
    
    private void initializeHeatmapZones() {
        // Initialize heatmap zones
        heatmapZones.put("center", new HeatmapZone(new Rectangle(300, 200, 400, 300), 1.0));
        heatmapZones.put("top_left", new HeatmapZone(new Rectangle(0, 0, 300, 200), 0.7));
        heatmapZones.put("top_right", new HeatmapZone(new Rectangle(700, 0, 300, 200), 0.7));
        heatmapZones.put("bottom_left", new HeatmapZone(new Rectangle(0, 500, 300, 200), 0.7));
        heatmapZones.put("bottom_right", new HeatmapZone(new Rectangle(700, 500, 300, 200), 0.7));
        heatmapZones.put("left_side", new HeatmapZone(new Rectangle(0, 200, 200, 300), 0.8));
        heatmapZones.put("right_side", new HeatmapZone(new Rectangle(800, 200, 200, 300), 0.8));
        heatmapZones.put("top_center", new HeatmapZone(new Rectangle(300, 0, 400, 200), 0.9));
        heatmapZones.put("bottom_center", new HeatmapZone(new Rectangle(300, 500, 400, 200), 0.9));
    }
    
    /**
     * Record a click at the specified position
     */
    public void recordClick(Point position) {
        if (position == null) {
            return;
        }
        
        // Add to click heatmap
        Point gridPosition = snapToGrid(position);
        clickHeatmap.put(gridPosition, clickHeatmap.getOrDefault(gridPosition, 0) + 1);
        
        // Add to click history
        clickHistory.add(position);
        if (clickHistory.size() > maxHistorySize) {
            clickHistory.remove(0);
        }
        
        // Add to recent clicks
        recentClicks.offer(position);
        if (recentClicks.size() > 50) {
            recentClicks.poll();
        }
        
        // Update tracking
        lastClickPosition = position;
        totalClicks++;
        
        // Update click patterns
        updateClickPatterns(position);
        
        // Record heatmap event
        recordHeatmapEvent("click", position);
        
        Logger.log("Recorded click at: " + position);
    }
    
    /**
     * Record a mouse move at the specified position
     */
    public void recordMove(Point position) {
        if (position == null) {
            return;
        }
        
        // Add to move heatmap
        Point gridPosition = snapToGrid(position);
        moveHeatmap.put(gridPosition, moveHeatmap.getOrDefault(gridPosition, 0) + 1);
        
        // Add to move history
        moveHistory.add(position);
        if (moveHistory.size() > maxHistorySize) {
            moveHistory.remove(0);
        }
        
        // Add to recent moves
        recentMoves.offer(position);
        if (recentMoves.size() > 100) {
            recentMoves.poll();
        }
        
        // Update tracking
        lastMovePosition = position;
        totalMoves++;
        
        // Record heatmap event
        recordHeatmapEvent("move", position);
    }
    
    /**
     * Get a biased click position within the specified area
     */
    public Point getBiasedClick(Rectangle area) {
        if (area == null || area.width <= 0 || area.height <= 0) {
            return new Point(500, 300); // Default center
        }
        
        // Calculate heatmap influence
        Map<Point, Double> heatmapInfluence = calculateHeatmapInfluence(area);
        
        // Generate biased position
        Point biasedPosition = generateBiasedPosition(area, heatmapInfluence);
        
        // Add human-like variation
        biasedPosition = addHumanVariation(biasedPosition, area);
        
        return biasedPosition;
    }
    
    /**
     * Get a biased click point within the specified area (alias for getBiasedClick)
     */
    public Point getBiasedClickPoint(Rectangle area) {
        return getBiasedClick(area);
    }
    
    /**
     * Calculate heatmap influence for the given area
     */
    private Map<Point, Double> calculateHeatmapInfluence(Rectangle area) {
        Map<Point, Double> influence = new HashMap<>();
        
        // Sample points within the area
        for (int x = area.x; x < area.x + area.width; x += heatmapResolution) {
            for (int y = area.y; y < area.y + area.height; y += heatmapResolution) {
                Point gridPoint = snapToGrid(new Point(x, y));
                
                // Get click heat
                double clickHeat = clickHeatmap.getOrDefault(gridPoint, 0);
                
                // Get move heat (weighted less)
                double moveHeat = moveHeatmap.getOrDefault(gridPoint, 0) * 0.3;
                
                // Calculate total influence
                double totalInfluence = clickHeat + moveHeat;
                
                if (totalInfluence > 0) {
                    influence.put(gridPoint, totalInfluence);
                }
            }
        }
        
        return influence;
    }
    
    /**
     * Generate biased position based on heatmap influence
     */
    private Point generateBiasedPosition(Rectangle area, Map<Point, Double> heatmapInfluence) {
        if (heatmapInfluence.isEmpty()) {
            // No heatmap data, use center with slight random variation
            return new Point(
                area.x + area.width / 2 + random.nextInt(20) - 10,
                area.y + area.height / 2 + random.nextInt(20) - 10
            );
        }
        
        // Calculate total influence
        double totalInfluence = heatmapInfluence.values().stream().mapToDouble(Double::doubleValue).sum();
        
        if (totalInfluence <= 0) {
            // No influence, use center
            return new Point(area.x + area.width / 2, area.y + area.height / 2);
        }
        
        // Generate random value
        double randomValue = random.nextDouble() * totalInfluence;
        double cumulativeInfluence = 0.0;
        
        // Find position based on influence
        for (Map.Entry<Point, Double> entry : heatmapInfluence.entrySet()) {
            cumulativeInfluence += entry.getValue();
            if (randomValue <= cumulativeInfluence) {
                Point gridPoint = entry.getKey();
                return new Point(
                    gridPoint.x + random.nextInt(heatmapResolution),
                    gridPoint.y + random.nextInt(heatmapResolution)
                );
            }
        }
        
        // Fallback to center
        return new Point(area.x + area.width / 2, area.y + area.height / 2);
    }
    
    /**
     * Add human-like variation to the position
     */
    private Point addHumanVariation(Point position, Rectangle area) {
        // Add small random variation
        int variationX = random.nextInt(11) - 5; // -5 to +5
        int variationY = random.nextInt(11) - 5; // -5 to +5
        
        Point variedPosition = new Point(position.x + variationX, position.y + variationY);
        
        // Ensure position is within area bounds
        variedPosition.x = Math.max(area.x, Math.min(area.x + area.width - 1, variedPosition.x));
        variedPosition.y = Math.max(area.y, Math.min(area.y + area.height - 1, variedPosition.y));
        
        return variedPosition;
    }
    
    /**
     * Snap position to grid
     */
    private Point snapToGrid(Point position) {
        int gridX = (position.x / heatmapResolution) * heatmapResolution;
        int gridY = (position.y / heatmapResolution) * heatmapResolution;
        return new Point(gridX, gridY);
    }
    
    /**
     * Update click patterns
     */
    private void updateClickPatterns(Point position) {
        // Update click density
        double density = calculateClickDensity(position);
        clickDensities.add(density);
        if (clickDensities.size() > 100) {
            clickDensities.remove(0);
        }
        
        // Update zone preferences
        String zone = getZoneForPosition(position);
        zonePreferences.put(zone, zonePreferences.getOrDefault(zone, 0) + 1);
        
        // Update click patterns
        if (lastClickPosition != null) {
            double distance = position.distance(lastClickPosition);
            clickPatterns.put("average_distance", 
                (clickPatterns.getOrDefault("average_distance", 0.0) + distance) / 2.0);
        }
    }
    
    /**
     * Calculate click density around position
     */
    private double calculateClickDensity(Point position) {
        int radius = 50;
        int clicksInRadius = 0;
        
        for (Point click : recentClicks) {
            if (position.distance(click) <= radius) {
                clicksInRadius++;
            }
        }
        
        return (double) clicksInRadius / recentClicks.size();
    }
    
    /**
     * Get zone for position
     */
    private String getZoneForPosition(Point position) {
        for (Map.Entry<String, HeatmapZone> entry : heatmapZones.entrySet()) {
            if (entry.getValue().area.contains(position)) {
                return entry.getKey();
            }
        }
        return "unknown";
    }
    
    /**
     * Record heatmap event
     */
    private void recordHeatmapEvent(String eventType, Point position) {
        HeatmapEvent event = new HeatmapEvent(
            System.currentTimeMillis(),
            eventType,
            position,
            getZoneForPosition(position)
        );
        
        heatmapEvents.add(event);
        if (heatmapEvents.size() > 500) {
            heatmapEvents.remove(0);
        }
    }
    
    /**
     * Update heatmap (decay old data)
     */
    public void updateHeatmap() {
        long currentTime = System.currentTimeMillis();
        
        if (currentTime - lastHeatmapUpdate < 60000) { // Update every minute
            return;
        }
        
        lastHeatmapUpdate = currentTime;
        
        // Decay click heatmap
        for (Map.Entry<Point, Integer> entry : clickHeatmap.entrySet()) {
            int newValue = (int)(entry.getValue() * decayRate);
            if (newValue > 0) {
                clickHeatmap.put(entry.getKey(), newValue);
            } else {
                clickHeatmap.remove(entry.getKey());
            }
        }
        
        // Decay move heatmap
        for (Map.Entry<Point, Integer> entry : moveHeatmap.entrySet()) {
            int newValue = (int)(entry.getValue() * decayRate);
            if (newValue > 0) {
                moveHeatmap.put(entry.getKey(), newValue);
            } else {
                moveHeatmap.remove(entry.getKey());
            }
        }
        
        Logger.log("Heatmap updated - decayed old data");
    }
    
    /**
     * Get click heatmap
     */
    public Map<Point, Integer> getClickHeatmap() {
        return new HashMap<>(clickHeatmap);
    }
    
    /**
     * Get move heatmap
     */
    public Map<Point, Integer> getMoveHeatmap() {
        return new HashMap<>(moveHeatmap);
    }
    
    /**
     * Get click history
     */
    public List<Point> getClickHistory() {
        return new ArrayList<>(clickHistory);
    }
    
    /**
     * Get move history
     */
    public List<Point> getMoveHistory() {
        return new ArrayList<>(moveHistory);
    }
    
    /**
     * Get total clicks
     */
    public int getTotalClicks() {
        return totalClicks;
    }
    
    /**
     * Get total moves
     */
    public int getTotalMoves() {
        return totalMoves;
    }
    
    /**
     * Get last click position
     */
    public Point getLastClickPosition() {
        return lastClickPosition;
    }
    
    /**
     * Get last move position
     */
    public Point getLastMovePosition() {
        return lastMovePosition;
    }
    
    /**
     * Get click patterns
     */
    public Map<String, Double> getClickPatterns() {
        return new HashMap<>(clickPatterns);
    }
    
    /**
     * Get zone preferences
     */
    public Map<String, Integer> getZonePreferences() {
        return new HashMap<>(zonePreferences);
    }
    
    /**
     * Get heatmap statistics
     */
    public Map<String, Object> getHeatmapStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalClicks", totalClicks);
        stats.put("totalMoves", totalMoves);
        stats.put("clickHeatmapSize", clickHeatmap.size());
        stats.put("moveHeatmapSize", moveHeatmap.size());
        stats.put("clickHistorySize", clickHistory.size());
        stats.put("moveHistorySize", moveHistory.size());
        stats.put("averageClickDistance", clickPatterns.getOrDefault("average_distance", 0.0));
        stats.put("preferredZone", getPreferredZone());
        
        return stats;
    }
    
    /**
     * Get preferred zone
     */
    private String getPreferredZone() {
        return zonePreferences.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey)
            .orElse("unknown");
    }
    
    // Heatmap zone class
    private static class HeatmapZone {
        final Rectangle area;
        final double weight;
        
        HeatmapZone(Rectangle area, double weight) {
            this.area = area;
            this.weight = weight;
        }
    }
    
    // Heatmap event class
    private static class HeatmapEvent {
        final long timestamp;
        final String eventType;
        final Point position;
        final String zone;
        
        HeatmapEvent(long timestamp, String eventType, Point position, String zone) {
            this.timestamp = timestamp;
            this.eventType = eventType;
            this.position = position;
            this.zone = zone;
        }
    }
} 