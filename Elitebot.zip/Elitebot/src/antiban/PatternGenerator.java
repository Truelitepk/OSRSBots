package antiban;

import org.dreambot.api.utilities.Logger;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class PatternGenerator {
    
    private final Random random = ThreadLocalRandom.current();
    
    // Pattern characteristics
    private final Map<String, Double> patternWeights = new HashMap<>();
    private final List<String> patternHistory = new ArrayList<>();
    private final Map<String, Integer> patternFrequency = new HashMap<>();
    
    // Advanced pattern generation
    private final Map<String, List<String>> patternSequences = new HashMap<>();
    private final Queue<PatternEvent> patternEvents = new LinkedList<>();
    
    // Pattern evolution
    private int evolutionCounter;
    private final Map<String, Double> evolutionFactors = new HashMap<>();
    
    // Behavioral state
    private String currentPattern;
    private long lastPatternChange;
    private int patternDuration;
    
    public PatternGenerator() {
        initializePatternWeights();
        initializePatternSequences();
        initializeEvolutionFactors();
        
        Logger.log("Pattern generator initialized with behavioral pattern weights");
    }
    
    private void initializePatternWeights() {
        // Initialize pattern weights (probabilities)
        patternWeights.put("MICRO_PAUSE", 0.25);
        patternWeights.put("SKILL_CHECK", 0.20);
        patternWeights.put("ENVIRONMENTAL_INTERACTION", 0.15);
        patternWeights.put("COMBAT_ANALYSIS", 0.15);
        patternWeights.put("INVENTORY_MANAGEMENT", 0.15);
        patternWeights.put("CAMERA_MANIPULATION", 0.10);
        
        // Initialize pattern frequency tracking
        for (String pattern : patternWeights.keySet()) {
            patternFrequency.put(pattern, 0);
        }
    }
    
    private void initializePatternSequences() {
        // Define natural pattern sequences
        patternSequences.put("SKILL_CHECK", Arrays.asList("INVENTORY_MANAGEMENT", "CAMERA_MANIPULATION"));
        patternSequences.put("COMBAT_ANALYSIS", Arrays.asList("MICRO_PAUSE", "ENVIRONMENTAL_INTERACTION"));
        patternSequences.put("INVENTORY_MANAGEMENT", Arrays.asList("SKILL_CHECK", "MICRO_PAUSE"));
        patternSequences.put("ENVIRONMENTAL_INTERACTION", Arrays.asList("CAMERA_MANIPULATION", "MICRO_PAUSE"));
        patternSequences.put("CAMERA_MANIPULATION", Arrays.asList("ENVIRONMENTAL_INTERACTION", "SKILL_CHECK"));
        patternSequences.put("MICRO_PAUSE", Arrays.asList("COMBAT_ANALYSIS", "INVENTORY_MANAGEMENT"));
    }
    
    private void initializeEvolutionFactors() {
        evolutionFactors.put("pattern_stability", 0.8 + random.nextDouble() * 0.2);
        evolutionFactors.put("sequence_preference", 0.3 + random.nextDouble() * 0.4);
        evolutionFactors.put("randomization_rate", 0.1 + random.nextDouble() * 0.2);
        evolutionFactors.put("adaptation_speed", 0.05 + random.nextDouble() * 0.1);
    }
    
    public String generatePattern() {
        // Check if we should continue current pattern
        if (shouldContinueCurrentPattern()) {
            return currentPattern;
        }
        
        // Generate new pattern
        String newPattern = selectPattern();
        
        // Update pattern state
        currentPattern = newPattern;
        lastPatternChange = System.currentTimeMillis();
        patternDuration = calculatePatternDuration(newPattern);
        
        // Update pattern history
        patternHistory.add(newPattern);
        if (patternHistory.size() > 100) {
            patternHistory.remove(0);
        }
        
        // Update frequency
        patternFrequency.put(newPattern, patternFrequency.get(newPattern) + 1);
        
        // Record pattern event
        PatternEvent event = new PatternEvent(
            System.currentTimeMillis(),
            newPattern,
            "pattern_generated"
        );
        patternEvents.offer(event);
        
        // Evolve patterns
        evolvePatterns();
        
        // Increment evolution counter
        evolutionCounter++;
        
        Logger.log("Generated pattern: " + newPattern);
        return newPattern;
    }
    
    private boolean shouldContinueCurrentPattern() {
        if (currentPattern == null) {
            return false;
        }
        
        long timeSinceChange = System.currentTimeMillis() - lastPatternChange;
        boolean withinDuration = timeSinceChange < patternDuration;
        
        // Add some randomness to pattern continuation
        double continuationChance = 0.7 + random.nextDouble() * 0.2;
        
        return withinDuration && random.nextDouble() < continuationChance;
    }
    
    private String selectPattern() {
        // Check for sequence-based patterns
        if (currentPattern != null && random.nextDouble() < evolutionFactors.get("sequence_preference")) {
            String sequencePattern = selectSequencePattern();
            if (sequencePattern != null) {
                return sequencePattern;
            }
        }
        
        // Weighted random selection with evolution
        List<String> availablePatterns = new ArrayList<>(patternWeights.keySet());
        List<Double> weights = new ArrayList<>();
        
        for (String pattern : availablePatterns) {
            double baseWeight = patternWeights.get(pattern);
            double evolutionWeight = getEvolutionWeight(pattern);
            double frequencyWeight = getFrequencyWeight(pattern);
            
            double finalWeight = baseWeight * evolutionWeight * frequencyWeight;
            weights.add(finalWeight);
        }
        
        // Normalize weights
        double totalWeight = weights.stream().mapToDouble(Double::doubleValue).sum();
        for (int i = 0; i < weights.size(); i++) {
            weights.set(i, weights.get(i) / totalWeight);
        }
        
        // Select pattern based on weights
        double randomValue = random.nextDouble();
        double cumulativeWeight = 0.0;
        
        for (int i = 0; i < availablePatterns.size(); i++) {
            cumulativeWeight += weights.get(i);
            if (randomValue <= cumulativeWeight) {
                return availablePatterns.get(i);
            }
        }
        
        // Fallback
        return availablePatterns.get(random.nextInt(availablePatterns.size()));
    }
    
    private String selectSequencePattern() {
        if (currentPattern == null || !patternSequences.containsKey(currentPattern)) {
            return null;
        }
        
        List<String> sequence = patternSequences.get(currentPattern);
        return sequence.get(random.nextInt(sequence.size()));
    }
    
    private double getEvolutionWeight(String pattern) {
        // Evolution affects pattern selection
        double baseWeight = 1.0;
        
        // Recent patterns get reduced weight
        int recentCount = 0;
        for (int i = Math.max(0, patternHistory.size() - 10); i < patternHistory.size(); i++) {
            if (patternHistory.get(i).equals(pattern)) {
                recentCount++;
            }
        }
        
        double recentPenalty = 1.0 - (recentCount * 0.1);
        baseWeight *= Math.max(0.3, recentPenalty);
        
        // Evolution factor influence
        double evolutionInfluence = Math.sin(evolutionCounter * 0.01) * 0.2;
        baseWeight *= (1.0 + evolutionInfluence);
        
        return baseWeight;
    }
    
    private double getFrequencyWeight(String pattern) {
        // Frequency affects pattern selection (avoid overuse)
        int frequency = patternFrequency.get(pattern);
        double frequencyWeight = 1.0 / (1.0 + frequency * 0.1);
        
        return Math.max(0.2, frequencyWeight);
    }
    
    private int calculatePatternDuration(String pattern) {
        // Calculate how long a pattern should last
        int baseDuration = 1000 + random.nextInt(2000); // 1-3 seconds
        
        switch (pattern) {
            case "MICRO_PAUSE":
                return 500 + random.nextInt(1000); // 0.5-1.5 seconds
            case "SKILL_CHECK":
                return 1500 + random.nextInt(2000); // 1.5-3.5 seconds
            case "ENVIRONMENTAL_INTERACTION":
                return 2000 + random.nextInt(3000); // 2-5 seconds
            case "COMBAT_ANALYSIS":
                return 1000 + random.nextInt(1500); // 1-2.5 seconds
            case "INVENTORY_MANAGEMENT":
                return 1200 + random.nextInt(1800); // 1.2-3 seconds
            case "CAMERA_MANIPULATION":
                return 800 + random.nextInt(1200); // 0.8-2 seconds
            default:
                return baseDuration;
        }
    }
    
    private void evolvePatterns() {
        // Evolutionary changes to pattern weights
        for (Map.Entry<String, Double> entry : patternWeights.entrySet()) {
            String pattern = entry.getKey();
            double currentWeight = entry.getValue();
            
            // Gradual evolution
            double evolution = (random.nextDouble() - 0.5) * evolutionFactors.get("adaptation_speed");
            double newWeight = currentWeight + evolution;
            
            // Ensure reasonable bounds
            newWeight = Math.max(0.05, Math.min(0.5, newWeight));
            patternWeights.put(pattern, newWeight);
        }
        
        // Major evolution events (rare)
        if (random.nextInt(5000) < 10) {
            Logger.log("Major pattern evolution triggered");
            triggerMajorPatternEvolution();
        }
    }
    
    private void triggerMajorPatternEvolution() {
        // Significant pattern weight changes
        String[] patterns = patternWeights.keySet().toArray(new String[0]);
        String targetPattern = patterns[random.nextInt(patterns.length)];
        
        double currentWeight = patternWeights.get(targetPattern);
        double evolution = (random.nextDouble() - 0.5) * 0.3; // Larger change
        double newWeight = Math.max(0.05, Math.min(0.5, currentWeight + evolution));
        
        patternWeights.put(targetPattern, newWeight);
        
        // Record evolution event
        PatternEvent event = new PatternEvent(
            System.currentTimeMillis(),
            targetPattern,
            "major_evolution"
        );
        patternEvents.offer(event);
    }
    
    public void randomizePatterns() {
        Logger.log("Randomizing pattern weights");
        
        // Randomize pattern weights
        for (Map.Entry<String, Double> entry : patternWeights.entrySet()) {
            String pattern = entry.getKey();
            double newWeight = 0.1 + random.nextDouble() * 0.4; // 0.1 - 0.5
            patternWeights.put(pattern, newWeight);
        }
        
        // Clear pattern history
        patternHistory.clear();
        patternFrequency.clear();
        
        // Reinitialize frequency tracking
        for (String pattern : patternWeights.keySet()) {
            patternFrequency.put(pattern, 0);
        }
    }
    
    public void addCustomPattern(String patternName, double weight) {
        patternWeights.put(patternName, weight);
        patternFrequency.put(patternName, 0);
        Logger.log("Added custom pattern: " + patternName + " with weight: " + weight);
    }
    
    public void removePattern(String patternName) {
        patternWeights.remove(patternName);
        patternFrequency.remove(patternName);
        patternSequences.remove(patternName);
        Logger.log("Removed pattern: " + patternName);
    }
    
    // Getters for external access
    public String getCurrentPattern() { return currentPattern; }
    public Map<String, Double> getPatternWeights() { return new HashMap<>(patternWeights); }
    public Map<String, Integer> getPatternFrequency() { return new HashMap<>(patternFrequency); }
    public List<String> getPatternHistory() { return new ArrayList<>(patternHistory); }
    public int getEvolutionCounter() { return evolutionCounter; }
    
    // Inner class for pattern events
    private static class PatternEvent {
        final long timestamp;
        final String pattern;
        final String type;
        
        PatternEvent(long timestamp, String pattern, String type) {
            this.timestamp = timestamp;
            this.pattern = pattern;
            this.type = type;
        }
    }
    
    public void performPatternBreak() {
        // Randomize patterns as a way to break predictable behavior
        randomizePatterns();
    }
} 