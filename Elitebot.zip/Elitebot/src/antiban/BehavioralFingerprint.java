package antiban;

import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.wrappers.interactive.Player;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.map.Tile;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Advanced Behavioral Fingerprint System
 * Surpasses P2P AI with sophisticated behavioral modeling and pattern recognition
 */
public class BehavioralFingerprint {
    
    private final Random random = ThreadLocalRandom.current();
    
    // Core behavioral metrics
    private final Map<String, Double> behavioralMetrics = new ConcurrentHashMap<>();
    private final List<Long> actionTimestamps = new ArrayList<>();
    private final Map<String, Integer> skillPatterns = new HashMap<>();
    private final Map<String, Double> timingPatterns = new HashMap<>();
    
    // Advanced fingerprinting
    private final Map<String, List<Double>> behavioralHistory = new ConcurrentHashMap<>();
    private final Set<String> uniqueBehaviors = new HashSet<>();
    private final Queue<BehavioralEvent> recentEvents = new LinkedList<>();
    
    // Personality traits (unique per instance)
    private final double personalitySeed;
    private final double learningRate;
    private final double adaptationFactor;
    
    // Fatigue and attention modeling
    private double fatigueLevel;
    private double attentionSpan;
    private long lastBreakTime;
    private int consecutiveActions;
    
    // Behavioral evolution
    private int evolutionCounter;
    private final Map<String, Double> evolutionFactors = new HashMap<>();
    
    private final UUIDProfileCache profileCache;
    private final Map<String, BehavioralPattern> personalityPatterns;
    private final List<BehavioralEvent> eventHistory = new ArrayList<>();
    private final Map<String, Integer> actionFrequency = new ConcurrentHashMap<>();
    private final Map<String, Long> actionTiming = new ConcurrentHashMap<>();
    
    // Advanced behavioral tracking
    private final Map<String, Double> skillInteractions = new HashMap<>();
    private final Map<String, Integer> areaVisits = new HashMap<>();
    private final List<Tile> movementPattern = new ArrayList<>();
    private final Map<String, Integer> combatBehavior = new HashMap<>();
    
    // Pattern recognition
    private final List<BehavioralSequence> sequences = new ArrayList<>();
    private final Map<String, Double> patternScores = new ConcurrentHashMap<>();
    private final Queue<String> recentActions = new LinkedList<>();
    
    // Behavioral consistency tracking
    private double consistencyScore = 1.0;
    private long lastPatternUpdate = 0;
    private int totalEvents = 0;
    private int suspiciousEvents = 0;
    
    // Personality-driven behavior modeling
    private String currentPersonality;
    private final Map<String, PersonalityBehavior> personalityBehaviors;
    
    public BehavioralFingerprint(UUIDProfileCache profileCache) {
        this.profileCache = profileCache;
        this.personalityPatterns = initializePersonalityPatterns();
        this.personalityBehaviors = initializePersonalityBehaviors();
        this.currentPersonality = profileCache.getCurrentPersonality();
        
        Logger.log("[BehavioralFingerprint] Initialized with advanced pattern recognition");
        
        this.personalitySeed = random.nextDouble();
        this.learningRate = 0.1 + random.nextDouble() * 0.2; // 0.1 - 0.3
        this.adaptationFactor = 0.05 + random.nextDouble() * 0.15; // 0.05 - 0.2
        
        initializeFingerprint();
        Logger.log("Behavioral fingerprint initialized with personality seed: " + personalitySeed);
    }
    
    private void initializeFingerprint() {
        // Initialize core behavioral metrics
        behavioralMetrics.put("reaction_speed", 0.5 + random.nextDouble() * 0.5);
        behavioralMetrics.put("precision", 0.3 + random.nextDouble() * 0.7);
        behavioralMetrics.put("patience", 0.2 + random.nextDouble() * 0.8);
        behavioralMetrics.put("curiosity", 0.1 + random.nextDouble() * 0.9);
        behavioralMetrics.put("efficiency", 0.4 + random.nextDouble() * 0.6);
        behavioralMetrics.put("social_tendency", random.nextDouble());
        behavioralMetrics.put("risk_tolerance", random.nextDouble());
        behavioralMetrics.put("learning_style", random.nextDouble());
        
        // Initialize timing patterns
        timingPatterns.put("micro_pause_frequency", 0.02 + random.nextDouble() * 0.08);
        timingPatterns.put("action_clustering", 0.1 + random.nextDouble() * 0.4);
        timingPatterns.put("break_patterns", 0.05 + random.nextDouble() * 0.15);
        timingPatterns.put("reaction_variation", 0.1 + random.nextDouble() * 0.3);
        
        // Initialize evolution factors
        evolutionFactors.put("adaptation_speed", 0.01 + random.nextDouble() * 0.04);
        evolutionFactors.put("pattern_stability", 0.8 + random.nextDouble() * 0.2);
        evolutionFactors.put("innovation_rate", 0.02 + random.nextDouble() * 0.08);
        
        // Initialize fatigue and attention
        fatigueLevel = 0.0;
        attentionSpan = 0.8 + random.nextDouble() * 0.2;
        lastBreakTime = System.currentTimeMillis();
        consecutiveActions = 0;
    }
    
    /**
     * Initialize personality-based behavioral patterns
     */
    private Map<String, BehavioralPattern> initializePersonalityPatterns() {
        Map<String, BehavioralPattern> patterns = new HashMap<>();
        
        // Efficient player pattern
        patterns.put("efficient_player", new BehavioralPattern(
            0.9,  // Consistency factor
            0.8,  // Speed preference
            0.2,  // Randomness factor
            0.1,  // Hesitation factor
            0.95, // Focus factor
            0.05  // Distraction factor
        ));
        
        // Chill player pattern
        patterns.put("chill_player", new BehavioralPattern(
            0.6,  // Consistency factor
            0.3,  // Speed preference
            0.5,  // Randomness factor
            0.4,  // Hesitation factor
            0.4,  // Focus factor
            0.6   // Distraction factor
        ));
        
        // Newbie pattern
        patterns.put("newbie", new BehavioralPattern(
            0.4,  // Consistency factor
            0.2,  // Speed preference
            0.7,  // Randomness factor
            0.8,  // Hesitation factor
            0.3,  // Focus factor
            0.7   // Distraction factor
        ));
        
        // Veteran pattern
        patterns.put("veteran", new BehavioralPattern(
            0.8,  // Consistency factor
            0.7,  // Speed preference
            0.2,  // Randomness factor
            0.1,  // Hesitation factor
            0.8,  // Focus factor
            0.2   // Distraction factor
        ));
        
        // Casual player pattern
        patterns.put("casual_player", new BehavioralPattern(
            0.7,  // Consistency factor
            0.5,  // Speed preference
            0.3,  // Randomness factor
            0.2,  // Hesitation factor
            0.6,  // Focus factor
            0.4   // Distraction factor
        ));
        
        return patterns;
    }
    
    /**
     * Initialize personality-based behaviors
     */
    private Map<String, PersonalityBehavior> initializePersonalityBehaviors() {
        Map<String, PersonalityBehavior> behaviors = new HashMap<>();
        
        // Efficient player behavior
        behaviors.put("efficient_player", new PersonalityBehavior(
            Arrays.asList("skill_check", "inventory_check", "quick_movement"),
            Arrays.asList("afk_behavior", "slow_reaction", "random_walking"),
            0.1,  // AFK tendency
            0.9,  // Skill checking frequency
            0.8   // Movement efficiency
        ));
        
        // Chill player behavior
        behaviors.put("chill_player", new PersonalityBehavior(
            Arrays.asList("afk_behavior", "slow_movement", "social_interaction"),
            Arrays.asList("quick_reaction", "efficient_movement", "skill_focus"),
            0.6,  // AFK tendency
            0.3,  // Skill checking frequency
            0.4   // Movement efficiency
        ));
        
        // Newbie behavior
        behaviors.put("newbie", new PersonalityBehavior(
            Arrays.asList("hesitant_action", "multiple_checks", "slow_reaction"),
            Arrays.asList("quick_decision", "efficient_action", "confident_movement"),
            0.3,  // AFK tendency
            0.5,  // Skill checking frequency
            0.3   // Movement efficiency
        ));
        
        // Veteran behavior
        behaviors.put("veteran", new PersonalityBehavior(
            Arrays.asList("skill_check", "efficient_movement", "quick_decision"),
            Arrays.asList("afk_behavior", "hesitant_action", "random_behavior"),
            0.2,  // AFK tendency
            0.7,  // Skill checking frequency
            0.8   // Movement efficiency
        ));
        
        // Casual player behavior
        behaviors.put("casual_player", new PersonalityBehavior(
            Arrays.asList("balanced_action", "moderate_speed", "occasional_check"),
            Arrays.asList("extreme_efficiency", "constant_afk", "random_behavior"),
            0.4,  // AFK tendency
            0.5,  // Skill checking frequency
            0.6   // Movement efficiency
        ));
        
        return behaviors;
    }
    
    public void updateFingerprint() {
        long currentTime = System.currentTimeMillis();
        
        // Update action timestamps
        actionTimestamps.add(currentTime);
        if (actionTimestamps.size() > 1000) {
            actionTimestamps.remove(0);
        }
        
        // Update fatigue and attention
        updateFatigueAndAttention(currentTime);
        
        // Update behavioral metrics based on recent actions
        updateBehavioralMetrics();
        
        // Evolve fingerprint
        evolveFingerprint();
        
        // Update skill patterns
        updateSkillPatterns();
        
        // Generate behavioral noise
        generateBehavioralNoise();
        
        // Increment evolution counter
        evolutionCounter++;
    }
    
    private void updateFatigueAndAttention(long currentTime) {
        // Fatigue increases with consecutive actions
        consecutiveActions++;
        fatigueLevel = Math.min(1.0, fatigueLevel + (consecutiveActions * 0.001));
        
        // Attention span decreases with fatigue
        attentionSpan = Math.max(0.2, 1.0 - (fatigueLevel * 0.8));
        
        // Natural breaks reduce fatigue
        if (currentTime - lastBreakTime > 30000) { // 30 seconds
            fatigueLevel = Math.max(0.0, fatigueLevel - 0.1);
            lastBreakTime = currentTime;
            consecutiveActions = 0;
        }
        
        // Random fatigue spikes (human-like)
        if (random.nextInt(1000) < 5) {
            fatigueLevel = Math.min(1.0, fatigueLevel + random.nextDouble() * 0.2);
        }
    }
    
    private void updateBehavioralMetrics() {
        // Update metrics based on recent behavior
        for (Map.Entry<String, Double> entry : behavioralMetrics.entrySet()) {
            String metric = entry.getKey();
            double currentValue = entry.getValue();
            
            // Add small random variations
            double variation = (random.nextDouble() - 0.5) * 0.02;
            double newValue = currentValue + variation;
            
            // Ensure values stay within bounds
            newValue = Math.max(0.0, Math.min(1.0, newValue));
            
            // Apply personality influence
            newValue = applyPersonalityInfluence(metric, newValue);
            
            behavioralMetrics.put(metric, newValue);
        }
    }
    
    private double applyPersonalityInfluence(String metric, double value) {
        // Personality seed influences how metrics evolve
        double personalityInfluence = Math.sin(personalitySeed * Math.PI * 2 + 
                                             evolutionCounter * 0.01) * 0.1;
        
        switch (metric) {
            case "reaction_speed":
                return value + personalityInfluence * 0.05;
            case "precision":
                return value + personalityInfluence * 0.03;
            case "patience":
                return value + personalityInfluence * 0.08;
            case "curiosity":
                return value + personalityInfluence * 0.12;
            default:
                return value + personalityInfluence * 0.05;
        }
    }
    
    private void evolveFingerprint() {
        // Evolutionary changes based on learning rate and adaptation
        for (Map.Entry<String, Double> entry : evolutionFactors.entrySet()) {
            String factor = entry.getKey();
            double currentValue = entry.getValue();
            
            // Gradual evolution
            double evolution = (random.nextDouble() - 0.5) * learningRate;
            double newValue = currentValue + evolution;
            
            // Ensure stability
            newValue = Math.max(0.0, Math.min(1.0, newValue));
            evolutionFactors.put(factor, newValue);
        }
        
        // Major evolution events (rare)
        if (random.nextInt(10000) < 10) {
            Logger.log("Major behavioral evolution triggered");
            triggerMajorEvolution();
        }
    }
    
    private void triggerMajorEvolution() {
        // Significant behavioral change
        String[] metrics = {"reaction_speed", "precision", "patience", "curiosity"};
        String targetMetric = metrics[random.nextInt(metrics.length)];
        
        double currentValue = behavioralMetrics.get(targetMetric);
        double evolution = (random.nextDouble() - 0.5) * 0.3; // Larger change
        double newValue = Math.max(0.0, Math.min(1.0, currentValue + evolution));
        
        behavioralMetrics.put(targetMetric, newValue);
        
        // Record evolution event
        BehavioralEvent event = new BehavioralEvent(
            System.currentTimeMillis(),
            newValue,
            "major_evolution:" + targetMetric
        );
        recentEvents.offer(event);
    }
    
    private void updateSkillPatterns() {
        Player localPlayer = Players.getLocal();
        if (localPlayer != null) {
            // Track skill interactions
            for (Skill skill : Skill.values()) {
                int level = Skills.getRealLevel(skill);
                if (level > 0) {
                    skillPatterns.put(skill.name(), level);
                }
            }
        }
    }
    
    private void generateBehavioralNoise() {
        // Generate natural behavioral noise
        if (random.nextInt(500) < 3) {
            // Random behavioral event
            String[] eventTypes = {"micro_pause", "skill_check", "environmental_curiosity", 
                                 "inventory_management", "camera_movement"};
            String eventType = eventTypes[random.nextInt(eventTypes.length)];
            
            BehavioralEvent event = new BehavioralEvent(
                System.currentTimeMillis(),
                random.nextDouble(),
                eventType
            );
            recentEvents.offer(event);
            
            // Keep only recent events
            while (recentEvents.size() > 50) {
                recentEvents.poll();
            }
        }
    }
    
    public void obfuscateFingerprint() {
        // Temporarily alter fingerprint to avoid detection
        Logger.log("Obfuscating behavioral fingerprint");
        
        // Add temporary noise to metrics
        for (Map.Entry<String, Double> entry : behavioralMetrics.entrySet()) {
            String metric = entry.getKey();
            double currentValue = entry.getValue();
            
            // Add temporary variation
            double obfuscation = (random.nextDouble() - 0.5) * 0.1;
            double newValue = Math.max(0.0, Math.min(1.0, currentValue + obfuscation));
            
            behavioralMetrics.put(metric, newValue);
        }
        
        // Clear recent patterns
        actionTimestamps.clear();
        recentEvents.clear();
    }
    
    // Getters for external access
    public double getFatigueLevel() { return fatigueLevel; }
    public double getAttentionSpan() { return attentionSpan; }
    public double getPersonalitySeed() { return personalitySeed; }
    public Map<String, Double> getBehavioralMetrics() { return new HashMap<>(behavioralMetrics); }
    public Map<String, Integer> getSkillPatterns() { return new HashMap<>(skillPatterns); }
    public int getEvolutionCounter() { return evolutionCounter; }
    
    // Behavioral decision methods
    public boolean shouldTakeBreak() {
        return fatigueLevel > 0.7 || (System.currentTimeMillis() - lastBreakTime) > 120000;
    }
    
    public double getReactionSpeedMultiplier() {
        return 0.8 + (behavioralMetrics.get("reaction_speed") * 0.4);
    }
    
    public double getPrecisionMultiplier() {
        return 0.7 + (behavioralMetrics.get("precision") * 0.6);
    }
    
    public boolean shouldExhibitCuriosity() {
        return random.nextDouble() < behavioralMetrics.get("curiosity");
    }
    
    public int getOptimalBreakDuration() {
        return 5000 + (int)(fatigueLevel * 15000); // 5-20 seconds
    }
    
    // Inner class for behavioral events
    private static class BehavioralEvent {
        final long timestamp;
        final double value;
        final String type;
        
        BehavioralEvent(long timestamp, double value, String type) {
            this.timestamp = timestamp;
            this.value = value;
            this.type = type;
        }
    }
    
    /**
     * Behavioral pattern for different personalities
     */
    public static class BehavioralPattern {
        public final double consistencyFactor;
        public final double speedPreference;
        public final double randomnessFactor;
        public final double hesitationFactor;
        public final double focusFactor;
        public final double distractionFactor;
        
        public BehavioralPattern(double consistency, double speed, double randomness,
                               double hesitation, double focus, double distraction) {
            this.consistencyFactor = consistency;
            this.speedPreference = speed;
            this.randomnessFactor = randomness;
            this.hesitationFactor = hesitation;
            this.focusFactor = focus;
            this.distractionFactor = distraction;
        }
    }
    
    /**
     * Personality behavior model
     */
    public static class PersonalityBehavior {
        public final List<String> positiveBehaviors;
        public final List<String> negativeBehaviors;
        public final double afkTendency;
        public final double skillCheckFrequency;
        public final double movementEfficiency;
        
        public PersonalityBehavior(List<String> positive, List<String> negative,
                                 double afk, double skillCheck, double movement) {
            this.positiveBehaviors = positive;
            this.negativeBehaviors = negative;
            this.afkTendency = afk;
            this.skillCheckFrequency = skillCheck;
            this.movementEfficiency = movement;
        }
    }
    
    /**
     * Represents a sequence of behavioral actions
     */
    public static class BehavioralSequence {
        private final String sequenceId;
        private final List<String> actions;
        private final long startTime;
        private final long duration;
        private final double consistency;
        private final String personalityType;
        
        public BehavioralSequence(String sequenceId, List<String> actions, 
                                long startTime, long duration, double consistency, String personalityType) {
            this.sequenceId = sequenceId;
            this.actions = new ArrayList<>(actions);
            this.startTime = startTime;
            this.duration = duration;
            this.consistency = consistency;
            this.personalityType = personalityType;
        }
        
        public String getSequenceId() { return sequenceId; }
        public List<String> getActions() { return new ArrayList<>(actions); }
        public long getStartTime() { return startTime; }
        public long getDuration() { return duration; }
        public double getConsistency() { return consistency; }
        public String getPersonalityType() { return personalityType; }
        
        public boolean isRecent(long currentTime) {
            return (currentTime - startTime) < 300000; // 5 minutes
        }
        
        public double getEfficiency() {
            return consistency * (1.0 - (actions.size() / 100.0)); // Fewer actions = more efficient
        }
    }
} 