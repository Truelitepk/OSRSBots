package antiban;

import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class QuestAndAchievementSystem {
    
    private final Random random = ThreadLocalRandom.current();
    private final ExecutorService executorService = Executors.newCachedThreadPool();
    
    // Quest and achievement data
    private final Map<String, Quest> quests = new ConcurrentHashMap<>();
    private final Map<String, Achievement> achievements = new ConcurrentHashMap<>();
    private final Map<String, Diary> diaries = new ConcurrentHashMap<>();
    private final Map<String, CollectionLogItem> collectionLog = new ConcurrentHashMap<>();
    
    // Progress tracking
    private final Map<String, QuestProgress> questProgress = new ConcurrentHashMap<>();
    private final Map<String, AchievementProgress> achievementProgress = new ConcurrentHashMap<>();
    private final Map<String, DiaryProgress> diaryProgress = new ConcurrentHashMap<>();
    private final List<QuestSession> questSessions = new ArrayList<>();
    
    // State tracking
    private boolean questSystemEnabled = true;
    private boolean achievementSystemEnabled = true;
    private boolean diarySystemEnabled = true;
    private boolean collectionLogEnabled = true;
    private double questIntensity = 0.6;
    private long lastQuestActivity;
    private int totalQuestsCompleted;
    private int totalAchievementsUnlocked;
    
    // Configuration
    private static final long QUEST_SESSION_TIME = 1800000; // 30 minutes
    private static final long ACHIEVEMENT_CHECK_INTERVAL = 900000; // 15 minutes
    private static final long DIARY_CHECK_INTERVAL = 1200000; // 20 minutes
    
    public QuestAndAchievementSystem() {
        initializeQuests();
        initializeAchievements();
        initializeDiaries();
        initializeCollectionLog();
        
        Logger.log("Quest and Achievement System initialized");
    }
    
    private void initializeQuests() {
        // Free-to-play quests
        quests.put("cook's_assistant", new Quest("Cook's Assistant", "Free", 1, "Cooking", Arrays.asList("Cooking", "Farming")));
        quests.put("demon_slayer", new Quest("Demon Slayer", "Free", 1, "Combat", Arrays.asList("Combat", "Prayer")));
        quests.put("dragon_slayer", new Quest("Dragon Slayer", "Free", 32, "Combat", Arrays.asList("Combat", "Prayer", "Magic")));
        quests.put("ernest_the_chicken", new Quest("Ernest the Chicken", "Free", 1, "Puzzle", Arrays.asList("Thieving")));
        quests.put("goblin_diplomacy", new Quest("Goblin Diplomacy", "Free", 1, "Diplomacy", Arrays.asList("Crafting")));
        quests.put("imp_catcher", new Quest("Imp Catcher", "Free", 1, "Collecting", Arrays.asList("Magic")));
        quests.put("the_knight's_sword", new Quest("The Knight's Sword", "Free", 10, "Smithing", Arrays.asList("Smithing", "Mining")));
        quests.put("pirate's_treasure", new Quest("Pirate's Treasure", "Free", 1, "Treasure Hunt", Arrays.asList("Thieving")));
        quests.put("prince_ali_rescue", new Quest("Prince Ali Rescue", "Free", 13, "Rescue", Arrays.asList("Thieving", "Crafting")));
        quests.put("the_restless_ghost", new Quest("The Restless Ghost", "Free", 1, "Ghost", Arrays.asList("Prayer")));
        quests.put("romeo_and_juliet", new Quest("Romeo and Juliet", "Free", 1, "Romance", Arrays.asList("Thieving")));
        quests.put("rune_mysteries", new Quest("Rune Mysteries", "Free", 1, "Mystery", Arrays.asList("Runecrafting")));
        quests.put("sheep_shearer", new Quest("Sheep Shearer", "Free", 1, "Farming", Arrays.asList("Crafting")));
        quests.put("shield_of_arrav", new Quest("Shield of Arrav", "Free", 1, "Gang War", Arrays.asList("Thieving")));
        quests.put("vampire_slayer", new Quest("Vampire Slayer", "Free", 1, "Combat", Arrays.asList("Combat", "Prayer")));
        quests.put("witch's_potion", new Quest("Witch's Potion", "Free", 1, "Potion", Arrays.asList("Herblore")));
        
        // Members quests (sample)
        quests.put("animal_magnetism", new Quest("Animal Magnetism", "Members", 18, "Combat", Arrays.asList("Combat", "Crafting", "Slayer")));
        quests.put("big_chompy_bird_hunting", new Quest("Big Chompy Bird Hunting", "Members", 30, "Hunting", Arrays.asList("Ranged", "Cooking")));
        quests.put("biohazard", new Quest("Biohazard", "Members", 43, "Plague", Arrays.asList("Thieving", "Agility")));
        quests.put("cabin_fever", new Quest("Cabin Fever", "Members", 42, "Pirate", Arrays.asList("Sailing", "Combat")));
        quests.put("clock_tower", new Quest("Clock Tower", "Members", 1, "Puzzle", Arrays.asList("Agility")));
        quests.put("cold_war", new Quest("Cold War", "Members", 34, "Penguin", Arrays.asList("Hunter", "Thieving")));
        quests.put("contact", new Quest("Contact!", "Members", 10, "Desert", Arrays.asList("Prayer", "Thieving")));
        quests.put("creature_of_fenkenstrain", new Quest("Creature of Fenkenstrain", "Members", 25, "Horror", Arrays.asList("Thieving", "Agility")));
        quests.put("darkness_of_hallowvale", new Quest("Darkness of Hallowvale", "Members", 20, "Vampire", Arrays.asList("Thieving", "Agility", "Crafting")));
        quests.put("death_plateau", new Quest("Death Plateau", "Members", 1, "Combat", Arrays.asList("Combat", "Prayer")));
        
        Logger.log("Initialized " + quests.size() + " quests");
    }
    
    private void initializeAchievements() {
        // Combat achievements
        achievements.put("kill_100_goblins", new Achievement("Kill 100 Goblins", "Combat", 1, "Kill 100 goblins"));
        achievements.put("kill_1000_goblins", new Achievement("Kill 1000 Goblins", "Combat", 5, "Kill 1000 goblins"));
        achievements.put("kill_elvarg", new Achievement("Kill Elvarg", "Combat", 10, "Defeat Elvarg in Dragon Slayer"));
        achievements.put("kill_king_black_dragon", new Achievement("Kill King Black Dragon", "Combat", 20, "Defeat the King Black Dragon"));
        achievements.put("kill_zulrah", new Achievement("Kill Zulrah", "Combat", 50, "Defeat Zulrah"));
        achievements.put("kill_vorkath", new Achievement("Kill Vorkath", "Combat", 50, "Defeat Vorkath"));
        
        // Skill achievements
        achievements.put("reach_level_50_attack", new Achievement("Reach Level 50 Attack", "Skills", 5, "Reach level 50 in Attack"));
        achievements.put("reach_level_99_attack", new Achievement("Reach Level 99 Attack", "Skills", 50, "Reach level 99 in Attack"));
        achievements.put("reach_level_50_strength", new Achievement("Reach Level 50 Strength", "Skills", 5, "Reach level 50 in Strength"));
        achievements.put("reach_level_99_strength", new Achievement("Reach Level 99 Strength", "Skills", 50, "Reach level 99 in Strength"));
        achievements.put("reach_level_50_defence", new Achievement("Reach Level 50 Defence", "Skills", 5, "Reach level 50 in Defence"));
        achievements.put("reach_level_99_defence", new Achievement("Reach Level 99 Defence", "Skills", 50, "Reach level 99 in Defence"));
        
        // Collection achievements
        achievements.put("collect_all_runes", new Achievement("Collect All Runes", "Collection", 10, "Collect one of each type of rune"));
        achievements.put("collect_all_gems", new Achievement("Collect All Gems", "Collection", 15, "Collect one of each type of gem"));
        achievements.put("collect_all_logs", new Achievement("Collect All Logs", "Collection", 10, "Collect one of each type of log"));
        
        // Exploration achievements
        achievements.put("visit_all_cities", new Achievement("Visit All Cities", "Exploration", 5, "Visit all major cities in Gielinor"));
        achievements.put("visit_all_dungeons", new Achievement("Visit All Dungeons", "Exploration", 10, "Explore all major dungeons"));
        achievements.put("complete_all_free_quests", new Achievement("Complete All Free Quests", "Quests", 25, "Complete all free-to-play quests"));
        
        Logger.log("Initialized " + achievements.size() + " achievements");
    }
    
    private void initializeDiaries() {
        // Area diaries
        diaries.put("ardougne_diary", new Diary("Ardougne Diary", "Ardougne", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("desert_diary", new Diary("Desert Diary", "Desert", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("falador_diary", new Diary("Falador Diary", "Falador", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("fremennik_diary", new Diary("Fremennik Diary", "Fremennik", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("kandarin_diary", new Diary("Kandarin Diary", "Kandarin", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("karamja_diary", new Diary("Karamja Diary", "Karamja", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("kourend_diary", new Diary("Kourend Diary", "Kourend", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("lumbridge_diary", new Diary("Lumbridge Diary", "Lumbridge", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("morytania_diary", new Diary("Morytania Diary", "Morytania", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("varrock_diary", new Diary("Varrock Diary", "Varrock", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("western_diary", new Diary("Western Diary", "Western Provinces", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        diaries.put("wilderness_diary", new Diary("Wilderness Diary", "Wilderness", Arrays.asList("Easy", "Medium", "Hard", "Elite")));
        
        Logger.log("Initialized " + diaries.size() + " area diaries");
    }
    
    private void initializeCollectionLog() {
        // Boss collection log items
        collectionLog.put("abyssal_whip", new CollectionLogItem("Abyssal Whip", "Abyssal Demon", "Rare", 1));
        collectionLog.put("dragon_med_helm", new CollectionLogItem("Dragon Med Helm", "Various", "Uncommon", 1));
        collectionLog.put("rune_full_helm", new CollectionLogItem("Rune Full Helm", "Various", "Common", 1));
        collectionLog.put("adamant_platebody", new CollectionLogItem("Adamant Platebody", "Various", "Common", 1));
        collectionLog.put("rune_scimitar", new CollectionLogItem("Rune Scimitar", "Various", "Common", 1));
        collectionLog.put("dragon_dagger", new CollectionLogItem("Dragon Dagger", "Various", "Uncommon", 1));
        collectionLog.put("rune_boots", new CollectionLogItem("Rune Boots", "Various", "Common", 1));
        collectionLog.put("rune_gloves", new CollectionLogItem("Rune Gloves", "Various", "Common", 1));
        
        // Skill collection log items
        collectionLog.put("yew_logs", new CollectionLogItem("Yew Logs", "Woodcutting", "Common", 1000));
        collectionLog.put("magic_logs", new CollectionLogItem("Magic Logs", "Woodcutting", "Uncommon", 1000));
        collectionLog.put("rune_essence", new CollectionLogItem("Rune Essence", "Mining", "Common", 10000));
        collectionLog.put("pure_essence", new CollectionLogItem("Pure Essence", "Mining", "Uncommon", 10000));
        collectionLog.put("lobster", new CollectionLogItem("Lobster", "Fishing", "Common", 1000));
        collectionLog.put("shark", new CollectionLogItem("Shark", "Fishing", "Uncommon", 1000));
        
        Logger.log("Initialized " + collectionLog.size() + " collection log items");
    }
    
    public void startQuestSystem() {
        if (!questSystemEnabled) {
            return;
        }
        
        CompletableFuture.runAsync(() -> {
            while (questSystemEnabled) {
                try {
                    // Check for available quests
                    checkAvailableQuests();
                    
                    // Update quest progress
                    updateQuestProgress();
                    
                    // Plan quest sessions
                    planQuestSessions();
                    
                    Sleep.sleep(60000); // Check every minute
                } catch (Exception e) {
                    Logger.log("Error in quest system: " + e.getMessage());
                }
            }
        }, executorService);
    }
    
    public void startAchievementSystem() {
        if (!achievementSystemEnabled) {
            return;
        }
        
        CompletableFuture.runAsync(() -> {
            while (achievementSystemEnabled) {
                try {
                    // Check for achievable achievements
                    checkAchievements();
                    
                    // Update achievement progress
                    updateAchievementProgress();
                    
                    Sleep.sleep(ACHIEVEMENT_CHECK_INTERVAL);
                } catch (Exception e) {
                    Logger.log("Error in achievement system: " + e.getMessage());
                }
            }
        }, executorService);
    }
    
    public void startDiarySystem() {
        if (!diarySystemEnabled) {
            return;
        }
        
        CompletableFuture.runAsync(() -> {
            while (diarySystemEnabled) {
                try {
                    // Check diary progress
                    checkDiaryProgress();
                    
                    // Plan diary tasks
                    planDiaryTasks();
                    
                    Sleep.sleep(DIARY_CHECK_INTERVAL);
                } catch (Exception e) {
                    Logger.log("Error in diary system: " + e.getMessage());
                }
            }
        }, executorService);
    }
    
    private void checkAvailableQuests() {
        List<Quest> availableQuests = new ArrayList<>();
        
        for (Quest quest : quests.values()) {
            if (isQuestAvailable(quest)) {
                availableQuests.add(quest);
            }
        }
        
        if (!availableQuests.isEmpty()) {
            // Select a quest to work on
            Quest selectedQuest = selectQuestToWorkOn(availableQuests);
            if (selectedQuest != null) {
                startQuestSession(selectedQuest);
            }
        }
    }
    
    private boolean isQuestAvailable(Quest quest) {
        // Check if quest requirements are met
        // This would integrate with actual skill levels and quest progress
        return random.nextDouble() < 0.3; // 30% chance for demo
    }
    
    private Quest selectQuestToWorkOn(List<Quest> availableQuests) {
        if (availableQuests.isEmpty()) {
            return null;
        }
        
        // Weight selection by difficulty and type
        double totalWeight = 0;
        Map<Quest, Double> questWeights = new HashMap<>();
        
        for (Quest quest : availableQuests) {
            double weight = calculateQuestWeight(quest);
            questWeights.put(quest, weight);
            totalWeight += weight;
        }
        
        double randomValue = random.nextDouble() * totalWeight;
        double currentWeight = 0;
        
        for (Map.Entry<Quest, Double> entry : questWeights.entrySet()) {
            currentWeight += entry.getValue();
            if (randomValue <= currentWeight) {
                return entry.getKey();
            }
        }
        
        return availableQuests.get(random.nextInt(availableQuests.size()));
    }
    
    private double calculateQuestWeight(Quest quest) {
        double weight = 1.0;
        
        // Prefer easier quests
        if (quest.getDifficulty() <= 10) {
            weight += 2.0;
        } else if (quest.getDifficulty() <= 30) {
            weight += 1.5;
        }
        
        // Prefer free quests
        if (quest.getType().equals("Free")) {
            weight += 1.0;
        }
        
        // Random variation
        weight += random.nextDouble() * 0.5;
        
        return weight;
    }
    
    private void startQuestSession(Quest quest) {
        QuestSession session = new QuestSession(quest, System.currentTimeMillis());
        questSessions.add(session);
        
        // Update progress
        QuestProgress progress = questProgress.getOrDefault(quest.getName(), new QuestProgress(quest.getName()));
        progress.updateProgress(10); // Simulate progress
        questProgress.put(quest.getName(), progress);
        
        Logger.log("Started quest session: " + quest.getName());
    }
    
    private void updateQuestProgress() {
        for (QuestProgress progress : questProgress.values()) {
            // Simulate progress updates
            if (random.nextDouble() < 0.1) { // 10% chance
                progress.updateProgress(random.nextInt(10) + 1);
            }
        }
    }
    
    private void planQuestSessions() {
        // Plan future quest sessions based on requirements
        List<Quest> plannedQuests = new ArrayList<>();
        
        for (Quest quest : quests.values()) {
            if (!questProgress.containsKey(quest.getName()) || 
                questProgress.get(quest.getName()).getProgress() < 100) {
                plannedQuests.add(quest);
            }
        }
        
        if (!plannedQuests.isEmpty()) {
            Logger.log("Planned quests: " + plannedQuests.stream()
                .map(Quest::getName)
                .limit(5)
                .reduce((a, b) -> a + ", " + b)
                .orElse("None"));
        }
    }
    
    private void checkAchievements() {
        for (Achievement achievement : achievements.values()) {
            if (isAchievementUnlocked(achievement)) {
                unlockAchievement(achievement);
            }
        }
    }
    
    private boolean isAchievementUnlocked(Achievement achievement) {
        // Check if achievement requirements are met
        // This would integrate with actual game state
        return random.nextDouble() < 0.05; // 5% chance for demo
    }
    
    private void unlockAchievement(Achievement achievement) {
        AchievementProgress progress = achievementProgress.getOrDefault(achievement.getName(), 
            new AchievementProgress(achievement.getName()));
        progress.unlock();
        achievementProgress.put(achievement.getName(), progress);
        
        totalAchievementsUnlocked++;
        Logger.log("Achievement unlocked: " + achievement.getName());
    }
    
    private void updateAchievementProgress() {
        for (AchievementProgress progress : achievementProgress.values()) {
            if (!progress.isUnlocked()) {
                // Simulate progress
                progress.updateProgress(random.nextInt(10) + 1);
            }
        }
    }
    
    private void checkDiaryProgress() {
        for (Diary diary : diaries.values()) {
            DiaryProgress progress = diaryProgress.getOrDefault(diary.getName(), 
                new DiaryProgress(diary.getName()));
            
            // Check each tier
            for (String tier : diary.getTiers()) {
                if (!progress.isTierCompleted(tier)) {
                    // Simulate progress
                    if (random.nextDouble() < 0.1) { // 10% chance
                        progress.completeTier(tier);
                        Logger.log("Completed " + diary.getName() + " " + tier + " tier");
                    }
                }
            }
            
            diaryProgress.put(diary.getName(), progress);
        }
    }
    
    private void planDiaryTasks() {
        // Plan diary tasks based on current progress
        List<String> plannedTasks = new ArrayList<>();
        
        for (DiaryProgress progress : diaryProgress.values()) {
            if (!progress.isFullyCompleted()) {
                plannedTasks.add(progress.getDiaryName() + " tasks");
            }
        }
        
        if (!plannedTasks.isEmpty()) {
            Logger.log("Planned diary tasks: " + plannedTasks.stream()
                .limit(3)
                .reduce((a, b) -> a + ", " + b)
                .orElse("None"));
        }
    }
    
    // Configuration methods
    
    public void setQuestSystemEnabled(boolean enabled) {
        this.questSystemEnabled = enabled;
        Logger.log("Quest system " + (enabled ? "enabled" : "disabled"));
    }
    
    public void setAchievementSystemEnabled(boolean enabled) {
        this.achievementSystemEnabled = enabled;
        Logger.log("Achievement system " + (enabled ? "enabled" : "disabled"));
    }
    
    public void setDiarySystemEnabled(boolean enabled) {
        this.diarySystemEnabled = enabled;
        Logger.log("Diary system " + (enabled ? "enabled" : "disabled"));
    }
    
    public void setCollectionLogEnabled(boolean enabled) {
        this.collectionLogEnabled = enabled;
        Logger.log("Collection log " + (enabled ? "enabled" : "disabled"));
    }
    
    public void setQuestIntensity(double intensity) {
        this.questIntensity = Math.max(0.0, Math.min(1.0, intensity));
        Logger.log("Quest intensity set to: " + questIntensity);
    }
    
    // Getters
    
    public boolean isQuestSystemEnabled() { return questSystemEnabled; }
    public boolean isAchievementSystemEnabled() { return achievementSystemEnabled; }
    public boolean isDiarySystemEnabled() { return diarySystemEnabled; }
    public boolean isCollectionLogEnabled() { return collectionLogEnabled; }
    public double getQuestIntensity() { return questIntensity; }
    public int getTotalQuestsCompleted() { return totalQuestsCompleted; }
    public int getTotalAchievementsUnlocked() { return totalAchievementsUnlocked; }
    public long getLastQuestActivity() { return lastQuestActivity; }
    public Map<String, Quest> getQuests() { return new HashMap<>(quests); }
    public Map<String, Achievement> getAchievements() { return new HashMap<>(achievements); }
    public Map<String, Diary> getDiaries() { return new HashMap<>(diaries); }
    public Map<String, CollectionLogItem> getCollectionLog() { return new HashMap<>(collectionLog); }
    public Map<String, QuestProgress> getQuestProgress() { return new HashMap<>(questProgress); }
    public Map<String, AchievementProgress> getAchievementProgress() { return new HashMap<>(achievementProgress); }
    public Map<String, DiaryProgress> getDiaryProgress() { return new HashMap<>(diaryProgress); }
    public List<QuestSession> getQuestSessions() { return new ArrayList<>(questSessions); }
    
    // Inner classes
    
    public static class Quest {
        private final String name;
        private final String type;
        private final int difficulty;
        private final String category;
        private final List<String> requirements;
        
        public Quest(String name, String type, int difficulty, String category, List<String> requirements) {
            this.name = name;
            this.type = type;
            this.difficulty = difficulty;
            this.category = category;
            this.requirements = requirements;
        }
        
        // Getters
        public String getName() { return name; }
        public String getType() { return type; }
        public int getDifficulty() { return difficulty; }
        public String getCategory() { return category; }
        public List<String> getRequirements() { return requirements; }
    }
    
    public static class Achievement {
        private final String name;
        private final String category;
        private final int points;
        private final String description;
        
        public Achievement(String name, String category, int points, String description) {
            this.name = name;
            this.category = category;
            this.points = points;
            this.description = description;
        }
        
        // Getters
        public String getName() { return name; }
        public String getCategory() { return category; }
        public int getPoints() { return points; }
        public String getDescription() { return description; }
    }
    
    public static class Diary {
        private final String name;
        private final String area;
        private final List<String> tiers;
        
        public Diary(String name, String area, List<String> tiers) {
            this.name = name;
            this.area = area;
            this.tiers = tiers;
        }
        
        // Getters
        public String getName() { return name; }
        public String getArea() { return area; }
        public List<String> getTiers() { return tiers; }
    }
    
    public static class CollectionLogItem {
        private final String name;
        private final String source;
        private final String rarity;
        private final int targetQuantity;
        
        public CollectionLogItem(String name, String source, String rarity, int targetQuantity) {
            this.name = name;
            this.source = source;
            this.rarity = rarity;
            this.targetQuantity = targetQuantity;
        }
        
        // Getters
        public String getName() { return name; }
        public String getSource() { return source; }
        public String getRarity() { return rarity; }
        public int getTargetQuantity() { return targetQuantity; }
    }
    
    public static class QuestProgress {
        private final String questName;
        private int progress;
        private long startTime;
        private long lastUpdate;
        
        public QuestProgress(String questName) {
            this.questName = questName;
            this.progress = 0;
            this.startTime = System.currentTimeMillis();
            this.lastUpdate = startTime;
        }
        
        public void updateProgress(int amount) {
            this.progress = Math.min(100, this.progress + amount);
            this.lastUpdate = System.currentTimeMillis();
        }
        
        // Getters
        public String getQuestName() { return questName; }
        public int getProgress() { return progress; }
        public long getStartTime() { return startTime; }
        public long getLastUpdate() { return lastUpdate; }
        public boolean isCompleted() { return progress >= 100; }
    }
    
    public static class AchievementProgress {
        private final String achievementName;
        private int progress;
        private boolean unlocked;
        private long unlockTime;
        
        public AchievementProgress(String achievementName) {
            this.achievementName = achievementName;
            this.progress = 0;
            this.unlocked = false;
        }
        
        public void updateProgress(int amount) {
            this.progress = Math.min(100, this.progress + amount);
        }
        
        public void unlock() {
            this.unlocked = true;
            this.unlockTime = System.currentTimeMillis();
        }
        
        // Getters
        public String getAchievementName() { return achievementName; }
        public int getProgress() { return progress; }
        public boolean isUnlocked() { return unlocked; }
        public long getUnlockTime() { return unlockTime; }
    }
    
    public static class DiaryProgress {
        private final String diaryName;
        private final Map<String, Boolean> completedTiers;
        
        public DiaryProgress(String diaryName) {
            this.diaryName = diaryName;
            this.completedTiers = new HashMap<>();
        }
        
        public void completeTier(String tier) {
            completedTiers.put(tier, true);
        }
        
        public boolean isTierCompleted(String tier) {
            return completedTiers.getOrDefault(tier, false);
        }
        
        public boolean isFullyCompleted() {
            return completedTiers.values().stream().allMatch(Boolean::booleanValue);
        }
        
        // Getters
        public String getDiaryName() { return diaryName; }
        public Map<String, Boolean> getCompletedTiers() { return new HashMap<>(completedTiers); }
    }
    
    public static class QuestSession {
        private final Quest quest;
        private final long startTime;
        private long endTime;
        private int progress;
        
        public QuestSession(Quest quest, long startTime) {
            this.quest = quest;
            this.startTime = startTime;
            this.progress = 0;
        }
        
        public void endSession(int finalProgress) {
            this.endTime = System.currentTimeMillis();
            this.progress = finalProgress;
        }
        
        // Getters
        public Quest getQuest() { return quest; }
        public long getStartTime() { return startTime; }
        public long getEndTime() { return endTime; }
        public int getProgress() { return progress; }
        public long getDuration() { return endTime - startTime; }
    }
} 