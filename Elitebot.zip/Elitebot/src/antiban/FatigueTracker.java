package antiban;

import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Advanced Fatigue Tracking System
 * Simulates human fatigue patterns and adjusts behavior accordingly
 */
public class FatigueTracker {
    
    // Fatigue state tracking
    private final AtomicInteger currentFatigueLevel = new AtomicInteger(0);
    private final AtomicLong sessionStartTime = new AtomicLong(System.currentTimeMillis());
    private final AtomicLong lastFatigueUpdate = new AtomicLong(System.currentTimeMillis());
    
    // Fatigue characteristics
    private final Map<String, Double> fatigueFactors = new HashMap<>();
    private final List<Long> fatigueEvents = new ArrayList<>();
    private final Queue<FatigueEvent> fatigueHistory = new LinkedList<>();
    
    // Advanced fatigue modeling
    private final Map<String, FatiguePattern> fatiguePatterns = new HashMap<>();
    private final List<Double> fatigueTrends = new ArrayList<>();
    private final Map<String, Integer> activityIntensity = new HashMap<>();
    
    // Human-like fatigue simulation
    private final Random random = new Random();
    private int consecutiveActions = 0;
    private long lastBreakTime = 0;
    private double fatigueAccumulationRate = 1.0;
    private boolean isFatigueActive = false;
    
    // Fatigue thresholds
    private static final int MAX_FATIGUE_LEVEL = 100;
    private static final int FATIGUE_WARNING_THRESHOLD = 60;
    private static final int FATIGUE_CRITICAL_THRESHOLD = 80;
    private static final long FATIGUE_UPDATE_INTERVAL = 30000; // 30 seconds
    private static final long MIN_BREAK_INTERVAL = 60000; // 1 minute
    
    public FatigueTracker() {
        initializeFatigueFactors();
        initializeFatiguePatterns();
        
        Logger.log("Fatigue tracker initialized with advanced human-like patterns");
    }
    
    private void initializeFatigueFactors() {
        // Initialize fatigue factors
        fatigueFactors.put("session_duration", 0.3);
        fatigueFactors.put("action_intensity", 0.4);
        fatigueFactors.put("consecutive_actions", 0.5);
        fatigueFactors.put("break_frequency", 0.2);
        fatigueFactors.put("activity_complexity", 0.3);
        fatigueFactors.put("time_of_day", 0.1);
        fatigueFactors.put("previous_sessions", 0.2);
        fatigueFactors.put("physical_activity", 0.4);
        fatigueFactors.put("mental_strain", 0.6);
        fatigueFactors.put("environmental_factors", 0.1);
    }
    
    private void initializeFatiguePatterns() {
        // Initialize fatigue patterns
        fatiguePatterns.put("morning_freshness", new MorningFreshnessPattern());
        fatiguePatterns.put("afternoon_dip", new AfternoonDipPattern());
        fatiguePatterns.put("evening_fatigue", new EveningFatiguePattern());
        fatiguePatterns.put("late_night_struggle", new LateNightStrugglePattern());
        fatiguePatterns.put("weekend_energy", new WeekendEnergyPattern());
        fatiguePatterns.put("workday_strain", new WorkdayStrainPattern());
        fatiguePatterns.put("post_break_boost", new PostBreakBoostPattern());
        fatiguePatterns.put("pre_break_fatigue", new PreBreakFatiguePattern());
    }
    
    /**
     * Update fatigue level based on current activity
     */
    public void updateFatigue() {
        long currentTime = System.currentTimeMillis();
        
        // Only update fatigue periodically
        if (currentTime - lastFatigueUpdate.get() < FATIGUE_UPDATE_INTERVAL) {
            return;
        }
        
        lastFatigueUpdate.set(currentTime);
        
        // Calculate fatigue increase
        int fatigueIncrease = calculateFatigueIncrease();
        
        // Apply fatigue patterns
        fatigueIncrease = applyFatiguePatterns(fatigueIncrease);
        
        // Update fatigue level
        int newFatigueLevel = Math.min(MAX_FATIGUE_LEVEL, 
            currentFatigueLevel.get() + fatigueIncrease);
        
        currentFatigueLevel.set(newFatigueLevel);
        
        // Update fatigue state
        updateFatigueState();
        
        // Record fatigue event
        recordFatigueEvent(currentTime, fatigueIncrease);
        
        // Check for fatigue-based actions
        checkFatigueActions();
        
        Logger.log("Fatigue updated: " + newFatigueLevel + "/" + MAX_FATIGUE_LEVEL);
    }
    
    /**
     * Calculate fatigue increase based on current activity
     */
    private int calculateFatigueIncrease() {
        int baseIncrease = 1;
        
        // Factor 1: Session duration
        long sessionDuration = System.currentTimeMillis() - sessionStartTime.get();
        double sessionFactor = Math.min(2.0, sessionDuration / 3600000.0); // 1 hour = 2x
        baseIncrease += (int)(sessionFactor * fatigueFactors.get("session_duration") * 10);
        
        // Factor 2: Consecutive actions
        double consecutiveFactor = Math.min(3.0, consecutiveActions / 50.0);
        baseIncrease += (int)(consecutiveFactor * fatigueFactors.get("consecutive_actions") * 5);
        
        // Factor 3: Action intensity
        double intensityFactor = getCurrentActivityIntensity();
        baseIncrease += (int)(intensityFactor * fatigueFactors.get("action_intensity") * 8);
        
        // Factor 4: Break frequency
        long timeSinceLastBreak = System.currentTimeMillis() - lastBreakTime;
        double breakFactor = Math.min(2.0, timeSinceLastBreak / 300000.0); // 5 minutes = 2x
        baseIncrease += (int)(breakFactor * fatigueFactors.get("break_frequency") * 3);
        
        // Factor 5: Time of day
        double timeOfDayFactor = getTimeOfDayFactor();
        baseIncrease += (int)(timeOfDayFactor * fatigueFactors.get("time_of_day") * 2);
        
        // Apply fatigue accumulation rate
        baseIncrease = (int)(baseIncrease * fatigueAccumulationRate);
        
        return Math.max(0, baseIncrease);
    }
    
    /**
     * Apply fatigue patterns based on time and context
     */
    private int applyFatiguePatterns(int baseIncrease) {
        // Get current time patterns
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        
        double patternMultiplier = 1.0;
        
        // Apply time-based patterns
        if (hour >= 6 && hour < 12) {
            // Morning freshness
            patternMultiplier = fatiguePatterns.get("morning_freshness").getMultiplier();
        } else if (hour >= 12 && hour < 17) {
            // Afternoon dip
            patternMultiplier = fatiguePatterns.get("afternoon_dip").getMultiplier();
        } else if (hour >= 17 && hour < 22) {
            // Evening fatigue
            patternMultiplier = fatiguePatterns.get("evening_fatigue").getMultiplier();
        } else {
            // Late night struggle
            patternMultiplier = fatiguePatterns.get("late_night_struggle").getMultiplier();
        }
        
        // Apply day-based patterns
        if (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY) {
            // Weekend energy
            patternMultiplier *= fatiguePatterns.get("weekend_energy").getMultiplier();
        } else {
            // Workday strain
            patternMultiplier *= fatiguePatterns.get("workday_strain").getMultiplier();
        }
        
        // Apply break-based patterns
        if (System.currentTimeMillis() - lastBreakTime < 300000) { // 5 minutes
            // Post-break boost
            patternMultiplier *= fatiguePatterns.get("post_break_boost").getMultiplier();
        } else if (System.currentTimeMillis() - lastBreakTime > 1800000) { // 30 minutes
            // Pre-break fatigue
            patternMultiplier *= fatiguePatterns.get("pre_break_fatigue").getMultiplier();
        }
        
        return (int)(baseIncrease * patternMultiplier);
    }
    
    /**
     * Update fatigue state based on current level
     */
    private void updateFatigueState() {
        int fatigueLevel = currentFatigueLevel.get();
        
        if (fatigueLevel >= FATIGUE_CRITICAL_THRESHOLD) {
            isFatigueActive = true;
            fatigueAccumulationRate = 1.5; // Faster accumulation
        } else if (fatigueLevel >= FATIGUE_WARNING_THRESHOLD) {
            isFatigueActive = true;
            fatigueAccumulationRate = 1.2; // Moderate accumulation
        } else {
            isFatigueActive = false;
            fatigueAccumulationRate = 1.0; // Normal accumulation
        }
    }
    
    /**
     * Record fatigue event for analysis
     */
    private void recordFatigueEvent(long timestamp, int fatigueIncrease) {
        FatigueEvent event = new FatigueEvent(timestamp, fatigueIncrease, currentFatigueLevel.get());
        fatigueHistory.offer(event);
        
        if (fatigueHistory.size() > 100) {
            fatigueHistory.poll();
        }
        
        fatigueEvents.add(timestamp);
        if (fatigueEvents.size() > 200) {
            fatigueEvents.remove(0);
        }
    }
    
    /**
     * Check for fatigue-based actions
     */
    private void checkFatigueActions() {
        int fatigueLevel = currentFatigueLevel.get();
        
        if (fatigueLevel >= FATIGUE_CRITICAL_THRESHOLD) {
            // Critical fatigue - force break
            Logger.log("Critical fatigue detected - forcing break");
            forceBreak();
        } else if (fatigueLevel >= FATIGUE_WARNING_THRESHOLD) {
            // Warning fatigue - suggest break
            if (random.nextDouble() < 0.3) {
                Logger.log("Warning fatigue - suggesting break");
                suggestBreak();
            }
        }
    }
    
    /**
     * Get current activity intensity
     */
    private double getCurrentActivityIntensity() {
        // Calculate based on recent activity
        if (fatigueEvents.size() < 5) {
            return 0.5; // Default moderate intensity
        }
        
        // Calculate events per minute
        long recentTime = System.currentTimeMillis() - 300000; // 5 minutes
        long recentEvents = fatigueEvents.stream()
            .filter(time -> time > recentTime)
            .count();
        
        return Math.min(1.0, recentEvents / 10.0); // Normalize to 0-1
    }
    
    /**
     * Get time of day factor
     */
    private double getTimeOfDayFactor() {
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        
        if (hour >= 6 && hour < 12) {
            return 0.5; // Morning - less fatigue
        } else if (hour >= 12 && hour < 17) {
            return 1.2; // Afternoon - more fatigue
        } else if (hour >= 17 && hour < 22) {
            return 1.5; // Evening - high fatigue
        } else {
            return 2.0; // Night - very high fatigue
        }
    }
    
    /**
     * Increment consecutive actions
     */
    public void incrementConsecutiveActions() {
        consecutiveActions++;
    }
    
    /**
     * Reset consecutive actions (after break)
     */
    public void resetConsecutiveActions() {
        consecutiveActions = 0;
    }
    
    /**
     * Take a break to reduce fatigue
     */
    public void takeBreak() {
        long currentTime = System.currentTimeMillis();
        
        if (currentTime - lastBreakTime < MIN_BREAK_INTERVAL) {
            return; // Too soon for another break
        }
        
        // Calculate fatigue reduction
        int fatigueReduction = calculateFatigueReduction();
        
        // Apply fatigue reduction
        int newFatigueLevel = Math.max(0, currentFatigueLevel.get() - fatigueReduction);
        currentFatigueLevel.set(newFatigueLevel);
        
        // Update break time
        lastBreakTime = currentTime;
        
        // Reset consecutive actions
        resetConsecutiveActions();
        
        // Update fatigue accumulation rate
        fatigueAccumulationRate = Math.max(0.5, fatigueAccumulationRate * 0.8);
        
        Logger.log("Break taken - fatigue reduced by " + fatigueReduction + " to " + newFatigueLevel);
    }
    
    /**
     * Calculate fatigue reduction from break
     */
    private int calculateFatigueReduction() {
        int baseReduction = 10;
        
        // Factor 1: Current fatigue level
        int fatigueLevel = currentFatigueLevel.get();
        if (fatigueLevel > 80) {
            baseReduction += 20; // More reduction for high fatigue
        } else if (fatigueLevel > 50) {
            baseReduction += 10; // Moderate reduction
        }
        
        // Factor 2: Break duration (simulated)
        long breakDuration = 300000; // 5 minutes
        double durationFactor = Math.min(2.0, breakDuration / 300000.0);
        baseReduction = (int)(baseReduction * durationFactor);
        
        // Factor 3: Random variation
        baseReduction += random.nextInt(10) - 5;
        
        return Math.max(5, baseReduction);
    }
    
    /**
     * Force a break due to high fatigue
     */
    private void forceBreak() {
        Logger.log("Forcing break due to high fatigue");
        
        // Simulate forced break
        try {
            Thread.sleep(5000 + random.nextInt(10000)); // 5-15 second break
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        takeBreak();
    }
    
    /**
     * Suggest a break
     */
    private void suggestBreak() {
        Logger.log("Fatigue suggests taking a break");
        
        // Simulate considering break
        try {
            Thread.sleep(1000 + random.nextInt(2000)); // 1-3 second pause
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    /**
     * Get current fatigue level
     */
    public int getFatigueLevel() {
        return currentFatigueLevel.get();
    }
    
    /**
     * Check if fatigue is active
     */
    public boolean isFatigueActive() {
        return isFatigueActive;
    }
    
    /**
     * Get fatigue percentage
     */
    public double getFatiguePercentage() {
        return (double) currentFatigueLevel.get() / MAX_FATIGUE_LEVEL;
    }
    
    /**
     * Check if break is recommended
     */
    public boolean isBreakRecommended() {
        return currentFatigueLevel.get() >= FATIGUE_WARNING_THRESHOLD;
    }
    
    /**
     * Check if break is critical
     */
    public boolean isBreakCritical() {
        return currentFatigueLevel.get() >= FATIGUE_CRITICAL_THRESHOLD;
    }
    
    /**
     * Get session duration
     */
    public long getSessionDuration() {
        return System.currentTimeMillis() - sessionStartTime.get();
    }
    
    /**
     * Get consecutive actions count
     */
    public int getConsecutiveActions() {
        return consecutiveActions;
    }
    
    /**
     * Get time since last break
     */
    public long getTimeSinceLastBreak() {
        return System.currentTimeMillis() - lastBreakTime;
    }
    
    /**
     * Increase fatigue level by a specific amount
     */
    public void increaseFatigue(int amount) {
        int newFatigueLevel = Math.min(MAX_FATIGUE_LEVEL, 
            currentFatigueLevel.get() + amount);
        currentFatigueLevel.set(newFatigueLevel);
        
        // Update fatigue state
        updateFatigueState();
        
        // Record fatigue event
        recordFatigueEvent(System.currentTimeMillis(), amount);
    }
    
    // Fatigue pattern interface and implementations
    private interface FatiguePattern {
        double getMultiplier();
    }
    
    private class MorningFreshnessPattern implements FatiguePattern {
        @Override
        public double getMultiplier() {
            return 0.7; // 30% less fatigue in morning
        }
    }
    
    private class AfternoonDipPattern implements FatiguePattern {
        @Override
        public double getMultiplier() {
            return 1.3; // 30% more fatigue in afternoon
        }
    }
    
    private class EveningFatiguePattern implements FatiguePattern {
        @Override
        public double getMultiplier() {
            return 1.5; // 50% more fatigue in evening
        }
    }
    
    private class LateNightStrugglePattern implements FatiguePattern {
        @Override
        public double getMultiplier() {
            return 2.0; // 100% more fatigue at night
        }
    }
    
    private class WeekendEnergyPattern implements FatiguePattern {
        @Override
        public double getMultiplier() {
            return 0.8; // 20% less fatigue on weekends
        }
    }
    
    private class WorkdayStrainPattern implements FatiguePattern {
        @Override
        public double getMultiplier() {
            return 1.2; // 20% more fatigue on workdays
        }
    }
    
    private class PostBreakBoostPattern implements FatiguePattern {
        @Override
        public double getMultiplier() {
            return 0.6; // 40% less fatigue after break
        }
    }
    
    private class PreBreakFatiguePattern implements FatiguePattern {
        @Override
        public double getMultiplier() {
            return 1.4; // 40% more fatigue before break
        }
    }
    
    // Fatigue event class
    private static class FatigueEvent {
        final long timestamp;
        final int fatigueIncrease;
        final int totalFatigue;
        
        FatigueEvent(long timestamp, int fatigueIncrease, int totalFatigue) {
            this.timestamp = timestamp;
            this.fatigueIncrease = fatigueIncrease;
            this.totalFatigue = totalFatigue;
        }
    }
}
