package antiban;

import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import antiban.AdvancedPathingSystem.PathingPreferences;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Advanced Run Energy Manager with personality-based decision making
 * Surpasses P2P AI with sophisticated run energy management
 */
public class RunEnergyManager {
    
    private final UUIDProfileCache profileCache;
    private final Map<String, RunEnergyProfile> personalityProfiles;
    private final List<RunDecision> decisionHistory = new ArrayList<>();
    
    // Run energy state tracking
    private int currentRunEnergy = 100;
    private long lastRunEnergyCheck = 0;
    private boolean wasRunning = false;
    private long lastRunToggle = 0;
    
    // Decision making statistics
    private int totalDecisions = 0;
    private int runDecisions = 0;
    private int walkDecisions = 0;
    
    // Personality-based run energy patterns
    private final Map<String, RunEnergyPattern> personalityPatterns;
    
    public RunEnergyManager(UUIDProfileCache profileCache) {
        this.profileCache = profileCache;
        this.personalityProfiles = initializePersonalityProfiles();
        this.personalityPatterns = initializePersonalityPatterns();
        
        Logger.log("[RunEnergyManager] Initialized with personality-based run energy management");
    }
    
    /**
     * Initialize personality-based run energy profiles
     */
    private Map<String, RunEnergyProfile> initializePersonalityProfiles() {
        Map<String, RunEnergyProfile> profiles = new HashMap<>();
        
        // Efficient player - aggressive run usage
        profiles.put("efficient_player", new RunEnergyProfile(
            0.8,  // Run threshold (use run when energy > 20%)
            0.9,  // Run preference (90% chance to run when possible)
            0.1,  // Walk preference (10% chance to walk even with energy)
            0.05, // Conservation factor (very low - use energy freely)
            0.95  // Efficiency factor (very high - prioritize speed)
        ));
        
        // Chill player - conservative run usage
        profiles.put("chill_player", new RunEnergyProfile(
            0.6,  // Run threshold (use run when energy > 40%)
            0.3,  // Run preference (30% chance to run when possible)
            0.7,  // Walk preference (70% chance to walk even with energy)
            0.8,  // Conservation factor (high - conserve energy)
            0.3   // Efficiency factor (low - prioritize comfort)
        ));
        
        // Newbie - cautious run usage
        profiles.put("newbie", new RunEnergyProfile(
            0.7,  // Run threshold (use run when energy > 30%)
            0.4,  // Run preference (40% chance to run when possible)
            0.6,  // Walk preference (60% chance to walk even with energy)
            0.6,  // Conservation factor (moderate - conserve some energy)
            0.5   // Efficiency factor (moderate - balanced approach)
        ));
        
        // Veteran - strategic run usage
        profiles.put("veteran", new RunEnergyProfile(
            0.5,  // Run threshold (use run when energy > 50%)
            0.7,  // Run preference (70% chance to run when possible)
            0.3,  // Walk preference (30% chance to walk even with energy)
            0.4,  // Conservation factor (moderate - strategic conservation)
            0.8   // Efficiency factor (high - prioritize efficiency)
        ));
        
        // Casual player - balanced run usage
        profiles.put("casual_player", new RunEnergyProfile(
            0.6,  // Run threshold (use run when energy > 40%)
            0.5,  // Run preference (50% chance to run when possible)
            0.5,  // Walk preference (50% chance to walk even with energy)
            0.5,  // Conservation factor (moderate - balanced conservation)
            0.6   // Efficiency factor (moderate - balanced efficiency)
        ));
        
        return profiles;
    }
    
    /**
     * Initialize personality-based run energy patterns
     */
    private Map<String, RunEnergyPattern> initializePersonalityPatterns() {
        Map<String, RunEnergyPattern> patterns = new HashMap<>();
        
        // Efficient player pattern
        patterns.put("efficient_player", new RunEnergyPattern(
            true,   // Use run for short distances
            true,   // Use run in combat
            true,   // Use run for resource gathering
            false,  // Conserve energy for long trips
            0.1,    // Random walk chance
            0.05    // Energy conservation chance
        ));
        
        // Chill player pattern
        patterns.put("chill_player", new RunEnergyPattern(
            false,  // Use run for short distances
            false,  // Use run in combat
            false,  // Use run for resource gathering
            true,   // Conserve energy for long trips
            0.4,    // Random walk chance
            0.3     // Energy conservation chance
        ));
        
        // Newbie pattern
        patterns.put("newbie", new RunEnergyPattern(
            false,  // Use run for short distances
            true,   // Use run in combat
            false,  // Use run for resource gathering
            true,   // Conserve energy for long trips
            0.3,    // Random walk chance
            0.2     // Energy conservation chance
        ));
        
        // Veteran pattern
        patterns.put("veteran", new RunEnergyPattern(
            true,   // Use run for short distances
            true,   // Use run in combat
            true,   // Use run for resource gathering
            false,  // Conserve energy for long trips
            0.15,   // Random walk chance
            0.1     // Energy conservation chance
        ));
        
        // Casual player pattern
        patterns.put("casual_player", new RunEnergyPattern(
            false,  // Use run for short distances
            true,   // Use run in combat
            false,  // Use run for resource gathering
            true,   // Conserve energy for long trips
            0.25,   // Random walk chance
            0.15    // Energy conservation chance
        ));
        
        return patterns;
    }
    
    /**
     * Decide whether to use run energy based on personality and situation
     */
    public boolean shouldUseRunEnergy(Tile destination, PathingPreferences pathingPrefs) {
        updateRunEnergy();
        
        String personality = profileCache.getCurrentPersonality();
        RunEnergyProfile profile = personalityProfiles.getOrDefault(personality, 
            personalityProfiles.get("casual_player"));
        RunEnergyPattern pattern = personalityPatterns.getOrDefault(personality,
            personalityPatterns.get("casual_player"));
        
        // Calculate distance to destination
        Tile currentTile = org.dreambot.api.methods.interactive.Players.getLocal().getTile();
        if (currentTile == null) return false;
        
        double distance = currentTile.distance(destination);
        
        // Get situational factors
        boolean inCombat = org.dreambot.api.methods.interactive.Players.getLocal().isInCombat();
        boolean nearResources = isNearResources(currentTile);
        boolean isLongTrip = distance > 20;
        
        // Calculate decision score
        double decisionScore = calculateRunDecisionScore(
            profile, pattern, distance, inCombat, nearResources, isLongTrip, pathingPrefs
        );
        
        // Add personality-based randomness
        decisionScore += getPersonalityRandomness(personality);
        
        // Make decision
        boolean shouldRun = decisionScore > 0.5;
        
        // Record decision
        recordDecision(shouldRun, distance, inCombat, nearResources, isLongTrip, decisionScore);
        
        // Apply decision
        toggleRun(shouldRun);
        
        return shouldRun;
    }
    
    /**
     * Calculate run decision score based on multiple factors
     */
    private double calculateRunDecisionScore(RunEnergyProfile profile, RunEnergyPattern pattern,
                                           double distance, boolean inCombat, boolean nearResources,
                                           boolean isLongTrip, PathingPreferences pathingPrefs) {
        double score = 0.0;
        
        // Base run preference
        score += profile.runPreference * 0.3;
        
        // Distance factor
        if (distance < 5) {
            score += pattern.useRunForShortDistances ? 0.2 : -0.2;
        } else if (distance > 15) {
            score += pattern.conserveEnergyForLongTrips ? -0.3 : 0.1;
        }
        
        // Combat factor
        if (inCombat) {
            score += pattern.useRunInCombat ? 0.4 : -0.1;
        }
        
        // Resource gathering factor
        if (nearResources) {
            score += pattern.useRunForResourceGathering ? 0.2 : -0.1;
        }
        
        // Energy level factor
        double energyFactor = currentRunEnergy / 100.0;
        if (energyFactor < profile.runThreshold) {
            score -= 0.5; // Strong penalty for low energy
        } else {
            score += energyFactor * 0.3;
        }
        
        // Conservation factor
        if (isLongTrip && pattern.conserveEnergyForLongTrips) {
            score -= profile.conservationFactor * 0.4;
        }
        
        // Efficiency factor
        score += profile.efficiencyFactor * 0.2;
        
        // Pathing preferences influence
        score += pathingPrefs.speedPreference * 0.3;
        score -= pathingPrefs.scenicPreference * 0.2;
        
        // Random walk chance
        if (ThreadLocalRandom.current().nextDouble() < pattern.randomWalkChance) {
            score -= 0.3;
        }
        
        // Energy conservation chance
        if (ThreadLocalRandom.current().nextDouble() < pattern.energyConservationChance) {
            score -= 0.2;
        }
        
        return Math.max(0.0, Math.min(1.0, score));
    }
    
    /**
     * Get personality-based randomness
     */
    private double getPersonalityRandomness(String personality) {
        switch (personality) {
            case "efficient_player":
                return ThreadLocalRandom.current().nextDouble(-0.1, 0.1);
            case "chill_player":
                return ThreadLocalRandom.current().nextDouble(-0.2, 0.2);
            case "newbie":
                return ThreadLocalRandom.current().nextDouble(-0.15, 0.15);
            case "veteran":
                return ThreadLocalRandom.current().nextDouble(-0.05, 0.05);
            default:
                return ThreadLocalRandom.current().nextDouble(-0.1, 0.1);
        }
    }
    
    /**
     * Check if player is near resources
     */
    private boolean isNearResources(Tile tile) {
        // Check for nearby trees, rocks, fishing spots, etc.
        return org.dreambot.api.methods.interactive.GameObjects.closest(obj -> 
            obj != null && (obj.getName().contains("Tree") || 
                           obj.getName().contains("Rock") || 
                           obj.getName().contains("Fishing spot"))) != null;
    }
    
    /**
     * Update current run energy
     */
    private void updateRunEnergy() {
        currentRunEnergy = Walking.getRunEnergy();
        lastRunEnergyCheck = System.currentTimeMillis();
    }
    
    /**
     * Toggle run energy with personality-based timing
     */
    private void toggleRun(boolean enable) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastRunToggle < 2000) { // Prevent rapid toggling
            return;
        }
        
        // Toggle run if needed
        if (Walking.isRunEnabled() != enable) {
            Walking.toggleRun();
            wasRunning = enable;
            lastRunToggle = currentTime;
            
            String personality = profileCache.getCurrentPersonality();
            Logger.log("[RunEnergyManager] " + personality + " " + (enable ? "enabled" : "disabled") + " run energy");
        }
    }
    
    /**
     * Record run decision for analysis
     */
    private void recordDecision(boolean decidedToRun, double distance, boolean inCombat, 
                              boolean nearResources, boolean isLongTrip, double decisionScore) {
        RunDecision decision = new RunDecision(
            decidedToRun,
            distance,
            inCombat,
            nearResources,
            isLongTrip,
            decisionScore,
            currentRunEnergy,
            System.currentTimeMillis()
        );
        
        decisionHistory.add(decision);
        totalDecisions++;
        
        if (decidedToRun) {
            runDecisions++;
        } else {
            walkDecisions++;
        }
        
        // Keep only recent history
        if (decisionHistory.size() > 500) {
            decisionHistory.remove(0);
        }
    }
    
    /**
     * Get run energy statistics
     */
    public RunEnergyStatistics getStatistics() {
        double runPercentage = totalDecisions > 0 ? (double) runDecisions / totalDecisions * 100 : 0;
        
        return new RunEnergyStatistics(
            totalDecisions,
            runDecisions,
            walkDecisions,
            runPercentage,
            currentRunEnergy,
            decisionHistory.size()
        );
    }
    
    /**
     * Get optimal run energy threshold for current personality
     */
    public int getOptimalRunThreshold() {
        String personality = profileCache.getCurrentPersonality();
        RunEnergyProfile profile = personalityProfiles.getOrDefault(personality, 
            personalityProfiles.get("casual_player"));
        
        return (int) (profile.runThreshold * 100);
    }
    
    /**
     * Check if should conserve energy for upcoming long trip
     */
    public boolean shouldConserveEnergy() {
        String personality = profileCache.getCurrentPersonality();
        RunEnergyPattern pattern = personalityPatterns.getOrDefault(personality,
            personalityPatterns.get("casual_player"));
        
        return pattern.conserveEnergyForLongTrips && currentRunEnergy < 50;
    }
    
    /**
     * Run energy profile for different personalities
     */
    public static class RunEnergyProfile {
        public final double runThreshold;      // Energy level threshold for using run
        public final double runPreference;     // General preference for running
        public final double walkPreference;    // General preference for walking
        public final double conservationFactor; // How much to conserve energy
        public final double efficiencyFactor;  // How much to prioritize efficiency
        
        public RunEnergyProfile(double threshold, double runPref, double walkPref, 
                              double conservation, double efficiency) {
            this.runThreshold = threshold;
            this.runPreference = runPref;
            this.walkPreference = walkPref;
            this.conservationFactor = conservation;
            this.efficiencyFactor = efficiency;
        }
    }
    
    /**
     * Run energy pattern for different personalities
     */
    public static class RunEnergyPattern {
        public final boolean useRunForShortDistances;
        public final boolean useRunInCombat;
        public final boolean useRunForResourceGathering;
        public final boolean conserveEnergyForLongTrips;
        public final double randomWalkChance;
        public final double energyConservationChance;
        
        public RunEnergyPattern(boolean shortDist, boolean combat, boolean resources,
                              boolean conserve, double randomChance, double conservationChance) {
            this.useRunForShortDistances = shortDist;
            this.useRunInCombat = combat;
            this.useRunForResourceGathering = resources;
            this.conserveEnergyForLongTrips = conserve;
            this.randomWalkChance = randomChance;
            this.energyConservationChance = conservationChance;
        }
    }
    
    /**
     * Run decision record for analysis
     */
    public static class RunDecision {
        public final boolean decidedToRun;
        public final double distance;
        public final boolean inCombat;
        public final boolean nearResources;
        public final boolean isLongTrip;
        public final double decisionScore;
        public final int runEnergy;
        public final long timestamp;
        
        public RunDecision(boolean run, double dist, boolean combat, boolean resources,
                          boolean longTrip, double score, int energy, long time) {
            this.decidedToRun = run;
            this.distance = dist;
            this.inCombat = combat;
            this.nearResources = resources;
            this.isLongTrip = longTrip;
            this.decisionScore = score;
            this.runEnergy = energy;
            this.timestamp = time;
        }
    }
    
    /**
     * Run energy statistics
     */
    public static class RunEnergyStatistics {
        public final int totalDecisions;
        public final int runDecisions;
        public final int walkDecisions;
        public final double runPercentage;
        public final int currentRunEnergy;
        public final int decisionHistorySize;
        
        public RunEnergyStatistics(int total, int run, int walk, double percentage, 
                                 int energy, int historySize) {
            this.totalDecisions = total;
            this.runDecisions = run;
            this.walkDecisions = walk;
            this.runPercentage = percentage;
            this.currentRunEnergy = energy;
            this.decisionHistorySize = historySize;
        }
    }
} 