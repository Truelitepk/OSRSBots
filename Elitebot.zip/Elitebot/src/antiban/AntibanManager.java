package antiban;

import org.dreambot.api.methods.input.Camera;
import org.dreambot.api.input.Mouse;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.wrappers.interactive.Player;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;

import java.awt.*;
import java.util.Random;

public class AntibanManager {

    private final FatigueTracker fatigue;
    private final UUIDProfileCache profile;
    private final Random random = new Random();
    private final MouseHeatmap mouseHeatmap;
    private final HumanMouseSimulator humanMouseSimulator;

    private int ticksSinceLastInterrupt = 0;

    public AntibanManager(UUIDProfileCache profile, MouseHeatmap mouseHeatmap) {
        this.profile = profile;
        this.mouseHeatmap = mouseHeatmap;
        this.fatigue = new FatigueTracker();
        this.humanMouseSimulator = new HumanMouseSimulator(mouseHeatmap);
        applyProfileSettings();
    }

    private void applyProfileSettings() {
        int reactionTime = profile.getReactionMin() + random.nextInt(profile.getReactionMax() - profile.getReactionMin());
        Logger.log("Antiban: Mouse reaction time set to: " + reactionTime);
    }

    public void tick() {
        fatigue.increaseFatigue(1);
        ticksSinceLastInterrupt++;

        simulateCameraDrift();
        maybeHoverRandomTab();
        maybeAFK();
        maybeMisclick();
        maybeInterruptBehavior();
    }

    private void simulateCameraDrift() {
        if (random.nextInt(100) < 5) {
            int yawChange = random.nextInt(20) - 10;
            int pitchChange = random.nextInt(10) - 5;
            
            Camera.rotateToYaw(Camera.getYaw() + yawChange);
            Camera.rotateToPitch(Camera.getPitch() + pitchChange);
        }
    }

    private void maybeHoverRandomTab() {
        if (random.nextInt(100) < 3) {
            Tab[] tabs = Tab.values();
            Tab randomTab = tabs[random.nextInt(tabs.length)];
            
            if (!Tabs.isOpen(randomTab)) {
                Tabs.open(randomTab);
                Sleep.sleep(200, 500);
            }
        }
    }

    private void maybeAFK() {
        if (random.nextInt(100) < 2) {
            int afkTime = random.nextInt(5000) + 2000; // 2-7 seconds
            Logger.log("Antiban: AFK for " + afkTime + "ms");
            Sleep.sleep(afkTime);
        }
    }

    private void maybeMisclick() {
        if (random.nextInt(100) < 1) {
            Point currentPos = Mouse.getPosition();
            Point misclickPos = new Point(
                currentPos.x + random.nextInt(20) - 10,
                currentPos.y + random.nextInt(20) - 10
            );
            
            Mouse.move(misclickPos);
            Sleep.sleep(100, 300);
            Mouse.move(currentPos);
        }
    }

    private void maybeInterruptBehavior() {
        if (random.nextInt(100) < 2) {
            // Random camera movement
            Camera.rotateToYaw(Camera.getYaw() + random.nextInt(30) - 15);
            Sleep.sleep(500, 1000);
        }
    }

    public void performRandomAction() {
        int action = random.nextInt(5);
        
        switch (action) {
            case 0:
                simulateCameraDrift();
                break;
            case 1:
                maybeHoverRandomTab();
                break;
            case 2:
                maybeAFK();
                break;
            case 3:
                maybeMisclick();
                break;
            case 4:
                maybeInterruptBehavior();
                break;
        }
    }

    public Point getHeatmapBiasedClick(Rectangle area) {
        return mouseHeatmap.getBiasedClickPoint(area);
    }

    public void executeHumanClick(Point target) {
        humanMouseSimulator.executeHumanHover(target);
    }

    public int sleepShort() {
        return random.nextInt(300) + 200;
    }

    public int sleepMedium() {
        return random.nextInt(600) + 400;
    }

    public int sleepLong() {
        return random.nextInt(1000) + 800;
    }

    public void sleep(int min, int max) {
        Sleep.sleep(min, max);
    }

    public UUIDProfileCache getProfile() {
        return profile;
    }

    public MouseHeatmap getMouseHeatmap() {
        return mouseHeatmap;
    }
}