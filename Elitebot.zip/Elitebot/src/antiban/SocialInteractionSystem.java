package antiban;

import org.dreambot.api.utilities.Logger;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.wrappers.interactive.Player;
import org.dreambot.api.utilities.Sleep;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SocialInteractionSystem {
    
    private final Random random = ThreadLocalRandom.current();
    private final ExecutorService executorService = Executors.newCachedThreadPool();
    
    // Social data
    private final Map<String, Friend> friends = new ConcurrentHashMap<>();
    private final Map<String, ClanMember> clanMembers = new ConcurrentHashMap<>();
    private final List<SocialEvent> socialEvents = new ArrayList<>();
    private final Map<String, TradeOffer> tradeOffers = new ConcurrentHashMap<>();
    
    // Interaction patterns
    private final Map<String, List<String>> conversationTopics = new HashMap<>();
    private final Map<String, List<String>> groupActivities = new HashMap<>();
    private final Map<String, Double> playerReputation = new ConcurrentHashMap<>();
    
    // State tracking
    private boolean socialEnabled = true;
    private boolean clanEnabled = true;
    private boolean tradingEnabled = true;
    private double socialIntensity = 0.6;
    private long lastSocialInteraction;
    private int totalInteractions;
    
    // Configuration
    private static final long INTERACTION_COOLDOWN = 300000; // 5 minutes
    private static final long CLAN_CHECK_INTERVAL = 600000; // 10 minutes
    private static final long FRIEND_UPDATE_INTERVAL = 900000; // 15 minutes
    
    public SocialInteractionSystem() {
        initializeConversationTopics();
        initializeGroupActivities();
        
        Logger.log("Social Interaction System initialized");
    }
    
    private void initializeConversationTopics() {
        // General topics
        conversationTopics.put("general", Arrays.asList(
            "How's your day going?", "What are you working on?", "Nice weather we're having!",
            "How's the grind?", "Any good drops lately?", "What's your goal right now?"
        ));
        
        // Skill-related topics
        conversationTopics.put("skills", Arrays.asList(
            "What skill are you training?", "How's the XP going?", "Any good methods you've found?",
            "What's your favorite skill?", "Working towards any specific level?", "How's the grind?"
        ));
        
        // PvM topics
        conversationTopics.put("pvm", Arrays.asList(
            "Been doing any bossing?", "Any good drops?", "What's your favorite boss?",
            "How's the PvM going?", "Any raids lately?", "What gear are you using?"
        ));
        
        // PvP topics
        conversationTopics.put("pvp", Arrays.asList(
            "Been doing any PvP?", "How's the PK scene?", "What's your favorite PK spot?",
            "Any good kills lately?", "What gear do you PK in?", "How's the bridge?"
        ));
        
        // Quest topics
        conversationTopics.put("quests", Arrays.asList(
            "Working on any quests?", "What's your quest point count?", "Any hard quests you've done?",
            "Quest cape progress?", "What's your favorite quest?", "Any quest rewards you're after?"
        ));
        
        // Money making topics
        conversationTopics.put("money", Arrays.asList(
            "What's your money making method?", "How's the GP coming along?", "Any good flips lately?",
            "What's your bank worth?", "Any expensive items you're saving for?", "How do you make money?"
        ));
    }
    
    private void initializeGroupActivities() {
        // Group activities that players can participate in
        groupActivities.put("bossing", Arrays.asList(
            "God Wars Dungeon", "Dagannoth Kings", "Kalphite Queen", "Zulrah", "Vorkath"
        ));
        
        groupActivities.put("raids", Arrays.asList(
            "Chambers of Xeric", "Theatre of Blood", "Tombs of Amascut"
        ));
        
        groupActivities.put("minigames", Arrays.asList(
            "Pest Control", "Barbarian Assault", "Castle Wars", "Stealing Creation"
        ));
        
        groupActivities.put("social", Arrays.asList(
            "House parties", "Drop parties", "Fashion contests", "Hide and seek"
        ));
        
        groupActivities.put("skilling", Arrays.asList(
            "Wintertodt", "Tempoross", "Zalcano", "Hallowed Sepulchre"
        ));
    }
    
    public void startSocialMonitoring() {
        if (!socialEnabled) {
            return;
        }
        
        CompletableFuture.runAsync(() -> {
            while (socialEnabled) {
                try {
                    // Monitor nearby players
                    monitorNearbyPlayers();
                    
                    // Update friend status
                    updateFriendStatus();
                    
                    // Check clan activities
                    if (clanEnabled) {
                        checkClanActivities();
                    }
                    
                    // Process trade offers
                    if (tradingEnabled) {
                        processTradeOffers();
                    }
                    
                    // Generate social interactions
                    generateSocialInteractions();
                    
                    Sleep.sleep(30000); // Check every 30 seconds
                } catch (Exception e) {
                    Logger.log("Error in social monitoring: " + e.getMessage());
                }
            }
        }, executorService);
    }
    
    private void monitorNearbyPlayers() {
        List<Player> nearbyPlayers = Players.all();
        
        for (Player player : nearbyPlayers) {
            if (player != null && !player.getName().equals(Players.getLocal().getName())) {
                String playerName = player.getName();
                
                // Check if player is a friend
                if (friends.containsKey(playerName)) {
                    Friend friend = friends.get(playerName);
                    friend.updateLastSeen(System.currentTimeMillis());
                    
                    // Chance to interact with friend
                    if (shouldInteractWithPlayer(playerName)) {
                        interactWithFriend(friend);
                    }
                } else {
                    // Check if player is a clan member
                    if (clanMembers.containsKey(playerName)) {
                        ClanMember member = clanMembers.get(playerName);
                        member.updateLastSeen(System.currentTimeMillis());
                        
                        // Chance to interact with clan member
                        if (shouldInteractWithPlayer(playerName)) {
                            interactWithClanMember(member);
                        }
                    } else {
                        // Random chance to interact with stranger
                        if (shouldInteractWithPlayer(playerName) && random.nextDouble() < 0.1) {
                            interactWithStranger(playerName);
                        }
                    }
                }
            }
        }
    }
    
    private boolean shouldInteractWithPlayer(String playerName) {
        long currentTime = System.currentTimeMillis();
        
        // Check cooldown
        if (currentTime - lastSocialInteraction < INTERACTION_COOLDOWN) {
            return false;
        }
        
        // Check player reputation
        double reputation = playerReputation.getOrDefault(playerName, 0.5);
        if (reputation < 0.2) {
            return false; // Avoid players with bad reputation
        }
        
        // Random chance based on social intensity
        return random.nextDouble() < socialIntensity * 0.3;
    }
    
    private void interactWithFriend(Friend friend) {
        String topic = selectConversationTopic();
        String message = generateConversationMessage(topic, friend.getName());
        
        // Record interaction
        SocialEvent event = new SocialEvent(
            friend.getName(),
            "friend_interaction",
            message,
            System.currentTimeMillis()
        );
        socialEvents.add(event);
        
        totalInteractions++;
        lastSocialInteraction = System.currentTimeMillis();
        
        Logger.log("Friend interaction with " + friend.getName() + ": " + message);
    }
    
    private void interactWithClanMember(ClanMember member) {
        String topic = selectConversationTopic();
        String message = generateConversationMessage(topic, member.getName());
        
        // Record interaction
        SocialEvent event = new SocialEvent(
            member.getName(),
            "clan_interaction",
            message,
            System.currentTimeMillis()
        );
        socialEvents.add(event);
        
        totalInteractions++;
        lastSocialInteraction = System.currentTimeMillis();
        
        Logger.log("Clan interaction with " + member.getName() + ": " + message);
    }
    
    private void interactWithStranger(String playerName) {
        String topic = selectConversationTopic();
        String message = generateConversationMessage(topic, playerName);
        
        // Record interaction
        SocialEvent event = new SocialEvent(
            playerName,
            "stranger_interaction",
            message,
            System.currentTimeMillis()
        );
        socialEvents.add(event);
        
        totalInteractions++;
        lastSocialInteraction = System.currentTimeMillis();
        
        Logger.log("Stranger interaction with " + playerName + ": " + message);
    }
    
    private String selectConversationTopic() {
        List<String> topics = new ArrayList<>(conversationTopics.keySet());
        return topics.get(random.nextInt(topics.size()));
    }
    
    private String generateConversationMessage(String topic, String playerName) {
        List<String> messages = conversationTopics.get(topic);
        if (messages != null && !messages.isEmpty()) {
            String baseMessage = messages.get(random.nextInt(messages.size()));
            
            // Personalize message
            if (random.nextDouble() < 0.3) {
                baseMessage = "Hey " + playerName + "! " + baseMessage;
            }
            
            return baseMessage;
        }
        
        return "Hello!";
    }
    
    private void updateFriendStatus() {
        long currentTime = System.currentTimeMillis();
        
        for (Friend friend : friends.values()) {
            // Update friend status based on last interaction
            long timeSinceLastInteraction = currentTime - friend.getLastInteraction();
            
            if (timeSinceLastInteraction > FRIEND_UPDATE_INTERVAL) {
                // Friend hasn't been active, update status
                friend.setStatus("inactive");
            } else {
                friend.setStatus("active");
            }
        }
    }
    
    private void checkClanActivities() {
        // Simulate clan activities
        if (random.nextDouble() < 0.1) { // 10% chance
            String activity = selectGroupActivity();
            
            SocialEvent event = new SocialEvent(
                "Clan",
                "clan_activity",
                "Clan is doing: " + activity,
                System.currentTimeMillis()
            );
            socialEvents.add(event);
            
            Logger.log("Clan activity: " + activity);
        }
    }
    
    private String selectGroupActivity() {
        List<String> activityTypes = new ArrayList<>(groupActivities.keySet());
        String activityType = activityTypes.get(random.nextInt(activityTypes.size()));
        
        List<String> activities = groupActivities.get(activityType);
        if (activities != null && !activities.isEmpty()) {
            return activities.get(random.nextInt(activities.size()));
        }
        
        return "General clan activity";
    }
    
    private void processTradeOffers() {
        // Simulate trade offers
        if (random.nextDouble() < 0.05) { // 5% chance
            String item = selectRandomTradeItem();
            int quantity = random.nextInt(100) + 1;
            int price = random.nextInt(10000) + 100;
            
            TradeOffer offer = new TradeOffer(
                "RandomPlayer" + random.nextInt(1000),
                item,
                quantity,
                price,
                System.currentTimeMillis()
            );
            
            tradeOffers.put(offer.getPlayerName() + "_" + System.currentTimeMillis(), offer);
            
            Logger.log("Received trade offer: " + quantity + "x " + item + " for " + price + " GP each");
        }
    }
    
    private String selectRandomTradeItem() {
        List<String> commonItems = Arrays.asList(
            "Rune scimitar", "Dragon dagger", "Rune platebody", "Rune full helm",
            "Rune boots", "Rune gloves", "Rune kiteshield", "Rune 2h sword"
        );
        
        return commonItems.get(random.nextInt(commonItems.size()));
    }
    
    private void generateSocialInteractions() {
        // Generate random social interactions
        if (random.nextDouble() < socialIntensity * 0.2) {
            String interaction = generateRandomInteraction();
            
            SocialEvent event = new SocialEvent(
                "System",
                "random_interaction",
                interaction,
                System.currentTimeMillis()
            );
            socialEvents.add(event);
            
            Logger.log("Random social interaction: " + interaction);
        }
    }
    
    private String generateRandomInteraction() {
        List<String> interactions = Arrays.asList(
            "Waves at nearby players", "Says hello to everyone", "Shares a joke",
            "Compliments someone's gear", "Asks for advice", "Offers help",
            "Talks about recent achievements", "Discusses game updates"
        );
        
        return interactions.get(random.nextInt(interactions.size()));
    }
    
    public void addFriend(String playerName) {
        Friend friend = new Friend(playerName, System.currentTimeMillis());
        friends.put(playerName, friend);
        Logger.log("Added friend: " + playerName);
    }
    
    public void removeFriend(String playerName) {
        friends.remove(playerName);
        Logger.log("Removed friend: " + playerName);
    }
    
    public void addClanMember(String playerName, String rank) {
        ClanMember member = new ClanMember(playerName, rank, System.currentTimeMillis());
        clanMembers.put(playerName, member);
        Logger.log("Added clan member: " + playerName + " (Rank: " + rank + ")");
    }
    
    public void updatePlayerReputation(String playerName, double reputation) {
        playerReputation.put(playerName, Math.max(0.0, Math.min(1.0, reputation)));
    }
    
    public void setSocialEnabled(boolean enabled) {
        this.socialEnabled = enabled;
        Logger.log("Social interactions " + (enabled ? "enabled" : "disabled"));
    }
    
    public void setClanEnabled(boolean enabled) {
        this.clanEnabled = enabled;
        Logger.log("Clan interactions " + (enabled ? "enabled" : "disabled"));
    }
    
    public void setTradingEnabled(boolean enabled) {
        this.tradingEnabled = enabled;
        Logger.log("Trading " + (enabled ? "enabled" : "disabled"));
    }
    
    public void setSocialIntensity(double intensity) {
        this.socialIntensity = Math.max(0.0, Math.min(1.0, intensity));
        Logger.log("Social intensity set to: " + socialIntensity);
    }
    
    // Getters
    public boolean isSocialEnabled() { return socialEnabled; }
    public boolean isClanEnabled() { return clanEnabled; }
    public boolean isTradingEnabled() { return tradingEnabled; }
    public double getSocialIntensity() { return socialIntensity; }
    public int getTotalInteractions() { return totalInteractions; }
    public long getLastSocialInteraction() { return lastSocialInteraction; }
    public Map<String, Friend> getFriends() { return new HashMap<>(friends); }
    public Map<String, ClanMember> getClanMembers() { return new HashMap<>(clanMembers); }
    public List<SocialEvent> getSocialEvents() { return new ArrayList<>(socialEvents); }
    public Map<String, TradeOffer> getTradeOffers() { return new HashMap<>(tradeOffers); }
    
    // Inner classes
    
    public static class Friend {
        private final String name;
        private final long addedTime;
        private long lastInteraction;
        private long lastSeen;
        private String status;
        
        public Friend(String name, long addedTime) {
            this.name = name;
            this.addedTime = addedTime;
            this.lastInteraction = addedTime;
            this.lastSeen = addedTime;
            this.status = "active";
        }
        
        public void updateLastSeen(long time) {
            this.lastSeen = time;
        }
        
        public void updateLastInteraction(long time) {
            this.lastInteraction = time;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        // Getters
        public String getName() { return name; }
        public long getAddedTime() { return addedTime; }
        public long getLastInteraction() { return lastInteraction; }
        public long getLastSeen() { return lastSeen; }
        public String getStatus() { return status; }
    }
    
    public static class ClanMember {
        private final String name;
        private final String rank;
        private final long joinedTime;
        private long lastSeen;
        
        public ClanMember(String name, String rank, long joinedTime) {
            this.name = name;
            this.rank = rank;
            this.joinedTime = joinedTime;
            this.lastSeen = joinedTime;
        }
        
        public void updateLastSeen(long time) {
            this.lastSeen = time;
        }
        
        // Getters
        public String getName() { return name; }
        public String getRank() { return rank; }
        public long getJoinedTime() { return joinedTime; }
        public long getLastSeen() { return lastSeen; }
    }
    
    public static class SocialEvent {
        private final String playerName;
        private final String eventType;
        private final String message;
        private final long timestamp;
        
        public SocialEvent(String playerName, String eventType, String message, long timestamp) {
            this.playerName = playerName;
            this.eventType = eventType;
            this.message = message;
            this.timestamp = timestamp;
        }
        
        // Getters
        public String getPlayerName() { return playerName; }
        public String getEventType() { return eventType; }
        public String getMessage() { return message; }
        public long getTimestamp() { return timestamp; }
    }
    
    public static class TradeOffer {
        private final String playerName;
        private final String item;
        private final int quantity;
        private final int price;
        private final long timestamp;
        
        public TradeOffer(String playerName, String item, int quantity, int price, long timestamp) {
            this.playerName = playerName;
            this.item = item;
            this.quantity = quantity;
            this.price = price;
            this.timestamp = timestamp;
        }
        
        // Getters
        public String getPlayerName() { return playerName; }
        public String getItem() { return item; }
        public int getQuantity() { return quantity; }
        public int getPrice() { return price; }
        public long getTimestamp() { return timestamp; }
        public int getTotalValue() { return quantity * price; }
    }
} 