package antiban;

import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Advanced Timing Engine with personality-based timing patterns
 * Surpasses P2P AI with sophisticated timing variations and human-like delays
 */
public class TimingEngine {
    
    private final UUIDProfileCache profileCache;
    private final Map<String, TimingProfile> personalityTimings;
    private final List<TimingEvent> timingHistory = new ArrayList<>();
    private final Map<String, Double> actionTimingAverages = new HashMap<>();
    
    // Advanced timing patterns
    private final Map<String, TimingPattern> personalityPatterns;
    private final Queue<Long> reactionTimes = new LinkedList<>();
    private final Map<String, Integer> actionDelays = new HashMap<>();
    
    // Timing state tracking
    private long lastActionTime = 0;
    private long sessionStartTime = System.currentTimeMillis();
    private int totalActions = 0;
    private double averageReactionTime = 0.0;
    
    // Personality-driven timing
    private String currentPersonality;
    private final Map<String, PersonalityTiming> personalityTimings_advanced;
    
    public TimingEngine(UUIDProfileCache profileCache) {
        this.profileCache = profileCache;
        this.personalityTimings = initializePersonalityTimings();
        this.personalityPatterns = initializePersonalityPatterns();
        this.personalityTimings_advanced = initializeAdvancedPersonalityTimings();
        this.currentPersonality = profileCache.getCurrentPersonality();
        
        Logger.log("[TimingEngine] Initialized with personality-based timing patterns");
    }
    
    /**
     * Initialize personality-based timing profiles
     */
    private Map<String, TimingProfile> initializePersonalityTimings() {
        Map<String, TimingProfile> timings = new HashMap<>();
        
        // Efficient player - fast, consistent timing
        timings.put("efficient_player", new TimingProfile(
            50,   // Min reaction time
            150,  // Max reaction time
            0.1,  // Timing variance
            0.9,  // Consistency factor
            0.1,  // Hesitation factor
            0.05  // Random delay chance
        ));
        
        // Chill player - relaxed, variable timing
        timings.put("chill_player", new TimingProfile(
            200,  // Min reaction time
            800,  // Max reaction time
            0.4,  // Timing variance
            0.5,  // Consistency factor
            0.6,  // Hesitation factor
            0.3   // Random delay chance
        ));
        
        // Newbie - slow, hesitant timing
        timings.put("newbie", new TimingProfile(
            300,  // Min reaction time
            1200, // Max reaction time
            0.6,  // Timing variance
            0.3,  // Consistency factor
            0.8,  // Hesitation factor
            0.4   // Random delay chance
        ));
        
        // Veteran - balanced, experienced timing
        timings.put("veteran", new TimingProfile(
            80,   // Min reaction time
            300,  // Max reaction time
            0.2,  // Timing variance
            0.8,  // Consistency factor
            0.2,  // Hesitation factor
            0.1   // Random delay chance
        ));
        
        // Casual player - moderate timing
        timings.put("casual_player", new TimingProfile(
            100,  // Min reaction time
            500,  // Max reaction time
            0.3,  // Timing variance
            0.7,  // Consistency factor
            0.4,  // Hesitation factor
            0.2   // Random delay chance
        ));
        
        return timings;
    }
    
    /**
     * Initialize personality-based timing patterns
     */
    private Map<String, TimingPattern> initializePersonalityPatterns() {
        Map<String, TimingPattern> patterns = new HashMap<>();
        
        // Efficient player pattern
        patterns.put("efficient_player", new TimingPattern(
            true,   // Quick reactions
            false,  // Hesitation
            true,   // Consistent timing
            false,  // Random delays
            0.1,    // Fatigue factor
            0.9     // Focus factor
        ));
        
        // Chill player pattern
        patterns.put("chill_player", new TimingPattern(
            false,  // Quick reactions
            true,   // Hesitation
            false,  // Consistent timing
            true,   // Random delays
            0.6,    // Fatigue factor
            0.4     // Focus factor
        ));
        
        // Newbie pattern
        patterns.put("newbie", new TimingPattern(
            false,  // Quick reactions
            true,   // Hesitation
            false,  // Consistent timing
            true,   // Random delays
            0.8,    // Fatigue factor
            0.2     // Focus factor
        ));
        
        // Veteran pattern
        patterns.put("veteran", new TimingPattern(
            true,   // Quick reactions
            false,  // Hesitation
            true,   // Consistent timing
            false,  // Random delays
            0.2,    // Fatigue factor
            0.8     // Focus factor
        ));
        
        // Casual player pattern
        patterns.put("casual_player", new TimingPattern(
            false,  // Quick reactions
            true,   // Hesitation
            true,   // Consistent timing
            true,   // Random delays
            0.4,    // Fatigue factor
            0.6     // Focus factor
        ));
        
        return patterns;
    }
    
    /**
     * Initialize advanced personality timings
     */
    private Map<String, PersonalityTiming> initializeAdvancedPersonalityTimings() {
        Map<String, PersonalityTiming> timings = new HashMap<>();
        
        // Efficient player advanced timing
        timings.put("efficient_player", new PersonalityTiming(
            Arrays.asList("quick_click", "fast_movement", "rapid_skill_check"),
            Arrays.asList("slow_reaction", "hesitant_action", "afk_behavior"),
            0.05, // AFK tendency
            0.95, // Skill check frequency
            0.9   // Movement efficiency
        ));
        
        // Chill player advanced timing
        timings.put("chill_player", new PersonalityTiming(
            Arrays.asList("slow_reaction", "relaxed_movement", "occasional_afk"),
            Arrays.asList("quick_action", "efficient_movement", "constant_activity"),
            0.6,  // AFK tendency
            0.3,  // Skill check frequency
            0.4   // Movement efficiency
        ));
        
        // Newbie advanced timing
        timings.put("newbie", new PersonalityTiming(
            Arrays.asList("hesitant_click", "slow_movement", "multiple_checks"),
            Arrays.asList("confident_action", "quick_movement", "single_check"),
            0.3,  // AFK tendency
            0.5,  // Skill check frequency
            0.3   // Movement efficiency
        ));
        
        // Veteran advanced timing
        timings.put("veteran", new PersonalityTiming(
            Arrays.asList("precise_click", "efficient_movement", "strategic_check"),
            Arrays.asList("random_action", "inefficient_movement", "constant_check"),
            0.2,  // AFK tendency
            0.7,  // Skill check frequency
            0.8   // Movement efficiency
        ));
        
        // Casual player advanced timing
        timings.put("casual_player", new PersonalityTiming(
            Arrays.asList("moderate_click", "balanced_movement", "occasional_check"),
            Arrays.asList("extreme_speed", "constant_afk", "no_checks"),
            0.4,  // AFK tendency
            0.5,  // Skill check frequency
            0.6   // Movement efficiency
        ));
        
        return timings;
    }
    
    /**
     * Get human-like walking delay
     */
    public int getHumanWalkingDelay() {
        TimingProfile profile = personalityTimings.getOrDefault(currentPersonality, 
            personalityTimings.get("casual_player"));
        
        int baseDelay = ThreadLocalRandom.current().nextInt(profile.minReactionTime, profile.maxReactionTime);
        
        // Apply personality-based modifications
        baseDelay = applyPersonalityModifications(baseDelay, "walking");
        
        // Add fatigue factor
        baseDelay += getFatigueDelay();
        
        // Add random variance
        baseDelay += (int) (baseDelay * profile.timingVariance * ThreadLocalRandom.current().nextDouble());
        
        return Math.max(100, baseDelay);
    }
    
    /**
     * Get human-like interaction delay
     */
    public int getHumanInteractionDelay() {
        TimingProfile profile = personalityTimings.getOrDefault(currentPersonality, 
            personalityTimings.get("casual_player"));
        
        int baseDelay = ThreadLocalRandom.current().nextInt(profile.minReactionTime, profile.maxReactionTime);
        
        // Apply personality-based modifications
        baseDelay = applyPersonalityModifications(baseDelay, "interaction");
        
        // Add hesitation factor
        if (ThreadLocalRandom.current().nextDouble() < profile.hesitationFactor) {
            baseDelay += ThreadLocalRandom.current().nextInt(100, 300);
        }
        
        // Add random delay chance
        if (ThreadLocalRandom.current().nextDouble() < profile.randomDelayChance) {
            baseDelay += ThreadLocalRandom.current().nextInt(200, 800);
        }
        
        return Math.max(50, baseDelay);
    }
    
    /**
     * Get human-like skill check delay
     */
    public int getHumanSkillCheckDelay() {
        TimingProfile profile = personalityTimings.getOrDefault(currentPersonality, 
            personalityTimings.get("casual_player"));
        
        int baseDelay = ThreadLocalRandom.current().nextInt(profile.minReactionTime, profile.maxReactionTime);
        
        // Apply personality-based modifications
        baseDelay = applyPersonalityModifications(baseDelay, "skill_check");
        
        // Add skill check specific timing
        PersonalityTiming personalityTiming = personalityTimings_advanced.get(currentPersonality);
        if (personalityTiming != null) {
            if (ThreadLocalRandom.current().nextDouble() < personalityTiming.skillCheckFrequency) {
                baseDelay = (int) (baseDelay * 0.8); // Faster skill checks
            } else {
                baseDelay = (int) (baseDelay * 1.5); // Slower skill checks
            }
        }
        
        return Math.max(100, baseDelay);
    }
    
    /**
     * Get next action delay
     */
    public long getNextActionDelay() {
        TimingProfile profile = personalityTimings.getOrDefault(currentPersonality, 
            personalityTimings.get("casual_player"));
        
        long baseDelay = ThreadLocalRandom.current().nextLong(profile.minReactionTime, profile.maxReactionTime);
        
        // Apply consistency factor
        baseDelay = (long) (baseDelay * (1.0 - profile.consistencyFactor * 0.5));
        
        // Add session fatigue
        long sessionTime = System.currentTimeMillis() - sessionStartTime;
        if (sessionTime > 300000) { // After 5 minutes
            baseDelay += sessionTime / 60000; // Add 1ms per minute
        }
        
        // Add action fatigue
        if (totalActions > 100) {
            baseDelay += totalActions / 10; // Add 1ms per 10 actions
        }
        
        return Math.max(50, baseDelay);
    }
    
    /**
     * Perform advanced timing action
     */
    public void performAdvancedTimingAction() {
        TimingPattern pattern = personalityPatterns.getOrDefault(currentPersonality,
            personalityPatterns.get("casual_player"));
        
        // Random timing action based on personality
        if (pattern.randomDelays && ThreadLocalRandom.current().nextDouble() < 0.3) {
            performRandomDelay();
        }
        
        if (pattern.hesitation && ThreadLocalRandom.current().nextDouble() < 0.2) {
            performHesitationAction();
        }
        
        if (pattern.quickReactions && ThreadLocalRandom.current().nextDouble() < 0.1) {
            performQuickReaction();
        }
        
        // Record timing event
        recordTimingEvent("advanced_action", System.currentTimeMillis());
    }
    
    /**
     * Apply personality-based modifications to timing
     */
    private int applyPersonalityModifications(int baseDelay, String actionType) {
        PersonalityTiming personalityTiming = personalityTimings_advanced.get(currentPersonality);
        if (personalityTiming == null) return baseDelay;
        
        // Check if action matches personality
        if (personalityTiming.positiveBehaviors.contains(actionType)) {
            baseDelay = (int) (baseDelay * 0.8); // Faster for positive behaviors
        } else if (personalityTiming.negativeBehaviors.contains(actionType)) {
            baseDelay = (int) (baseDelay * 1.3); // Slower for negative behaviors
        }
        
        // Apply AFK tendency
        if (ThreadLocalRandom.current().nextDouble() < personalityTiming.afkTendency) {
            baseDelay += ThreadLocalRandom.current().nextInt(500, 2000);
        }
        
        // Apply movement efficiency
        if (actionType.contains("movement")) {
            baseDelay = (int) (baseDelay * (1.0 - personalityTiming.movementEfficiency * 0.3));
        }
        
        return baseDelay;
    }
    
    /**
     * Get fatigue-based delay
     */
    private int getFatigueDelay() {
        TimingPattern pattern = personalityPatterns.getOrDefault(currentPersonality,
            personalityPatterns.get("casual_player"));
        
        long sessionTime = System.currentTimeMillis() - sessionStartTime;
        double fatigueMultiplier = 1.0 + (sessionTime / 600000.0) * pattern.fatigueFactor; // Fatigue over 10 minutes
        
        return (int) (ThreadLocalRandom.current().nextInt(50, 200) * fatigueMultiplier);
    }
    
    /**
     * Perform random delay
     */
    private void performRandomDelay() {
        int delay = ThreadLocalRandom.current().nextInt(1000, 5000);
        Sleep.sleep(delay);
        recordTimingEvent("random_delay", delay);
    }
    
    /**
     * Perform hesitation action
     */
    private void performHesitationAction() {
        int delay = ThreadLocalRandom.current().nextInt(200, 800);
        Sleep.sleep(delay);
        recordTimingEvent("hesitation", delay);
    }
    
    /**
     * Perform quick reaction
     */
    private void performQuickReaction() {
        int delay = ThreadLocalRandom.current().nextInt(50, 150);
        Sleep.sleep(delay);
        recordTimingEvent("quick_reaction", delay);
    }
    
    /**
     * Record timing event
     */
    private void recordTimingEvent(String eventType, long duration) {
        TimingEvent event = new TimingEvent(eventType, duration, System.currentTimeMillis());
        timingHistory.add(event);
        
        // Update averages
        actionTimingAverages.merge(eventType, (double) duration, (old, newVal) -> (old + newVal) / 2);
        
        // Update reaction times
        reactionTimes.offer(duration);
        if (reactionTimes.size() > 50) {
            reactionTimes.poll();
        }
        
        // Update total actions
        totalActions++;
        
        // Update average reaction time
        if (!reactionTimes.isEmpty()) {
            averageReactionTime = reactionTimes.stream()
                .mapToLong(Long::longValue)
                .average()
                .orElse(0.0);
        }
        
        // Keep history manageable
        if (timingHistory.size() > 200) {
            timingHistory.remove(0);
        }
    }
    
    /**
     * Get timing statistics
     */
    public TimingStatistics getStatistics() {
        return new TimingStatistics(
            totalActions,
            averageReactionTime,
            timingHistory.size(),
            actionTimingAverages.size(),
            System.currentTimeMillis() - sessionStartTime
        );
    }
    
    /**
     * Get optimal timing for personality
     */
    public int getOptimalTiming(String actionType) {
        TimingProfile profile = personalityTimings.getOrDefault(currentPersonality, 
            personalityTimings.get("casual_player"));
        
        int baseTiming = (profile.minReactionTime + profile.maxReactionTime) / 2;
        return applyPersonalityModifications(baseTiming, actionType);
    }
    
    /**
     * Timing profile for different personalities
     */
    public static class TimingProfile {
        public final int minReactionTime;
        public final int maxReactionTime;
        public final double timingVariance;
        public final double consistencyFactor;
        public final double hesitationFactor;
        public final double randomDelayChance;
        
        public TimingProfile(int min, int max, double variance, double consistency,
                           double hesitation, double randomChance) {
            this.minReactionTime = min;
            this.maxReactionTime = max;
            this.timingVariance = variance;
            this.consistencyFactor = consistency;
            this.hesitationFactor = hesitation;
            this.randomDelayChance = randomChance;
        }
    }
    
    /**
     * Timing pattern for different personalities
     */
    public static class TimingPattern {
        public final boolean quickReactions;
        public final boolean hesitation;
        public final boolean consistentTiming;
        public final boolean randomDelays;
        public final double fatigueFactor;
        public final double focusFactor;
        
        public TimingPattern(boolean quick, boolean hesitate, boolean consistent,
                           boolean random, double fatigue, double focus) {
            this.quickReactions = quick;
            this.hesitation = hesitate;
            this.consistentTiming = consistent;
            this.randomDelays = random;
            this.fatigueFactor = fatigue;
            this.focusFactor = focus;
        }
    }
    
    /**
     * Advanced personality timing
     */
    public static class PersonalityTiming {
        public final List<String> positiveBehaviors;
        public final List<String> negativeBehaviors;
        public final double afkTendency;
        public final double skillCheckFrequency;
        public final double movementEfficiency;
        
        public PersonalityTiming(List<String> positive, List<String> negative,
                               double afk, double skillCheck, double movement) {
            this.positiveBehaviors = positive;
            this.negativeBehaviors = negative;
            this.afkTendency = afk;
            this.skillCheckFrequency = skillCheck;
            this.movementEfficiency = movement;
        }
    }
    
    /**
     * Timing event record
     */
    public static class TimingEvent {
        public final String eventType;
        public final long duration;
        public final long timestamp;
        
        public TimingEvent(String type, long duration, long time) {
            this.eventType = type;
            this.duration = duration;
            this.timestamp = time;
        }
    }
    
    /**
     * Timing statistics
     */
    public static class TimingStatistics {
        public final int totalActions;
        public final double averageReactionTime;
        public final int timingHistorySize;
        public final int actionTypesCount;
        public final long sessionDuration;
        
        public TimingStatistics(int total, double avgReaction, int history, 
                              int actionTypes, long session) {
            this.totalActions = total;
            this.averageReactionTime = avgReaction;
            this.timingHistorySize = history;
            this.actionTypesCount = actionTypes;
            this.sessionDuration = session;
        }
    }
} 