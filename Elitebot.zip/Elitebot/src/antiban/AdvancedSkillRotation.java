package antiban;

import org.dreambot.api.utilities.Logger;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.utilities.Sleep;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AdvancedSkillRotation {
    
    private final Random random = ThreadLocalRandom.current();
    private final ExecutorService executorService = Executors.newCachedThreadPool();
    
    // Skill rotation data
    private final Map<Skill, SkillGoal> skillGoals = new ConcurrentHashMap<>();
    private final Map<Skill, Long> lastTrainingTime = new ConcurrentHashMap<>();
    private final Map<Skill, Integer> skillLevels = new ConcurrentHashMap<>();
    private final List<SkillSession> skillSessions = new ArrayList<>();
    
    // Rotation patterns
    private final Map<String, List<Skill>> skillGroups = new HashMap<>();
    private final Map<Skill, List<Skill>> skillSynergies = new HashMap<>();
    private final Map<Skill, Double> skillPriorities = new ConcurrentHashMap<>();
    
    // State tracking
    private Skill currentSkill;
    private long sessionStartTime;
    private int totalSessions;
    private boolean rotationEnabled = true;
    private double rotationIntensity = 0.7;
    
    // Configuration
    private static final long MIN_SESSION_TIME = 300000; // 5 minutes
    private static final long MAX_SESSION_TIME = 1800000; // 30 minutes
    private static final long BREAK_TIME = 600000; // 10 minutes
    private static final int MAX_LEVEL = 99;
    
    public AdvancedSkillRotation() {
        initializeSkillGroups();
        initializeSkillSynergies();
        initializeSkillGoals();
        
        Logger.log("Advanced Skill Rotation initialized");
    }
    
    private void initializeSkillGroups() {
        // Combat skills
        skillGroups.put("combat", Arrays.asList(
            Skill.ATTACK, Skill.STRENGTH, Skill.DEFENCE, 
            Skill.RANGED, Skill.MAGIC, Skill.PRAYER, Skill.HITPOINTS
        ));
        
        // Gathering skills
        skillGroups.put("gathering", Arrays.asList(
            Skill.MINING, Skill.WOODCUTTING, Skill.FISHING, 
            Skill.FARMING, Skill.HUNTER, Skill.THIEVING
        ));
        
        // Production skills
        skillGroups.put("production", Arrays.asList(
            Skill.SMITHING, Skill.CRAFTING, Skill.FLETCHING,
            Skill.HERBLORE, Skill.COOKING, Skill.FIREMAKING
        ));
        
        // Support skills
        skillGroups.put("support", Arrays.asList(
            Skill.AGILITY, Skill.CONSTRUCTION, Skill.RUNECRAFTING,
            Skill.SLAYER
        ));
        
        // AFK skills
        skillGroups.put("afk", Arrays.asList(
            Skill.WOODCUTTING, Skill.FISHING, Skill.MINING,
            Skill.THIEVING, Skill.FARMING
        ));
        
        // Fast XP skills
        skillGroups.put("fast_xp", Arrays.asList(
            Skill.FIREMAKING, Skill.COOKING, Skill.FLETCHING,
            Skill.CRAFTING, Skill.SMITHING
        ));
    }
    
    private void initializeSkillSynergies() {
        // Skills that work well together
        skillSynergies.put(Skill.MINING, Arrays.asList(Skill.SMITHING, Skill.CRAFTING));
        skillSynergies.put(Skill.WOODCUTTING, Arrays.asList(Skill.FIREMAKING, Skill.FLETCHING, Skill.CONSTRUCTION));
        skillSynergies.put(Skill.FISHING, Arrays.asList(Skill.COOKING));
        skillSynergies.put(Skill.FARMING, Arrays.asList(Skill.HERBLORE, Skill.COOKING));
        skillSynergies.put(Skill.THIEVING, Arrays.asList(Skill.AGILITY));
        skillSynergies.put(Skill.SLAYER, Arrays.asList(Skill.ATTACK, Skill.STRENGTH, Skill.DEFENCE, Skill.RANGED, Skill.MAGIC));
        skillSynergies.put(Skill.AGILITY, Arrays.asList(Skill.THIEVING, Skill.HUNTER));
        skillSynergies.put(Skill.RUNECRAFTING, Arrays.asList(Skill.MAGIC));
    }
    
    private void initializeSkillGoals() {
        // Initialize goals for all skills
        for (Skill skill : Skill.values()) {
            int currentLevel = Skills.getRealLevel(skill);
            skillLevels.put(skill, currentLevel);
            
            // Set realistic goals based on current level
            int goalLevel = calculateGoalLevel(currentLevel);
            long estimatedTime = estimateTimeToGoal(skill, currentLevel, goalLevel);
            
            SkillGoal goal = new SkillGoal(skill, currentLevel, goalLevel, estimatedTime);
            skillGoals.put(skill, goal);
            
            // Set initial priorities
            skillPriorities.put(skill, calculateSkillPriority(skill, currentLevel));
        }
        
        Logger.log("Initialized skill goals for " + skillGoals.size() + " skills");
    }
    
    private int calculateGoalLevel(int currentLevel) {
        if (currentLevel < 30) {
            return Math.min(99, currentLevel + random.nextInt(10) + 5);
        } else if (currentLevel < 70) {
            return Math.min(99, currentLevel + random.nextInt(15) + 10);
        } else if (currentLevel < 90) {
            return Math.min(99, currentLevel + random.nextInt(10) + 5);
        } else {
            return 99; // Max level goal
        }
    }
    
    private long estimateTimeToGoal(Skill skill, int currentLevel, int goalLevel) {
        // Rough time estimates in milliseconds
        long baseTime = 3600000; // 1 hour per level on average
        
        // Adjust based on skill type
        if (skillGroups.get("fast_xp").contains(skill)) {
            baseTime = baseTime / 2; // Faster XP
        } else if (skillGroups.get("afk").contains(skill)) {
            baseTime = baseTime * 3 / 2; // Slower but AFK
        }
        
        return baseTime * (goalLevel - currentLevel);
    }
    
    private double calculateSkillPriority(Skill skill, int currentLevel) {
        double priority = 1.0;
        
        // Higher priority for lower levels
        if (currentLevel < 30) {
            priority += 2.0;
        } else if (currentLevel < 50) {
            priority += 1.5;
        } else if (currentLevel < 70) {
            priority += 1.0;
        }
        
        // Bonus for combat skills
        if (skillGroups.get("combat").contains(skill)) {
            priority += 0.5;
        }
        
        // Bonus for gathering skills (money making)
        if (skillGroups.get("gathering").contains(skill)) {
            priority += 0.3;
        }
        
        // Random variation
        priority += random.nextDouble() * 0.5;
        
        return priority;
    }
    
    public void startSkillRotation() {
        if (!rotationEnabled) {
            return;
        }
        
        CompletableFuture.runAsync(() -> {
            while (rotationEnabled) {
                try {
                    // Update current skill levels
                    updateSkillLevels();
                    
                    // Check if it's time to switch skills
                    if (shouldSwitchSkill()) {
                        Skill newSkill = selectNextSkill();
                        if (newSkill != null) {
                            switchToSkill(newSkill);
                        }
                    }
                    
                    // Update skill priorities
                    updateSkillPriorities();
                    
                    // Plan future sessions
                    planSkillSessions();
                    
                    Sleep.sleep(30000); // Check every 30 seconds
                } catch (Exception e) {
                    Logger.log("Error in skill rotation: " + e.getMessage());
                }
            }
        }, executorService);
    }
    
    private void updateSkillLevels() {
        for (Skill skill : Skill.values()) {
            int realLevel = Skills.getRealLevel(skill);
            int cachedLevel = skillLevels.getOrDefault(skill, 0);
            
            if (realLevel != cachedLevel) {
                skillLevels.put(skill, realLevel);
                
                // Update goal if level increased
                SkillGoal goal = skillGoals.get(skill);
                if (goal != null && realLevel >= goal.getTargetLevel()) {
                    // Goal achieved, set new goal
                    int newGoal = calculateGoalLevel(realLevel);
                    long newTime = estimateTimeToGoal(skill, realLevel, newGoal);
                    goal.updateGoal(realLevel, newGoal, newTime);
                    
                    Logger.log("New goal set for " + skill.getName() + ": " + realLevel + " -> " + newGoal);
                }
            }
        }
    }
    
    private boolean shouldSwitchSkill() {
        if (currentSkill == null) {
            return true;
        }
        
        long currentTime = System.currentTimeMillis();
        long sessionTime = currentTime - sessionStartTime;
        
        // Switch if session is too long
        if (sessionTime > MAX_SESSION_TIME) {
            return true;
        }
        
        // Random chance to switch based on rotation intensity
        if (random.nextDouble() < rotationIntensity * 0.1) {
            return true;
        }
        
        // Switch if current skill goal is achieved
        SkillGoal goal = skillGoals.get(currentSkill);
        if (goal != null && skillLevels.get(currentSkill) >= goal.getTargetLevel()) {
            return true;
        }
        
        return false;
    }
    
    private Skill selectNextSkill() {
        List<Skill> candidates = new ArrayList<>();
        
        // Get all skills with their priorities
        for (Map.Entry<Skill, Double> entry : skillPriorities.entrySet()) {
            Skill skill = entry.getKey();
            
            // Skip current skill
            if (skill == currentSkill) {
                continue;
            }
            
            // Check if skill hasn't been trained recently
            long lastTraining = lastTrainingTime.getOrDefault(skill, 0L);
            if (System.currentTimeMillis() - lastTraining > BREAK_TIME) {
                candidates.add(skill);
            }
        }
        
        if (candidates.isEmpty()) {
            // If no candidates, consider all skills
            candidates.addAll(skillPriorities.keySet());
        }
        
        // Weight selection by priority
        double totalPriority = candidates.stream()
            .mapToDouble(skill -> skillPriorities.getOrDefault(skill, 1.0))
            .sum();
        
        double randomValue = random.nextDouble() * totalPriority;
        double currentSum = 0;
        
        for (Skill skill : candidates) {
            currentSum += skillPriorities.getOrDefault(skill, 1.0);
            if (randomValue <= currentSum) {
                return skill;
            }
        }
        
        return candidates.get(random.nextInt(candidates.size()));
    }
    
    private void switchToSkill(Skill newSkill) {
        // End current session
        if (currentSkill != null) {
            endSkillSession();
        }
        
        // Start new session
        currentSkill = newSkill;
        sessionStartTime = System.currentTimeMillis();
        lastTrainingTime.put(newSkill, sessionStartTime);
        
        Logger.log("Switched to skill: " + newSkill.getName());
        
        // Create new session
        SkillSession session = new SkillSession(newSkill, sessionStartTime);
        skillSessions.add(session);
        totalSessions++;
    }
    
    private void endSkillSession() {
        if (currentSkill != null) {
            long sessionTime = System.currentTimeMillis() - sessionStartTime;
            
            // Update last session
            if (!skillSessions.isEmpty()) {
                SkillSession lastSession = skillSessions.get(skillSessions.size() - 1);
                lastSession.endSession(sessionTime);
            }
            
            Logger.log("Ended " + currentSkill.getName() + " session after " + (sessionTime / 60000) + " minutes");
        }
    }
    
    private void updateSkillPriorities() {
        for (Skill skill : skillPriorities.keySet()) {
            int currentLevel = skillLevels.getOrDefault(skill, 0);
            double newPriority = calculateSkillPriority(skill, currentLevel);
            
            // Adjust based on recent training
            long lastTraining = lastTrainingTime.getOrDefault(skill, 0L);
            long timeSinceTraining = System.currentTimeMillis() - lastTraining;
            
            if (timeSinceTraining > BREAK_TIME * 2) {
                newPriority += 1.0; // Boost priority for neglected skills
            }
            
            skillPriorities.put(skill, newPriority);
        }
    }
    
    private void planSkillSessions() {
        // Plan future skill sessions based on goals and synergies
        List<Skill> plannedSkills = new ArrayList<>();
        
        // Add skills with high priorities
        skillPriorities.entrySet().stream()
            .sorted(Map.Entry.<Skill, Double>comparingByValue().reversed())
            .limit(5)
            .forEach(entry -> plannedSkills.add(entry.getKey()));
        
        // Add synergistic skills
        if (currentSkill != null) {
            List<Skill> synergies = skillSynergies.get(currentSkill);
            if (synergies != null) {
                plannedSkills.addAll(synergies);
            }
        }
        
        Logger.log("Planned skills for next rotation: " + plannedSkills.stream()
            .map(Skill::getName)
            .reduce((a, b) -> a + ", " + b)
            .orElse("None"));
    }
    
    public Skill getCurrentSkill() {
        return currentSkill;
    }
    
    public SkillGoal getSkillGoal(Skill skill) {
        return skillGoals.get(skill);
    }
    
    public Map<Skill, Double> getSkillPriorities() {
        return new HashMap<>(skillPriorities);
    }
    
    public List<SkillSession> getSkillSessions() {
        return new ArrayList<>(skillSessions);
    }
    
    public void setRotationEnabled(boolean enabled) {
        this.rotationEnabled = enabled;
        Logger.log("Skill rotation " + (enabled ? "enabled" : "disabled"));
    }
    
    public void setRotationIntensity(double intensity) {
        this.rotationIntensity = Math.max(0.0, Math.min(1.0, intensity));
        Logger.log("Skill rotation intensity set to: " + rotationIntensity);
    }
    
    // Inner classes
    
    public static class SkillGoal {
        private final Skill skill;
        private int currentLevel;
        private int targetLevel;
        private long estimatedTime;
        private long startTime;
        
        public SkillGoal(Skill skill, int currentLevel, int targetLevel, long estimatedTime) {
            this.skill = skill;
            this.currentLevel = currentLevel;
            this.targetLevel = targetLevel;
            this.estimatedTime = estimatedTime;
            this.startTime = System.currentTimeMillis();
        }
        
        public void updateGoal(int newCurrentLevel, int newTargetLevel, long newEstimatedTime) {
            this.currentLevel = newCurrentLevel;
            this.targetLevel = newTargetLevel;
            this.estimatedTime = newEstimatedTime;
            this.startTime = System.currentTimeMillis();
        }
        
        // Getters
        public Skill getSkill() { return skill; }
        public int getCurrentLevel() { return currentLevel; }
        public int getTargetLevel() { return targetLevel; }
        public long getEstimatedTime() { return estimatedTime; }
        public long getStartTime() { return startTime; }
        public double getProgress() { 
            if (targetLevel <= currentLevel) return 1.0;
            return (double) (Skills.getRealLevel(skill) - currentLevel) / (targetLevel - currentLevel);
        }
    }
    
    public static class SkillSession {
        private final Skill skill;
        private final long startTime;
        private long endTime;
        private long duration;
        private int startLevel;
        private int endLevel;
        
        public SkillSession(Skill skill, long startTime) {
            this.skill = skill;
            this.startTime = startTime;
            this.startLevel = Skills.getRealLevel(skill);
        }
        
        public void endSession(long duration) {
            this.endTime = System.currentTimeMillis();
            this.duration = duration;
            this.endLevel = Skills.getRealLevel(skill);
        }
        
        // Getters
        public Skill getSkill() { return skill; }
        public long getStartTime() { return startTime; }
        public long getEndTime() { return endTime; }
        public long getDuration() { return duration; }
        public int getStartLevel() { return startLevel; }
        public int getEndLevel() { return endLevel; }
        public int getLevelsGained() { return endLevel - startLevel; }
    }
} 