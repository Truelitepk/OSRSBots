package antiban;

import org.dreambot.api.utilities.Logger;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.widget.Widgets;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Advanced Chat Monitoring System
 * Monitors chat for various events and generates appropriate responses
 */
public class ChatMonitor {
    
    private final ChatGPTPersonalityEngine chatGPT;
    private final UUIDProfileCache profileCache;
    
    // Chat monitoring state
    private final Map<String, ChatEvent> chatEvents = new ConcurrentHashMap<>();
    private final List<String> chatHistory = new ArrayList<>();
    private final Queue<ChatMessage> recentMessages = new LinkedList<>();
    
    // Advanced chat features
    private final Map<String, ChatResponse> chatResponses = new HashMap<>();
    private final List<ChatPattern> chatPatterns = new ArrayList<>();
    private final Map<String, Integer> messageFrequency = new ConcurrentHashMap<>();
    
    // Chat analysis
    private final Map<String, Double> chatMetrics = new ConcurrentHashMap<>();
    private final List<Long> messageTimestamps = new ArrayList<>();
    private final Map<String, String> responseTemplates = new HashMap<>();
    
    // Configuration
    private final Random random = new Random();
    private final AtomicLong lastChatCheck = new AtomicLong(0);
    private final int maxChatHistory = 100;
    private final int maxRecentMessages = 50;
    
    // State tracking
    private boolean isChatActive = false;
    private String lastMessage = "";
    private long lastResponseTime = 0;
    private int totalMessages = 0;
    private int totalResponses = 0;
    
    public ChatMonitor(ChatGPTPersonalityEngine chatGPT, UUIDProfileCache profileCache) {
        this.chatGPT = chatGPT;
        this.profileCache = profileCache;
        
        initializeChatResponses();
        initializeChatPatterns();
        initializeResponseTemplates();
        
        Logger.log("Chat monitor initialized with advanced response system");
    }
    
    private void initializeChatResponses() {
        // Initialize chat responses
        chatResponses.put("greeting", new GreetingResponse());
        chatResponses.put("question", new QuestionResponse());
        chatResponses.put("insult", new InsultResponse());
        chatResponses.put("compliment", new ComplimentResponse());
        chatResponses.put("help_request", new HelpRequestResponse());
        chatResponses.put("trade_request", new TradeRequestResponse());
        chatResponses.put("spam", new SpamResponse());
        chatResponses.put("bot_accusation", new BotAccusationResponse());
    }
    
    private void initializeChatPatterns() {
        // Initialize chat patterns
        chatPatterns.add(new GreetingPattern());
        chatPatterns.add(new QuestionPattern());
        chatPatterns.add(new InsultPattern());
        chatPatterns.add(new ComplimentPattern());
        chatPatterns.add(new HelpRequestPattern());
        chatPatterns.add(new TradeRequestPattern());
        chatPatterns.add(new SpamPattern());
        chatPatterns.add(new BotAccusationPattern());
    }
    
    private void initializeResponseTemplates() {
        // Initialize response templates
        responseTemplates.put("greeting", "Hey there! How's it going?");
        responseTemplates.put("question", "That's a good question. Let me think about that.");
        responseTemplates.put("insult", "No need for that kind of language.");
        responseTemplates.put("compliment", "Thanks! That's really nice of you to say.");
        responseTemplates.put("help_request", "I'd be happy to help if I can!");
        responseTemplates.put("trade_request", "Sorry, I'm not really into trading right now.");
        responseTemplates.put("spam", "Please keep the chat clean.");
        responseTemplates.put("bot_accusation", "I'm just a regular player like you.");
    }
    
    /**
     * Monitor chat for new messages
     */
    public void monitorChat() {
        long currentTime = System.currentTimeMillis();
        
        // Check for new messages
        String currentMessage = getCurrentChatMessage();
        if (currentMessage != null && !currentMessage.equals(lastMessage)) {
            processChatMessage(currentMessage, currentTime);
            lastMessage = currentMessage;
        }
        
        // Update chat metrics
        updateChatMetrics(currentTime);
        
        // Check for response opportunities
        if (shouldRespond()) {
            generateResponse();
        }
    }
    
    /**
     * Get current chat message
     */
    private String getCurrentChatMessage() {
        try {
            // Check for dialogue
            if (Dialogues.isProcessing()) {
                return "dialogue: " + Dialogues.getNPCDialogue();
            }
            
            // TODO: Widget handling needs update for current DreamBot API
            // Widget widget = Widgets.getWidget(162);
            // WidgetChild chatWidget = widget != null ? widget.getChild(32) : null;
            // if (chatWidget != null && chatWidget.isVisible()) {
            //     String text = chatWidget.getText();
            //     if (text != null && !text.trim().isEmpty()) {
            //         return text;
            //     }
            // }
            // WidgetChild publicChat = widget != null ? widget.getChild(30) : null;
            // if (publicChat != null && publicChat.isVisible()) {
            //     String text = publicChat.getText();
            //     if (text != null && !text.trim().isEmpty()) {
            //         return text;
            //     }
            // }
            
        } catch (Exception e) {
            Logger.log("Error reading chat: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Process chat message
     */
    private void processChatMessage(String message, long timestamp) {
        // Add to chat history
        chatHistory.add(message);
        if (chatHistory.size() > maxChatHistory) {
            chatHistory.remove(0);
        }
        
        // Add to recent messages
        ChatMessage chatMessage = new ChatMessage(message, timestamp, "unknown");
        recentMessages.offer(chatMessage);
        if (recentMessages.size() > maxRecentMessages) {
            recentMessages.poll();
        }
        
        // Analyze message
        String messageType = analyzeMessage(message);
        chatMessage.type = messageType;
        
        // Update message frequency
        messageFrequency.put(messageType, messageFrequency.getOrDefault(messageType, 0) + 1);
        
        // Update timestamps
        messageTimestamps.add(timestamp);
        if (messageTimestamps.size() > 100) {
            messageTimestamps.remove(0);
        }
        
        // Update total messages
        totalMessages++;
        
        // Record chat event
        recordChatEvent(messageType, message, timestamp);
        
        Logger.log("Processed chat message: " + messageType + " - " + message);
    }
    
    /**
     * Analyze message type
     */
    private String analyzeMessage(String message) {
        if (message == null || message.trim().isEmpty()) {
            return "empty";
        }
        
        String lowerMessage = message.toLowerCase();
        
        // Check each pattern
        for (ChatPattern pattern : chatPatterns) {
            if (pattern.matches(lowerMessage)) {
                return pattern.getType();
            }
        }
        
        return "unknown";
    }
    
    /**
     * Update chat metrics
     */
    private void updateChatMetrics(long currentTime) {
        // Update chat activity
        isChatActive = !recentMessages.isEmpty() && 
            (currentTime - recentMessages.peek().timestamp) < 300000; // 5 minutes
        
        // Calculate message rate
        if (messageTimestamps.size() > 1) {
            long timeSpan = messageTimestamps.get(messageTimestamps.size() - 1) - messageTimestamps.get(0);
            double messageRate = (double) messageTimestamps.size() / (timeSpan / 1000.0);
            chatMetrics.put("message_rate", messageRate);
        }
        
        // Calculate response rate
        if (totalMessages > 0) {
            double responseRate = (double) totalResponses / totalMessages;
            chatMetrics.put("response_rate", responseRate);
        }
    }
    
    /**
     * Check if should respond
     */
    private boolean shouldRespond() {
        if (!isChatActive) {
            return false;
        }
        
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastResponseTime < 30000) { // 30 seconds minimum between responses
            return false;
        }
        
        // Check personality-based response probability
        String personality = profileCache.getCurrentPersonality();
        double responseProbability = getResponseProbability(personality);
        
        return random.nextDouble() < responseProbability;
    }
    
    /**
     * Get response probability based on personality
     */
    private double getResponseProbability(String personality) {
        switch (personality) {
            case "social":
                return 0.8; // High response rate
            case "casual":
                return 0.6; // Moderate response rate
            case "efficient":
                return 0.3; // Low response rate
            case "veteran":
                return 0.4; // Moderate response rate
            case "pker":
                return 0.5; // Moderate response rate
            case "skiller":
                return 0.2; // Low response rate
            case "ironman":
                return 0.3; // Low response rate
            case "explorer":
                return 0.7; // High response rate
            default:
                return 0.4; // Default moderate response rate
        }
    }
    
    /**
     * Generate response
     */
    private void generateResponse() {
        if (recentMessages.isEmpty()) {
            return;
        }
        
        // Get most recent message
        ChatMessage lastMsg = recentMessages.peek();
        String messageType = lastMsg.type;
        
        // Get appropriate response
        ChatResponse response = chatResponses.get(messageType);
        if (response != null) {
            String responseText = response.generateResponse(profileCache);
            
            // Log response (in real implementation, this would send the message)
            Logger.log("Generated response: " + responseText);
            
            // Update response tracking
            totalResponses++;
            lastResponseTime = System.currentTimeMillis();
            
            // Record response event
            recordChatEvent("response", responseText, lastResponseTime);
        }
    }
    
    /**
     * Record chat event
     */
    private void recordChatEvent(String eventType, String message, long timestamp) {
        ChatEvent event = new ChatEvent(eventType, message, timestamp);
        chatEvents.put(eventType + "_" + timestamp, event);
        
        // Keep only recent events
        if (chatEvents.size() > 100) {
            String oldestKey = chatEvents.keySet().iterator().next();
            chatEvents.remove(oldestKey);
        }
    }
    
    /**
     * Get chat statistics
     */
    public Map<String, Object> getChatStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalMessages", totalMessages);
        stats.put("totalResponses", totalResponses);
        stats.put("isChatActive", isChatActive);
        stats.put("messageRate", chatMetrics.getOrDefault("message_rate", 0.0));
        stats.put("responseRate", chatMetrics.getOrDefault("response_rate", 0.0));
        stats.put("recentMessageCount", recentMessages.size());
        stats.put("chatHistorySize", chatHistory.size());
        
        return stats;
    }
    
    /**
     * Get message frequency
     */
    public Map<String, Integer> getMessageFrequency() {
        return new HashMap<>(messageFrequency);
    }
    
    /**
     * Get chat metrics
     */
    public Map<String, Double> getChatMetrics() {
        return new HashMap<>(chatMetrics);
    }
    
    /**
     * Get recent messages
     */
    public List<ChatMessage> getRecentMessages() {
        return new ArrayList<>(recentMessages);
    }
    
    // Chat pattern interface and implementations
    private interface ChatPattern {
        boolean matches(String message);
        String getType();
    }
    
    private class GreetingPattern implements ChatPattern {
        private final List<String> greetings = Arrays.asList(
            "hello", "hi", "hey", "sup", "what's up", "howdy", "greetings"
        );
        
        @Override
        public boolean matches(String message) {
            return greetings.stream().anyMatch(message::contains);
        }
        
        @Override
        public String getType() {
            return "greeting";
        }
    }
    
    private class QuestionPattern implements ChatPattern {
        private final List<String> questionWords = Arrays.asList(
            "what", "how", "why", "when", "where", "who", "which"
        );
        
        @Override
        public boolean matches(String message) {
            return message.contains("?") || questionWords.stream().anyMatch(message::contains);
        }
        
        @Override
        public String getType() {
            return "question";
        }
    }
    
    private class InsultPattern implements ChatPattern {
        private final List<String> insults = Arrays.asList(
            "noob", "stupid", "idiot", "dumb", "bad", "terrible", "awful"
        );
        
        @Override
        public boolean matches(String message) {
            return insults.stream().anyMatch(message::contains);
        }
        
        @Override
        public String getType() {
            return "insult";
        }
    }
    
    private class ComplimentPattern implements ChatPattern {
        private final List<String> compliments = Arrays.asList(
            "good", "great", "awesome", "amazing", "nice", "cool", "sweet"
        );
        
        @Override
        public boolean matches(String message) {
            return compliments.stream().anyMatch(message::contains);
        }
        
        @Override
        public String getType() {
            return "compliment";
        }
    }
    
    private class HelpRequestPattern implements ChatPattern {
        private final List<String> helpWords = Arrays.asList(
            "help", "assist", "support", "guide", "teach", "explain"
        );
        
        @Override
        public boolean matches(String message) {
            return helpWords.stream().anyMatch(message::contains);
        }
        
        @Override
        public String getType() {
            return "help_request";
        }
    }
    
    private class TradeRequestPattern implements ChatPattern {
        private final List<String> tradeWords = Arrays.asList(
            "trade", "buy", "sell", "offer", "price", "gp", "gold"
        );
        
        @Override
        public boolean matches(String message) {
            return tradeWords.stream().anyMatch(message::contains);
        }
        
        @Override
        public String getType() {
            return "trade_request";
        }
    }
    
    private class SpamPattern implements ChatPattern {
        @Override
        public boolean matches(String message) {
            // Check for repeated characters or excessive length
            return message.length() > 100 || 
                   message.matches(".*(.)\\1{4,}.*"); // 5+ repeated characters
        }
        
        @Override
        public String getType() {
            return "spam";
        }
    }
    
    private class BotAccusationPattern implements ChatPattern {
        private final List<String> botWords = Arrays.asList(
            "bot", "auto", "script", "macro", "cheat", "hack"
        );
        
        @Override
        public boolean matches(String message) {
            return botWords.stream().anyMatch(message::contains);
        }
        
        @Override
        public String getType() {
            return "bot_accusation";
        }
    }
    
    // Chat response interface and implementations
    private interface ChatResponse {
        String generateResponse(UUIDProfileCache profile);
    }
    
    private class GreetingResponse implements ChatResponse {
        @Override
        public String generateResponse(UUIDProfileCache profile) {
            String personality = profile.getCurrentPersonality();
            String template = responseTemplates.get("greeting");
            
            // Add personality-based variation
            switch (personality) {
                case "social":
                    return template + " Nice to meet you!";
                case "casual":
                    return template + " How's your day going?";
                case "efficient":
                    return "Hi.";
                case "veteran":
                    return template + " Welcome to the game.";
                default:
                    return template;
            }
        }
    }
    
    private class QuestionResponse implements ChatResponse {
        @Override
        public String generateResponse(UUIDProfileCache profile) {
            String personality = profile.getCurrentPersonality();
            String template = responseTemplates.get("question");
            
            switch (personality) {
                case "social":
                    return template + " I'd love to discuss that!";
                case "efficient":
                    return "I'm not sure.";
                case "veteran":
                    return template + " That's an interesting question.";
                default:
                    return template;
            }
        }
    }
    
    private class InsultResponse implements ChatResponse {
        @Override
        public String generateResponse(UUIDProfileCache profile) {
            String personality = profile.getCurrentPersonality();
            String template = responseTemplates.get("insult");
            
            switch (personality) {
                case "pker":
                    return "Bring it on!";
                case "casual":
                    return template + " Let's keep it friendly.";
                case "efficient":
                    return "Whatever.";
                default:
                    return template;
            }
        }
    }
    
    private class ComplimentResponse implements ChatResponse {
        @Override
        public String generateResponse(UUIDProfileCache profile) {
            String personality = profile.getCurrentPersonality();
            String template = responseTemplates.get("compliment");
            
            switch (personality) {
                case "social":
                    return template + " You're pretty cool too!";
                case "casual":
                    return template + " That means a lot!";
                case "efficient":
                    return "Thanks.";
                default:
                    return template;
            }
        }
    }
    
    private class HelpRequestResponse implements ChatResponse {
        @Override
        public String generateResponse(UUIDProfileCache profile) {
            String personality = profile.getCurrentPersonality();
            String template = responseTemplates.get("help_request");
            
            switch (personality) {
                case "social":
                    return template + " What do you need help with?";
                case "veteran":
                    return template + " I have some experience with that.";
                case "efficient":
                    return "I can try to help.";
                default:
                    return template;
            }
        }
    }
    
    private class TradeRequestResponse implements ChatResponse {
        @Override
        public String generateResponse(UUIDProfileCache profile) {
            String personality = profile.getCurrentPersonality();
            String template = responseTemplates.get("trade_request");
            
            switch (personality) {
                case "merchant":
                    return "What are you looking to trade?";
                case "ironman":
                    return "I'm an ironman, sorry.";
                case "efficient":
                    return template;
                default:
                    return template;
            }
        }
    }
    
    private class SpamResponse implements ChatResponse {
        @Override
        public String generateResponse(UUIDProfileCache profile) {
            return responseTemplates.get("spam");
        }
    }
    
    private class BotAccusationResponse implements ChatResponse {
        @Override
        public String generateResponse(UUIDProfileCache profile) {
            String personality = profile.getCurrentPersonality();
            String template = responseTemplates.get("bot_accusation");
            
            switch (personality) {
                case "veteran":
                    return template + " I've been playing for years.";
                case "casual":
                    return template + " I just like to take my time.";
                case "efficient":
                    return template + " I'm just focused on efficiency.";
                default:
                    return template;
            }
        }
    }
    
    // Chat message class
    private static class ChatMessage {
        final String message;
        final long timestamp;
        String type;
        
        ChatMessage(String message, long timestamp, String type) {
            this.message = message;
            this.timestamp = timestamp;
            this.type = type;
        }
    }
    
    // Chat event class
    private static class ChatEvent {
        final String eventType;
        final String message;
        final long timestamp;
        
        ChatEvent(String eventType, String message, long timestamp) {
            this.eventType = eventType;
            this.message = message;
            this.timestamp = timestamp;
        }
    }
} 