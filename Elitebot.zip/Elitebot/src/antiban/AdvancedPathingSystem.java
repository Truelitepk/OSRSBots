package antiban;

import org.dreambot.api.methods.Calculations;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Advanced Pathing System with personality-based preferences
 * Surpasses P2P AI with sophisticated route calculation and human-like pathing
 */
public class AdvancedPathingSystem {
    
    private final UUIDProfileCache profileCache;
    private final Map<String, PathingPreferences> personalityPreferences;
    private final Map<Tile, List<Tile>> cachedPaths = new HashMap<>();
    private final List<MovementRecord> movementHistory = new ArrayList<>();
    
    // Pathing statistics
    private int totalPathsCalculated = 0;
    private long totalPathingTime = 0;
    private double averagePathEfficiency = 0.0;
    
    // Personality-based pathing patterns
    private final Map<String, PathingPattern> personalityPatterns;
    
    public AdvancedPathingSystem(UUIDProfileCache profileCache) {
        this.profileCache = profileCache;
        this.personalityPreferences = initializePersonalityPreferences();
        this.personalityPatterns = initializePersonalityPatterns();
        
        Logger.log("[AdvancedPathing] Initialized with personality-based pathing");
    }
    
    /**
     * Initialize personality-based pathing preferences
     */
    private Map<String, PathingPreferences> initializePersonalityPreferences() {
        Map<String, PathingPreferences> prefs = new HashMap<>();
        
        // Efficient player - direct, fast paths
        prefs.put("efficient_player", new PathingPreferences(
            0.9, // Directness preference
            0.8, // Speed preference
            0.3, // Scenic preference
            0.2, // Avoidance preference
            0.1  // Randomness preference
        ));
        
        // Chill player - relaxed, scenic paths
        prefs.put("chill_player", new PathingPreferences(
            0.4, // Directness preference
            0.3, // Speed preference
            0.8, // Scenic preference
            0.6, // Avoidance preference
            0.4  // Randomness preference
        ));
        
        // Newbie - cautious, simple paths
        prefs.put("newbie", new PathingPreferences(
            0.6, // Directness preference
            0.4, // Speed preference
            0.2, // Scenic preference
            0.8, // Avoidance preference
            0.1  // Randomness preference
        ));
        
        // Veteran - balanced, experienced paths
        prefs.put("veteran", new PathingPreferences(
            0.7, // Directness preference
            0.6, // Speed preference
            0.5, // Scenic preference
            0.4, // Avoidance preference
            0.2  // Randomness preference
        ));
        
        // Casual player - balanced paths
        prefs.put("casual_player", new PathingPreferences(
            0.6, // Directness preference
            0.5, // Speed preference
            0.4, // Scenic preference
            0.5, // Avoidance preference
            0.3  // Randomness preference
        ));
        
        return prefs;
    }
    
    /**
     * Initialize personality-based pathing patterns
     */
    private Map<String, PathingPattern> initializePersonalityPatterns() {
        Map<String, PathingPattern> patterns = new HashMap<>();
        
        // Efficient player pattern
        patterns.put("efficient_player", new PathingPattern(
            true,   // Use shortcuts
            false,  // Avoid obstacles
            true,   // Use run energy efficiently
            0.1,    // Path deviation chance
            0.05    // Stop chance
        ));
        
        // Chill player pattern
        patterns.put("chill_player", new PathingPattern(
            false,  // Use shortcuts
            true,   // Avoid obstacles
            false,  // Use run energy efficiently
            0.3,    // Path deviation chance
            0.15    // Stop chance
        ));
        
        // Newbie pattern
        patterns.put("newbie", new PathingPattern(
            false,  // Use shortcuts
            true,   // Avoid obstacles
            false,  // Use run energy efficiently
            0.2,    // Path deviation chance
            0.25    // Stop chance
        ));
        
        // Veteran pattern
        patterns.put("veteran", new PathingPattern(
            true,   // Use shortcuts
            false,  // Avoid obstacles
            true,   // Use run energy efficiently
            0.15,   // Path deviation chance
            0.08    // Stop chance
        ));
        
        // Casual player pattern
        patterns.put("casual_player", new PathingPattern(
            false,  // Use shortcuts
            true,   // Avoid obstacles
            false,  // Use run energy efficiently
            0.25,   // Path deviation chance
            0.12    // Stop chance
        ));
        
        return patterns;
    }
    
    /**
     * Calculate optimal path considering personality and fatigue
     */
    public List<Tile> calculateOptimalPath(Tile start, Tile destination, boolean useRun, int fatigueLevel) {
        long startTime = System.currentTimeMillis();
        
        // Get personality preferences
        String personality = profileCache.getCurrentPersonality();
        PathingPreferences prefs = personalityPreferences.getOrDefault(personality, 
            personalityPreferences.get("casual_player"));
        PathingPattern pattern = personalityPatterns.getOrDefault(personality,
            personalityPatterns.get("casual_player"));
        
        // Check cache first
        String cacheKey = start.toString() + "->" + destination.toString() + ":" + personality;
        if (cachedPaths.containsKey(start)) {
            List<Tile> cachedPath = cachedPaths.get(start);
            if (isPathStillValid(cachedPath)) {
                return applyPersonalityModifications(cachedPath, prefs, pattern, fatigueLevel);
            }
        }
        
        // Calculate base path using A* algorithm
        List<Tile> basePath = calculateAStarPath(start, destination);
        
        // Apply personality-based modifications
        List<Tile> modifiedPath = applyPersonalityModifications(basePath, prefs, pattern, fatigueLevel);
        
        // Cache the result
        cachedPaths.put(start, modifiedPath);
        
        // Update statistics
        long pathingTime = System.currentTimeMillis() - startTime;
        totalPathsCalculated++;
        totalPathingTime += pathingTime;
        averagePathEfficiency = (averagePathEfficiency * (totalPathsCalculated - 1) + 
            calculatePathEfficiency(modifiedPath)) / totalPathsCalculated;
        
        Logger.log("[AdvancedPathing] Calculated path in " + pathingTime + "ms for " + personality);
        
        return modifiedPath;
    }
    
    /**
     * Calculate A* pathfinding
     */
    private List<Tile> calculateAStarPath(Tile start, Tile destination) {
        PriorityQueue<PathNode> openSet = new PriorityQueue<>();
        Set<Tile> closedSet = new HashSet<>();
        Map<Tile, Tile> cameFrom = new HashMap<>();
        Map<Tile, Double> gScore = new HashMap<>();
        Map<Tile, Double> fScore = new HashMap<>();
        
        openSet.add(new PathNode(start, 0, calculateHeuristic(start, destination)));
        gScore.put(start, 0.0);
        fScore.put(start, calculateHeuristic(start, destination));
        
        while (!openSet.isEmpty()) {
            PathNode current = openSet.poll();
            
            if (current.tile.equals(destination)) {
                return reconstructPath(cameFrom, current.tile);
            }
            
            closedSet.add(current.tile);
            
            // Get neighbors
            for (Tile neighbor : getNeighbors(current.tile)) {
                if (closedSet.contains(neighbor)) continue;
                
                double tentativeGScore = gScore.get(current.tile) + 
                    calculateDistance(current.tile, neighbor);
                
                if (!gScore.containsKey(neighbor) || tentativeGScore < gScore.get(neighbor)) {
                    cameFrom.put(neighbor, current.tile);
                    gScore.put(neighbor, tentativeGScore);
                    fScore.put(neighbor, tentativeGScore + calculateHeuristic(neighbor, destination));
                    
                    PathNode neighborNode = new PathNode(neighbor, tentativeGScore, fScore.get(neighbor));
                    openSet.add(neighborNode);
                }
            }
        }
        
        // Fallback to direct path if A* fails
        return Arrays.asList(start, destination);
    }
    
    /**
     * Get neighboring tiles
     */
    private List<Tile> getNeighbors(Tile tile) {
        List<Tile> neighbors = new ArrayList<>();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue;
                
                Tile neighbor = new Tile(tile.getX() + dx, tile.getY() + dy, tile.getZ());
                if (isWalkable(neighbor)) {
                    neighbors.add(neighbor);
                }
            }
        }
        return neighbors;
    }
    
    /**
     * Check if tile is walkable
     */
    private boolean isWalkable(Tile tile) {
        // Basic walkability check - can be enhanced with collision detection
        return tile != null && tile.getX() >= 0 && tile.getY() >= 0;
    }
    
    /**
     * Calculate heuristic (Manhattan distance)
     */
    private double calculateHeuristic(Tile from, Tile to) {
        return Math.abs(from.getX() - to.getX()) + Math.abs(from.getY() - to.getY());
    }
    
    /**
     * Calculate distance between tiles
     */
    private double calculateDistance(Tile from, Tile to) {
        return Math.sqrt(Math.pow(from.getX() - to.getX(), 2) + Math.pow(from.getY() - to.getY(), 2));
    }
    
    /**
     * Reconstruct path from A* result
     */
    private List<Tile> reconstructPath(Map<Tile, Tile> cameFrom, Tile current) {
        List<Tile> path = new ArrayList<>();
        path.add(current);
        
        while (cameFrom.containsKey(current)) {
            current = cameFrom.get(current);
            path.add(0, current);
        }
        
        return path;
    }
    
    /**
     * Apply personality-based modifications to path
     */
    private List<Tile> applyPersonalityModifications(List<Tile> basePath, PathingPreferences prefs, 
                                                   PathingPattern pattern, int fatigueLevel) {
        if (basePath.size() <= 2) return basePath;
        
        List<Tile> modifiedPath = new ArrayList<>(basePath);
        
        // Apply directness preference
        if (prefs.directnessPreference > 0.7) {
            modifiedPath = optimizeForDirectness(modifiedPath);
        }
        
        // Apply scenic preference
        if (prefs.scenicPreference > 0.6) {
            modifiedPath = addScenicDetours(modifiedPath);
        }
        
        // Apply avoidance preference
        if (prefs.avoidancePreference > 0.5) {
            modifiedPath = addAvoidancePaths(modifiedPath);
        }
        
        // Apply randomness preference
        if (prefs.randomnessPreference > 0.3) {
            modifiedPath = addRandomDeviations(modifiedPath);
        }
        
        // Apply fatigue-based modifications
        if (fatigueLevel > 70) {
            modifiedPath = addFatigueBreaks(modifiedPath);
        }
        
        return modifiedPath;
    }
    
    /**
     * Optimize path for directness
     */
    private List<Tile> optimizeForDirectness(List<Tile> path) {
        List<Tile> optimized = new ArrayList<>();
        optimized.add(path.get(0));
        
        for (int i = 1; i < path.size() - 1; i++) {
            Tile prev = optimized.get(optimized.size() - 1);
            Tile current = path.get(i);
            Tile next = path.get(i + 1);
            
            // Skip intermediate tiles if they don't add significant value
            if (calculateDistance(prev, next) < calculateDistance(prev, current) + calculateDistance(current, next) * 1.2) {
                continue;
            }
            optimized.add(current);
        }
        
        optimized.add(path.get(path.size() - 1));
        return optimized;
    }
    
    /**
     * Add scenic detours to path
     */
    private List<Tile> addScenicDetours(List<Tile> path) {
        List<Tile> scenicPath = new ArrayList<>();
        
        for (int i = 0; i < path.size() - 1; i++) {
            scenicPath.add(path.get(i));
            
            // Add scenic detour with 30% chance
            if (ThreadLocalRandom.current().nextDouble() < 0.3) {
                Tile detour = generateScenicDetour(path.get(i), path.get(i + 1));
                if (detour != null) {
                    scenicPath.add(detour);
                }
            }
        }
        
        scenicPath.add(path.get(path.size() - 1));
        return scenicPath;
    }
    
    /**
     * Generate scenic detour
     */
    private Tile generateScenicDetour(Tile from, Tile to) {
        // Generate a tile that's slightly off the direct path
        int midX = (from.getX() + to.getX()) / 2;
        int midY = (from.getY() + to.getY()) / 2;
        
        // Add some randomness
        int offsetX = ThreadLocalRandom.current().nextInt(-2, 3);
        int offsetY = ThreadLocalRandom.current().nextInt(-2, 3);
        
        return new Tile(midX + offsetX, midY + offsetY, from.getZ());
    }
    
    /**
     * Add avoidance paths
     */
    private List<Tile> addAvoidancePaths(List<Tile> path) {
        List<Tile> avoidancePath = new ArrayList<>();
        
        for (int i = 0; i < path.size() - 1; i++) {
            Tile current = path.get(i);
            Tile next = path.get(i + 1);
            
            avoidancePath.add(current);
            
            // Check if we should avoid this area
            if (shouldAvoidArea(current)) {
                Tile avoidanceTile = findAvoidanceTile(current, next);
                if (avoidanceTile != null) {
                    avoidancePath.add(avoidanceTile);
                }
            }
        }
        
        avoidancePath.add(path.get(path.size() - 1));
        return avoidancePath;
    }
    
    /**
     * Check if area should be avoided
     */
    private boolean shouldAvoidArea(Tile tile) {
        // Avoid areas with many players or dangerous NPCs
        return ThreadLocalRandom.current().nextDouble() < 0.2;
    }
    
    /**
     * Find avoidance tile
     */
    private Tile findAvoidanceTile(Tile from, Tile to) {
        // Find a tile that's slightly away from the direct path
        int offsetX = ThreadLocalRandom.current().nextInt(-3, 4);
        int offsetY = ThreadLocalRandom.current().nextInt(-3, 4);
        
        return new Tile(from.getX() + offsetX, from.getY() + offsetY, from.getZ());
    }
    
    /**
     * Add random deviations
     */
    private List<Tile> addRandomDeviations(List<Tile> path) {
        List<Tile> deviatedPath = new ArrayList<>();
        
        for (int i = 0; i < path.size() - 1; i++) {
            deviatedPath.add(path.get(i));
            
            // Add random deviation with 20% chance
            if (ThreadLocalRandom.current().nextDouble() < 0.2) {
                Tile deviation = generateRandomDeviation(path.get(i), path.get(i + 1));
                if (deviation != null) {
                    deviatedPath.add(deviation);
                }
            }
        }
        
        deviatedPath.add(path.get(path.size() - 1));
        return deviatedPath;
    }
    
    /**
     * Generate random deviation
     */
    private Tile generateRandomDeviation(Tile from, Tile to) {
        // Generate a random tile between the two points
        double ratio = ThreadLocalRandom.current().nextDouble();
        int x = (int) (from.getX() + (to.getX() - from.getX()) * ratio);
        int y = (int) (from.getY() + (to.getY() - from.getY()) * ratio);
        
        // Add some randomness
        x += ThreadLocalRandom.current().nextInt(-1, 2);
        y += ThreadLocalRandom.current().nextInt(-1, 2);
        
        return new Tile(x, y, from.getZ());
    }
    
    /**
     * Add fatigue breaks to path
     */
    private List<Tile> addFatigueBreaks(List<Tile> path) {
        List<Tile> fatiguePath = new ArrayList<>();
        
        for (int i = 0; i < path.size(); i++) {
            fatiguePath.add(path.get(i));
            
            // Add rest stops every few tiles when fatigued
            if (i > 0 && i % 3 == 0 && ThreadLocalRandom.current().nextDouble() < 0.4) {
                // Add the same tile again to simulate stopping
                fatiguePath.add(path.get(i));
            }
        }
        
        return fatiguePath;
    }
    
    /**
     * Record movement for analysis
     */
    public void recordMovement(Tile from, Tile to, long timeToMove) {
        MovementRecord record = new MovementRecord(from, to, timeToMove, System.currentTimeMillis());
        movementHistory.add(record);
        
        // Keep only recent history
        if (movementHistory.size() > 1000) {
            movementHistory.remove(0);
        }
    }
    
    /**
     * Get personality preferences
     */
    public PathingPreferences getPersonalityPreferences(String personality) {
        return personalityPreferences.getOrDefault(personality, 
            personalityPreferences.get("casual_player"));
    }
    
    /**
     * Check if cached path is still valid
     */
    private boolean isPathStillValid(List<Tile> path) {
        // Check if all tiles in path are still walkable
        for (Tile tile : path) {
            if (!isWalkable(tile)) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Calculate path efficiency
     */
    private double calculatePathEfficiency(List<Tile> path) {
        if (path.size() < 2) return 1.0;
        
        double directDistance = calculateDistance(path.get(0), path.get(path.size() - 1));
        double actualDistance = 0;
        
        for (int i = 0; i < path.size() - 1; i++) {
            actualDistance += calculateDistance(path.get(i), path.get(i + 1));
        }
        
        return directDistance / actualDistance;
    }
    
    /**
     * Pathing preferences for different personalities
     */
    public static class PathingPreferences {
        public final double directnessPreference;
        public final double speedPreference;
        public final double scenicPreference;
        public final double avoidancePreference;
        public final double randomnessPreference;
        
        public PathingPreferences(double directness, double speed, double scenic, 
                                double avoidance, double randomness) {
            this.directnessPreference = directness;
            this.speedPreference = speed;
            this.scenicPreference = scenic;
            this.avoidancePreference = avoidance;
            this.randomnessPreference = randomness;
        }
    }
    
    /**
     * Pathing pattern for different personalities
     */
    public static class PathingPattern {
        public final boolean useShortcuts;
        public final boolean avoidObstacles;
        public final boolean useRunEfficiently;
        public final double pathDeviationChance;
        public final double stopChance;
        
        public PathingPattern(boolean shortcuts, boolean obstacles, boolean runEfficiently,
                            double deviationChance, double stopChance) {
            this.useShortcuts = shortcuts;
            this.avoidObstacles = obstacles;
            this.useRunEfficiently = runEfficiently;
            this.pathDeviationChance = deviationChance;
            this.stopChance = stopChance;
        }
    }
    
    /**
     * Path node for A* algorithm
     */
    private static class PathNode implements Comparable<PathNode> {
        public final Tile tile;
        public final double gScore;
        public final double fScore;
        
        public PathNode(Tile tile, double gScore, double fScore) {
            this.tile = tile;
            this.gScore = gScore;
            this.fScore = fScore;
        }
        
        @Override
        public int compareTo(PathNode other) {
            return Double.compare(this.fScore, other.fScore);
        }
    }
    
    /**
     * Movement record for analysis
     */
    public static class MovementRecord {
        public final Tile from;
        public final Tile to;
        public final long timeToMove;
        public final long timestamp;
        
        public MovementRecord(Tile from, Tile to, long timeToMove, long timestamp) {
            this.from = from;
            this.to = to;
            this.timeToMove = timeToMove;
            this.timestamp = timestamp;
        }
    }
    
    /**
     * Pathing statistics
     */
    public static class PathingStatistics {
        public final int totalPathsCalculated;
        public final long totalPathingTime;
        public final double averagePathEfficiency;
        public final int movementHistorySize;
        
        public PathingStatistics(int totalPaths, long totalTime, double avgEfficiency, int historySize) {
            this.totalPathsCalculated = totalPaths;
            this.totalPathingTime = totalTime;
            this.averagePathEfficiency = avgEfficiency;
            this.movementHistorySize = historySize;
        }
    }
} 