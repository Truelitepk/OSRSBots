package namegen;

import java.util.Random;
import java.util.Map;
import java.util.HashMap;

/**
 * Advanced Name Generator that creates personality-appropriate names
 * based on the bot's sophisticated behavioral fingerprint system
 */
public class VeteranNameGenerator {

    private static final Random random = new Random();
    
    // Personality-based name components
    private static final String[] EFFICIENT_PREFIXES = {
        "Efficient", "Optimal", "Max", "Peak", "Elite", "Pro", "Meta", "Speed", "Fast", "Quick",
        "Rush", "Haste", "Swift", "Rapid", "Turbo", "Boost", "Power", "Force", "Drive", "Push"
    };
    
    private static final String[] EFFICIENT_SUFFIXES = {
        "Xp", "Gains", "Rate", "Meta", "Pro", "Elite", "Max", "Peak", "Optimal", "Efficient",
        "Speed", "Fast", "Quick", "Rush", "Haste", "Swift", "Rapid", "Turbo", "Boost", "Power"
    };
    
    private static final String[] CHILL_PREFIXES = {
        "Chill", "Relax", "Calm", "Peace", "Zen", "Mellow", "Easy", "Smooth", "Gentle", "Soft",
        "Cool", "Fresh", "Nice", "Sweet", "Kind", "Friendly", "Happy", "Joy", "Fun", "Good"
    };
    
    private static final String[] CHILL_SUFFIXES = {
        "Vibes", "Mood", "Feels", "Energy", "Flow", "Chill", "Relax", "Calm", "Peace", "Zen",
        "Cool", "Fresh", "Nice", "Sweet", "Kind", "Friendly", "Happy", "Joy", "Fun", "Good"
    };
    
    private static final String[] VETERAN_PREFIXES = {
        "Veteran", "Vet", "Old", "Ancient", "Classic", "Legacy", "Vintage", "Retro", "OG", "Original",
        "Master", "Expert", "Guru", "Sage", "Wise", "Elder", "Senior", "Pro", "Elite", "Legend"
    };
    
    private static final String[] VETERAN_SUFFIXES = {
        "Vet", "Veteran", "OG", "Classic", "Legacy", "Vintage", "Retro", "Original", "Master", "Expert",
        "Guru", "Sage", "Wise", "Elder", "Senior", "Pro", "Elite", "Legend", "King", "Lord"
    };
    
    private static final String[] NEWBIE_PREFIXES = {
        "New", "Fresh", "Young", "Beginner", "Start", "First", "Learning", "Student", "Apprentice", "Novice",
        "Baby", "Little", "Small", "Tiny", "Mini", "Newbie", "Noob", "Rookie", "Green", "Fresh"
    };
    
    private static final String[] NEWBIE_SUFFIXES = {
        "Newbie", "Noob", "Rookie", "Beginner", "Student", "Apprentice", "Novice", "Baby", "Little", "Small",
        "Tiny", "Mini", "Green", "Fresh", "New", "Young", "Learning", "Start", "First", "Beginner"
    };
    
    private static final String[] CASUAL_PREFIXES = {
        "Casual", "Relaxed", "Easy", "Simple", "Basic", "Normal", "Regular", "Average", "Standard", "Typical",
        "Comfort", "Cozy", "Snug", "Warm", "Soft", "Gentle", "Mild", "Moderate", "Balanced", "Steady"
    };
    
    private static final String[] CASUAL_SUFFIXES = {
        "Casual", "Relaxed", "Easy", "Simple", "Basic", "Normal", "Regular", "Average", "Standard", "Typical",
        "Comfort", "Cozy", "Snug", "Warm", "Soft", "Gentle", "Mild", "Moderate", "Balanced", "Steady"
    };
    
    private static final String[] PKER_PREFIXES = {
        "PK", "Kill", "Death", "Blood", "Rage", "Fury", "Wrath", "Anger", "Hate", "Destroy",
        "Slay", "Murder", "Assassin", "Hunter", "Predator", "Killer", "Death", "Blood", "Rage", "Fury"
    };
    
    private static final String[] PKER_SUFFIXES = {
        "PKer", "Killer", "Slayer", "Hunter", "Predator", "Assassin", "Murderer", "Death", "Blood", "Rage",
        "Fury", "Wrath", "Anger", "Hate", "Destroy", "Slay", "Murder", "Kill", "Death", "Blood"
    };
    
    private static final String[] PVMER_PREFIXES = {
        "PvM", "Boss", "Raid", "Dungeon", "Monster", "Beast", "Creature", "Dragon", "Demon", "Giant",
        "Slayer", "Hunter", "Killer", "Destroyer", "Conqueror", "Champion", "Hero", "Warrior", "Fighter", "Combat"
    };
    
    private static final String[] PVMER_SUFFIXES = {
        "PvMer", "Boss", "Raid", "Dungeon", "Monster", "Beast", "Creature", "Dragon", "Demon", "Giant",
        "Slayer", "Hunter", "Killer", "Destroyer", "Conqueror", "Champion", "Hero", "Warrior", "Fighter", "Combat"
    };
    
    private static final String[] SKILLER_PREFIXES = {
        "Skill", "Train", "Level", "Xp", "Gain", "Grind", "Farm", "Gather", "Collect", "Harvest",
        "Craft", "Make", "Build", "Create", "Form", "Shape", "Design", "Art", "Master", "Expert"
    };
    
    private static final String[] SKILLER_SUFFIXES = {
        "Skiller", "Trainer", "Grinder", "Farmer", "Gatherer", "Collector", "Harvester", "Crafter", "Maker", "Builder",
        "Creator", "Former", "Shaper", "Designer", "Artist", "Master", "Expert", "Skill", "Train", "Level"
    };
    
    private static final String[] IRONMAN_PREFIXES = {
        "Iron", "BTW", "Hard", "Tough", "Strong", "Mighty", "Powerful", "Brave", "Bold", "Courage",
        "Steel", "Metal", "Iron", "Hard", "Tough", "Strong", "Mighty", "Powerful", "Brave", "Bold"
    };
    
    private static final String[] IRONMAN_SUFFIXES = {
        "Iron", "BTW", "Hard", "Tough", "Strong", "Mighty", "Powerful", "Brave", "Bold", "Courage",
        "Steel", "Metal", "Iron", "Hard", "Tough", "Strong", "Mighty", "Powerful", "Brave", "Bold"
    };
    
    // Leet speak characters and substitution patterns
    private static final char[] LEET_CHARS = { '0', '1', '3', '4', '5', '7', '8', '9' };
    
    // Extensive character substitution patterns for name availability
    private static final Map<Character, String[]> CHARACTER_SUBSTITUTIONS = new HashMap<>();
    static {
        // Common substitutions that look natural
        CHARACTER_SUBSTITUTIONS.put('a', new String[]{"4", "@"});
        CHARACTER_SUBSTITUTIONS.put('e', new String[]{"3"});
        CHARACTER_SUBSTITUTIONS.put('i', new String[]{"1", "!"});
        CHARACTER_SUBSTITUTIONS.put('o', new String[]{"0"});
        CHARACTER_SUBSTITUTIONS.put('s', new String[]{"5", "$"});
        CHARACTER_SUBSTITUTIONS.put('t', new String[]{"7"});
        CHARACTER_SUBSTITUTIONS.put('l', new String[]{"1", "|"});
        CHARACTER_SUBSTITUTIONS.put('g', new String[]{"9"});
        CHARACTER_SUBSTITUTIONS.put('b', new String[]{"8"});
        CHARACTER_SUBSTITUTIONS.put('z', new String[]{"2"});
        
        // Less common but still valid substitutions
        CHARACTER_SUBSTITUTIONS.put('u', new String[]{"v"});
        CHARACTER_SUBSTITUTIONS.put('c', new String[]{"k"});
        CHARACTER_SUBSTITUTIONS.put('f', new String[]{"ph"});
        CHARACTER_SUBSTITUTIONS.put('q', new String[]{"kw"});
        CHARACTER_SUBSTITUTIONS.put('x', new String[]{"ks"});
    }
    
    // Name variation strategies
    private static final String[] NAME_VARIATIONS = {
        "Xx", "xX", "X_", "_X", "x_", "_x",  // Prefix variations
        "z", "Z", "_z", "z_", "Z_", "_Z",    // Suffix variations
        "99", "69", "420", "1337", "666",    // Common number suffixes
        "YT", "YT_", "_YT", "YTz", "zYT",    // YouTuber style
        "TV", "TV_", "_TV", "TVz", "zTV",    // Streamer style
        "GOD", "G0D", "GOD_", "_GOD",        // God variations
        "KING", "K1NG", "KING_", "_KING",    // King variations
        "BOSS", "B0SS", "BOSS_", "_BOSS",    // Boss variations
        "PRO", "PR0", "PRO_", "_PRO",        // Pro variations
        "LEGEND", "L3GEND", "LEGEND_", "_LEGEND" // Legend variations
    };
    
    // Double letter patterns for more natural names
    private static final String[] DOUBLE_LETTERS = {"ll", "ss", "tt", "nn", "mm", "pp", "rr", "ff", "cc", "dd"};
    
    // Name length variations
    private static final int[] NAME_LENGTHS = {8, 9, 10, 11, 12};
    
    // Maximum attempts for name generation
    private static final int MAX_NAME_ATTEMPTS = 20;
    
    // Personality types
    public enum PersonalityType {
        EFFICIENT, CHILL, VETERAN, NEWBIE, CASUAL, PKER, PVMER, SKILLER, IRONMAN, RANDOM
    }
    
    // Gender types
    public enum Gender {
        MALE, FEMALE, RANDOM
    }
    
    // Gender-specific name components
    private static final String[] MALE_PREFIXES = {
        "King", "Lord", "Sir", "Master", "Captain", "Warrior", "Knight", "Hero", "Champion", "Legend",
        "Dragon", "Tiger", "Lion", "Wolf", "Bear", "Eagle", "Hawk", "Falcon", "Shark", "Cobra"
    };
    
    private static final String[] MALE_SUFFIXES = {
        "King", "Lord", "Master", "Warrior", "Knight", "Hero", "Champion", "Legend", "Dragon", "Tiger",
        "Lion", "Wolf", "Bear", "Eagle", "Hawk", "Falcon", "Shark", "Cobra", "Alpha", "Omega"
    };
    
    private static final String[] FEMALE_PREFIXES = {
        "Queen", "Lady", "Princess", "Goddess", "Angel", "Valkyrie", "Phoenix", "Rose", "Lily", "Star",
        "Moon", "Sun", "Dawn", "Twilight", "Rainbow", "Butterfly", "Dove", "Swan", "Pearl", "Crystal"
    };
    
    private static final String[] FEMALE_SUFFIXES = {
        "Queen", "Lady", "Princess", "Goddess", "Angel", "Valkyrie", "Phoenix", "Rose", "Lily", "Star",
        "Moon", "Sun", "Dawn", "Twilight", "Rainbow", "Butterfly", "Dove", "Swan", "Pearl", "Crystal"
    };
    
    // Gender-specific personality adjustments
    private static final Map<Gender, Map<PersonalityType, Double>> GENDER_PERSONALITY_MODIFIERS = new HashMap<>();
    static {
        // Male personality modifiers
        Map<PersonalityType, Double> maleModifiers = new HashMap<>();
        maleModifiers.put(PersonalityType.PKER, 1.2); // Males more likely to be PKers
        maleModifiers.put(PersonalityType.EFFICIENT, 1.1); // Males slightly more efficient
        maleModifiers.put(PersonalityType.CHILL, 0.9); // Males slightly less chill
        maleModifiers.put(PersonalityType.NEWBIE, 0.8); // Males less likely to be newbies
        GENDER_PERSONALITY_MODIFIERS.put(Gender.MALE, maleModifiers);
        
        // Female personality modifiers
        Map<PersonalityType, Double> femaleModifiers = new HashMap<>();
        femaleModifiers.put(PersonalityType.CHILL, 1.2); // Females more likely to be chill
        femaleModifiers.put(PersonalityType.SKILLER, 1.1); // Females more likely to be skillers
        femaleModifiers.put(PersonalityType.PKER, 0.8); // Females less likely to be PKers
        femaleModifiers.put(PersonalityType.EFFICIENT, 0.9); // Females slightly less efficient
        GENDER_PERSONALITY_MODIFIERS.put(Gender.FEMALE, femaleModifiers);
    }

    /**
     * Generate a name based on personality type and gender
     */
    public static String generate(PersonalityType personalityType, Gender gender) {
        if (gender == Gender.RANDOM) {
            gender = random.nextBoolean() ? Gender.MALE : Gender.FEMALE;
        }
        
        // Adjust personality based on gender
        personalityType = adjustPersonalityForGender(personalityType, gender);
        
        String[] prefixes;
        String[] suffixes;
        
        // Choose between gender-specific and personality-specific names
        if (random.nextDouble() < 0.6) { // 60% chance for gender-specific names
            prefixes = (gender == Gender.MALE) ? MALE_PREFIXES : FEMALE_PREFIXES;
            suffixes = (gender == Gender.MALE) ? MALE_SUFFIXES : FEMALE_SUFFIXES;
        } else { // 40% chance for personality-specific names
            switch (personalityType) {
                case EFFICIENT:
                    prefixes = EFFICIENT_PREFIXES;
                    suffixes = EFFICIENT_SUFFIXES;
                    break;
                case CHILL:
                    prefixes = CHILL_PREFIXES;
                    suffixes = CHILL_SUFFIXES;
                    break;
                case VETERAN:
                    prefixes = VETERAN_PREFIXES;
                    suffixes = VETERAN_SUFFIXES;
                    break;
                case NEWBIE:
                    prefixes = NEWBIE_PREFIXES;
                    suffixes = NEWBIE_SUFFIXES;
                    break;
                case CASUAL:
                    prefixes = CASUAL_PREFIXES;
                    suffixes = CASUAL_SUFFIXES;
                    break;
                case PKER:
                    prefixes = PKER_PREFIXES;
                    suffixes = PKER_SUFFIXES;
                    break;
                case PVMER:
                    prefixes = PVMER_PREFIXES;
                    suffixes = PVMER_SUFFIXES;
                    break;
                case SKILLER:
                    prefixes = SKILLER_PREFIXES;
                    suffixes = SKILLER_SUFFIXES;
                    break;
                case IRONMAN:
                    prefixes = IRONMAN_PREFIXES;
                    suffixes = IRONMAN_SUFFIXES;
                    break;
                case RANDOM:
                default:
                    return generateRandomPersonality();
            }
        }
        
        return generateNameFromArrays(prefixes, suffixes, personalityType, gender);
    }
    
    /**
     * Generate a name with random personality type and gender
     */
    public static String generate() {
        return generate(PersonalityType.RANDOM, Gender.RANDOM);
    }
    
    /**
     * Generate a name with random personality type and specified gender
     */
    public static String generate(Gender gender) {
        return generate(PersonalityType.RANDOM, gender);
    }
    
    /**
     * Generate name based on behavioral fingerprint personality and gender
     */
    public static String generateFromPersonality(String personalityType, Gender gender) {
        try {
            PersonalityType type = PersonalityType.valueOf(personalityType.toUpperCase());
            return generate(type, gender);
        } catch (IllegalArgumentException e) {
            // If personality type not found, generate random
            return generate(gender);
        }
    }
    
    /**
     * Generate name based on behavioral fingerprint personality (with random gender)
     */
    public static String generateFromPersonality(String personalityType) {
        return generateFromPersonality(personalityType, Gender.RANDOM);
    }
    
    /**
     * Alias for generate() method for compatibility
     */
    public static String generateName() {
        return generate();
    }
    
    /**
     * Generate name with gender awareness
     */
    public static String generateName(Gender gender) {
        return generate(gender);
    }
    
    private static PersonalityType adjustPersonalityForGender(PersonalityType personalityType, Gender gender) {
        if (gender == Gender.RANDOM) {
            return personalityType;
        }
        
        Map<PersonalityType, Double> modifiers = GENDER_PERSONALITY_MODIFIERS.get(gender);
        if (modifiers == null) {
            return personalityType;
        }
        
        // Apply gender-based personality adjustments
        Double modifier = modifiers.get(personalityType);
        if (modifier != null && random.nextDouble() < (modifier - 1.0)) {
            // Adjust personality based on gender tendencies
            switch (gender) {
                case MALE:
                    if (personalityType == PersonalityType.CHILL && random.nextDouble() < 0.3) {
                        return PersonalityType.EFFICIENT; // Males more likely to be efficient than chill
                    }
                    if (personalityType == PersonalityType.NEWBIE && random.nextDouble() < 0.4) {
                        return PersonalityType.VETERAN; // Males more likely to be veterans than newbies
                    }
                    break;
                case FEMALE:
                    if (personalityType == PersonalityType.PKER && random.nextDouble() < 0.4) {
                        return PersonalityType.SKILLER; // Females more likely to be skillers than PKers
                    }
                    if (personalityType == PersonalityType.EFFICIENT && random.nextDouble() < 0.3) {
                        return PersonalityType.CHILL; // Females more likely to be chill than efficient
                    }
                    break;
            }
        }
        
        return personalityType;
    }
    
    private static String generateRandomPersonality() {
        PersonalityType[] types = PersonalityType.values();
        PersonalityType randomType = types[random.nextInt(types.length - 1)]; // Exclude RANDOM
        return generate(randomType, Gender.RANDOM);
    }
    
    private static String generateNameFromArrays(String[] prefixes, String[] suffixes, PersonalityType type, Gender gender) {
        // Try multiple variations to find an available name
        for (int attempt = 0; attempt < MAX_NAME_ATTEMPTS; attempt++) {
            String prefix = prefixes[random.nextInt(prefixes.length)];
            String suffix = suffixes[random.nextInt(suffixes.length)];
            
            // Apply personality-based transformations
            String name = applyPersonalityTransformations(prefix, suffix, type, attempt, gender);
            
            // Ensure max 12 characters
            if (name.length() <= 12) {
                return name;
            }
        }
        
        // Fallback: generate a simple name with heavy substitutions
        return generateFallbackName(type, gender);
    }
    
    private static String applyPersonalityTransformations(String prefix, String suffix, PersonalityType type, int attempt, Gender gender) {
        String name = prefix + suffix;
        
        // Apply leet speak based on personality type and attempt number
        double leetChance = getLeetChance(type, gender) + (attempt * 0.1); // Increase leet speak with attempts
        if (random.nextDouble() < leetChance) {
            name = applyAdvancedLeetSpeak(name, type, gender);
        }
        
        // Add numbers based on personality type and attempt number
        double numberChance = getNumberChance(type, gender) + (attempt * 0.15); // Increase numbers with attempts
        if (random.nextDouble() < numberChance) {
            int number = getNumberForPersonality(type, gender);
            name += number;
        }
        
        // Add special characters based on personality type and attempt number
        double specialChance = getSpecialChance(type, gender) + (attempt * 0.1); // Increase special chars with attempts
        if (random.nextDouble() < specialChance) {
            String special = getSpecialForPersonality(type, gender);
            name += special;
        }
        
        // Add name variations for higher attempts
        if (attempt > 5) {
            name = addNameVariations(name, type, attempt, gender);
        }
        
        // Add double letters for naturalness (lower attempts)
        if (attempt < 3 && random.nextDouble() < 0.3) {
            name = addDoubleLetters(name);
        }
        
        return name;
    }
    
    private static String applyAdvancedLeetSpeak(String input, PersonalityType type, Gender gender) {
        StringBuilder result = new StringBuilder();
        
        for (char c : input.toCharArray()) {
            char lowerC = Character.toLowerCase(c);
            
            // Check if we have a substitution for this character
            if (CHARACTER_SUBSTITUTIONS.containsKey(lowerC)) {
                String[] substitutions = CHARACTER_SUBSTITUTIONS.get(lowerC);
                
                // Personality and gender-based substitution chance
                double subChance = getSubstitutionChance(type, gender);
                if (random.nextDouble() < subChance) {
                    String substitution = substitutions[random.nextInt(substitutions.length)];
                    result.append(substitution);
                } else {
                    result.append(c);
                }
            } else {
                result.append(c);
            }
        }
        
        return result.toString();
    }
    
    private static double getSubstitutionChance(PersonalityType type, Gender gender) {
        double baseChance = getSubstitutionChance(type);
        
        // Gender adjustments
        switch (gender) {
            case MALE:
                baseChance *= 1.1; // Males slightly more likely to use leet speak
                break;
            case FEMALE:
                baseChance *= 0.9; // Females slightly less likely to use leet speak
                break;
        }
        
        return baseChance;
    }
    
    private static double getLeetChance(PersonalityType type, Gender gender) {
        double baseChance = getLeetChance(type);
        
        // Gender adjustments
        switch (gender) {
            case MALE:
                baseChance *= 1.1; // Males slightly more likely to use leet speak
                break;
            case FEMALE:
                baseChance *= 0.9; // Females slightly less likely to use leet speak
                break;
        }
        
        return baseChance;
    }
    
    private static double getNumberChance(PersonalityType type, Gender gender) {
        double baseChance = getNumberChance(type);
        
        // Gender adjustments
        switch (gender) {
            case MALE:
                baseChance *= 1.05; // Males slightly more likely to use numbers
                break;
            case FEMALE:
                baseChance *= 0.95; // Females slightly less likely to use numbers
                break;
        }
        
        return baseChance;
    }
    
    private static double getSpecialChance(PersonalityType type, Gender gender) {
        double baseChance = getSpecialChance(type);
        
        // Gender adjustments
        switch (gender) {
            case MALE:
                baseChance *= 1.05; // Males slightly more likely to use special chars
                break;
            case FEMALE:
                baseChance *= 0.95; // Females slightly less likely to use special chars
                break;
        }
        
        return baseChance;
    }
    
    private static int getNumberForPersonality(PersonalityType type, Gender gender) {
        int baseNumber = getNumberForPersonality(type);
        
        // Gender-specific number preferences
        switch (gender) {
            case MALE:
                // Males might prefer "cooler" numbers
                if (random.nextDouble() < 0.3) {
                    return random.nextInt(999); // Any number
                }
                break;
            case FEMALE:
                // Females might prefer smaller, "prettier" numbers
                if (random.nextDouble() < 0.4) {
                    return random.nextInt(99); // Smaller numbers
                }
                break;
        }
        
        return baseNumber;
    }
    
    private static String getSpecialForPersonality(PersonalityType type, Gender gender) {
        String[] specials = {"_", "x", "X", "z", "Z"};
        
        // Gender-specific special character preferences
        switch (gender) {
            case MALE:
                // Males might prefer more aggressive special chars
                if (random.nextDouble() < 0.3) {
                    return specials[random.nextInt(specials.length)];
                }
                break;
            case FEMALE:
                // Females might prefer softer special chars
                if (random.nextDouble() < 0.4) {
                    return "_"; // Prefer underscore
                }
                break;
        }
        
        return getSpecialForPersonality(type);
    }
    
    private static String addNameVariations(String name, PersonalityType type, int attempt, Gender gender) {
        // Add prefix variations
        if (random.nextDouble() < 0.3) {
            String prefix = NAME_VARIATIONS[random.nextInt(6)]; // First 6 are prefixes
            name = prefix + name;
        }
        
        // Add suffix variations
        if (random.nextDouble() < 0.4) {
            String suffix = NAME_VARIATIONS[random.nextInt(NAME_VARIATIONS.length - 6) + 6];
            name = name + suffix;
        }
        
        // Add personality-specific variations
        switch (type) {
            case PKER:
                if (random.nextDouble() < 0.3) {
                    name += "PK";
                }
                break;
            case PVMER:
                if (random.nextDouble() < 0.3) {
                    name += "PvM";
                }
                break;
            case IRONMAN:
                if (random.nextDouble() < 0.3) {
                    name += "BTW";
                }
                break;
            case EFFICIENT:
                if (random.nextDouble() < 0.3) {
                    name += "Xp";
                }
                break;
        }
        
        // Add gender-specific variations
        switch (gender) {
            case MALE:
                if (random.nextDouble() < 0.2) {
                    name += "King";
                }
                break;
            case FEMALE:
                if (random.nextDouble() < 0.2) {
                    name += "Queen";
                }
                break;
        }
        
        return name;
    }
    
    private static String addDoubleLetters(String name) {
        // Find a good place to add double letters
        for (int i = 0; i < name.length() - 1; i++) {
            char current = Character.toLowerCase(name.charAt(i));
            char next = Character.toLowerCase(name.charAt(i + 1));
            
            // Check if this could be a double letter
            if (current == next) {
                // Already has double letter, try to add another
                if (i < name.length() - 2) {
                    String doublePattern = DOUBLE_LETTERS[random.nextInt(DOUBLE_LETTERS.length)];
                    return name.substring(0, i + 2) + doublePattern + name.substring(i + 2);
                }
            }
        }
        
        // Add double letter at a random position
        if (name.length() > 2) {
            int pos = random.nextInt(name.length() - 1);
            String doublePattern = DOUBLE_LETTERS[random.nextInt(DOUBLE_LETTERS.length)];
            return name.substring(0, pos) + doublePattern + name.substring(pos);
        }
        
        return name;
    }
    
    private static String generateFallbackName(PersonalityType type, Gender gender) {
        // Generate a heavily modified name for high availability
        String baseName = getBaseNameForPersonality(type, gender);
        
        // Apply heavy substitutions
        baseName = applyHeavySubstitutions(baseName);
        
        // Add random numbers
        baseName += random.nextInt(9999);
        
        // Add special characters
        String[] specials = {"_", "x", "X", "z", "Z"};
        baseName += specials[random.nextInt(specials.length)];
        
        return baseName.length() > 12 ? baseName.substring(0, 12) : baseName;
    }
    
    private static String getBaseNameForPersonality(PersonalityType type, Gender gender) {
        // Gender-specific base names
        switch (gender) {
            case MALE:
                switch (type) {
                    case EFFICIENT: return "Fast";
                    case CHILL: return "Cool";
                    case VETERAN: return "Old";
                    case NEWBIE: return "New";
                    case CASUAL: return "Easy";
                    case PKER: return "Kill";
                    case PVMER: return "Boss";
                    case SKILLER: return "Skill";
                    case IRONMAN: return "Iron";
                    default: return "Player";
                }
            case FEMALE:
                switch (type) {
                    case EFFICIENT: return "Quick";
                    case CHILL: return "Calm";
                    case VETERAN: return "Wise";
                    case NEWBIE: return "Fresh";
                    case CASUAL: return "Gentle";
                    case PKER: return "Fierce";
                    case PVMER: return "Brave";
                    case SKILLER: return "Craft";
                    case IRONMAN: return "Strong";
                    default: return "Player";
                }
            default:
                return getBaseNameForPersonality(type);
        }
    }
    
    private static String applyHeavySubstitutions(String input) {
        StringBuilder result = new StringBuilder();
        
        for (char c : input.toCharArray()) {
            char lowerC = Character.toLowerCase(c);
            
            if (CHARACTER_SUBSTITUTIONS.containsKey(lowerC)) {
                String[] substitutions = CHARACTER_SUBSTITUTIONS.get(lowerC);
                String substitution = substitutions[random.nextInt(substitutions.length)];
                result.append(substitution);
            } else {
                result.append(c);
            }
        }
        
        return result.toString();
    }
    
    // Base methods for personality-based chances (without gender)
    private static double getSubstitutionChance(PersonalityType type) {
        switch (type) {
            case EFFICIENT: return 0.4; // High substitution for efficiency
            case CHILL: return 0.2; // Low substitution for chill
            case VETERAN: return 0.3; // Moderate substitution
            case NEWBIE: return 0.1; // Very low substitution
            case CASUAL: return 0.25; // Moderate substitution
            case PKER: return 0.5; // High substitution for edge
            case PVMER: return 0.35; // Moderate substitution
            case SKILLER: return 0.3; // Moderate substitution
            case IRONMAN: return 0.35; // Moderate substitution
            default: return 0.3;
        }
    }
    
    private static double getLeetChance(PersonalityType type) {
        switch (type) {
            case EFFICIENT: return 0.3; // Some leet speak for efficiency
            case CHILL: return 0.1; // Minimal leet speak
            case VETERAN: return 0.2; // Some leet speak
            case NEWBIE: return 0.05; // Very little leet speak
            case CASUAL: return 0.15; // Moderate leet speak
            case PKER: return 0.4; // More leet speak for edge
            case PVMER: return 0.25; // Some leet speak
            case SKILLER: return 0.2; // Some leet speak
            case IRONMAN: return 0.3; // Some leet speak for pride
            default: return 0.2;
        }
    }
    
    private static double getNumberChance(PersonalityType type) {
        switch (type) {
            case EFFICIENT: return 0.6; // Numbers for efficiency
            case CHILL: return 0.3; // Fewer numbers
            case VETERAN: return 0.5; // Some numbers
            case NEWBIE: return 0.2; // Few numbers
            case CASUAL: return 0.4; // Moderate numbers
            case PKER: return 0.7; // Many numbers for edge
            case PVMER: return 0.5; // Some numbers
            case SKILLER: return 0.6; // Numbers for grinding
            case IRONMAN: return 0.5; // Some numbers
            default: return 0.4;
        }
    }
    
    private static double getSpecialChance(PersonalityType type) {
        switch (type) {
            case EFFICIENT: return 0.2; // Some special chars
            case CHILL: return 0.1; // Few special chars
            case VETERAN: return 0.15; // Some special chars
            case NEWBIE: return 0.05; // Very few special chars
            case CASUAL: return 0.1; // Few special chars
            case PKER: return 0.3; // More special chars for edge
            case PVMER: return 0.2; // Some special chars
            case SKILLER: return 0.15; // Some special chars
            case IRONMAN: return 0.2; // Some special chars
            default: return 0.15;
        }
    }
    
    private static int getNumberForPersonality(PersonalityType type) {
        switch (type) {
            case EFFICIENT: return random.nextInt(999); // Any number
            case CHILL: return random.nextInt(99); // Smaller numbers
            case VETERAN: return random.nextInt(999); // Any number
            case NEWBIE: return random.nextInt(50); // Very small numbers
            case CASUAL: return random.nextInt(199); // Small numbers
            case PKER: return random.nextInt(999); // Any number
            case PVMER: return random.nextInt(999); // Any number
            case SKILLER: return random.nextInt(999); // Any number
            case IRONMAN: return random.nextInt(999); // Any number
            default: return random.nextInt(999);
        }
    }
    
    private static String getSpecialForPersonality(PersonalityType type) {
        String[] specials = {"_", "x", "X", "z", "Z"};
        switch (type) {
            case EFFICIENT: return specials[random.nextInt(specials.length)];
            case CHILL: return specials[random.nextInt(2)]; // Only _ and x
            case VETERAN: return specials[random.nextInt(specials.length)];
            case NEWBIE: return "_"; // Only underscore
            case CASUAL: return specials[random.nextInt(3)]; // _, x, X
            case PKER: return specials[random.nextInt(specials.length)];
            case PVMER: return specials[random.nextInt(specials.length)];
            case SKILLER: return specials[random.nextInt(specials.length)];
            case IRONMAN: return specials[random.nextInt(specials.length)];
            default: return specials[random.nextInt(specials.length)];
        }
    }
    
    private static String getBaseNameForPersonality(PersonalityType type) {
        switch (type) {
            case EFFICIENT: return "Fast";
            case CHILL: return "Cool";
            case VETERAN: return "Old";
            case NEWBIE: return "New";
            case CASUAL: return "Easy";
            case PKER: return "Kill";
            case PVMER: return "Boss";
            case SKILLER: return "Skill";
            case IRONMAN: return "Iron";
            default: return "Player";
        }
    }
    
    /**
     * Test method to demonstrate personality-based name generation
     */
    public static void main(String[] args) {
        System.out.println("=== Personality-Based Name Generator Demo ===\n");
        
        PersonalityType[] types = {
            PersonalityType.EFFICIENT, PersonalityType.CHILL, PersonalityType.VETERAN,
            PersonalityType.NEWBIE, PersonalityType.CASUAL, PersonalityType.PKER,
            PersonalityType.PVMER, PersonalityType.SKILLER, PersonalityType.IRONMAN
        };
        
        for (PersonalityType type : types) {
            System.out.println(type.name() + " Names:");
            for (int i = 0; i < 5; i++) {
                String name = generate(type, Gender.RANDOM);
                System.out.println("  " + name);
            }
            System.out.println();
        }
        
        System.out.println("Random Personality Names:");
        for (int i = 0; i < 10; i++) {
            String name = generate();
            System.out.println("  " + name);
        }
    }
}
