package tasks.tutorial;

import antiban.AdvancedAntibanManager;
import framework.Task;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.methods.container.impl.Inventory;

public class QuestGuideTask extends TutorialIslandAntibanTask {

    private static final String QUEST_GUIDE_NAME = "Quest Guide";
    private static final Tile QUEST_GUIDE_TILE = new Tile(3088, 3124, 0);
    private static final Tile MINING_INSTRUCTOR_TILE = new Tile(3081, 9504, 0);

    // Main entry tile after leaving cook's house
    private static final Tile COOK_EXIT_TILE = new Tile(3088, 3123, 0);

    // Tile just outside Quest Guide's house (near door)
    private static final Tile QUEST_HOUSE_ENTRY_TILE = new Tile(3088, 3124, 0);

    // Accurate area for the inside of the Quest Guide's house: SW (3083, 3119), NE (3089, 3125)
    private static final Area QUEST_GUIDE_AREA = new Area(3087, 3123, 3090, 3126, 0);

    // Quest Guide door specifics
    private static final int QUEST_DOOR_ID = 9716;
    private static final Tile QUEST_DOOR_TILE = new Tile(3089, 3124, 0);

    // Ladder specifics (from your screenshot)
    private static final int LADDER_ID = 9726;
    private static final Tile LADDER_TILE = new Tile(3088, 3126, 0);

    // Quest Guide NPC ID
    private static final int QUEST_GUIDE_ID = 3312;

    private boolean areasLogged = false;
    private final AdvancedAntibanManager antibanManager;

    public QuestGuideTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }

    @Override
    public boolean canExecute() {
        return getProgress() >= 260 && getProgress() <= 360;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
            antibanManager.tick();
        }

        performRandomAntiBan();

        int progress = getProgress();
        Tile playerTile = Players.getLocal() != null ? Players.getLocal().getTile() : null;
        Logger.log("[QuestGuide][Progress] Varbit 281 = " + progress + ", PlayerTile=" + playerTile);

        if (!areasLogged) {
            Logger.log("[QuestGuide][AREAS] QUEST_GUIDE_AREA: " + QUEST_GUIDE_AREA);
            Logger.log("[QuestGuide][AREAS] QUEST_HOUSE_ENTRY_TILE: " + QUEST_HOUSE_ENTRY_TILE);
            Logger.log("[QuestGuide][AREAS] QUEST_DOOR_TILE: " + QUEST_DOOR_TILE);
            Logger.log("[QuestGuide][AREAS] LADDER_TILE: " + LADDER_TILE);
            areasLogged = true;
        }

        // Handle tutorial dialogue system
        if (handleTutorialDialogue()) {
            return antibanManager.sleepMedium();
        }

        // Handle regular NPC dialogue
        if (Dialogues.inDialogue()) {
            handleDialogue();
            return antibanManager.sleepMedium();
        }

        switch (progress) {
            case 200:
                enterQuestGuideHouse();
                break;
            case 220:
                talkToQuestGuide();
                break;
            case 230:
                openQuestTab();
                break;
            case 240:
                talkToQuestGuideAfterQuests();
                break;
            case 250:
                climbDownLadder();
                break;
            default:
                Logger.log("QuestGuideTask in unexpected state with progress: " + progress);
                // Fallback: try to talk to guide
                talkToQuestGuide();
                break;
        }

        if (antibanManager != null) {
            return antibanManager.sleepShort();
        }
        return 600;
    }

    private boolean handleTutorialDialogue() {
        // Check for tutorial dialogue widget (always present during tutorial)
        // TODO: Widget handling needs update for current DreamBot API
        // Widget widget = Widgets.getWidget(263);
        // WidgetChild tutorialWidget = widget != null ? widget.getChild(1) : null;
        // if (tutorialWidget != null && tutorialWidget.isVisible()) {
        //     String text = tutorialWidget.getText();
        //     if (text != null) {
        //         Logger.log("Tutorial dialogue: " + text);
        //         
        //         // Handle different tutorial prompts
        //         if (text.contains("click here to continue")) {
        //             tutorialWidget.interact();
        //             Sleep.sleep(300, 600);
        //             return true;
        //         }
        //         
        //         if (text.contains("enter the door")) {
        //             enterQuestGuideHouse();
        //             return true;
        //         }
        //         
        //         if (text.contains("talk to the Quest Guide")) {
        //             talkToQuestGuide();
        //             return true;
        //         }
        //         
        //         if (text.contains("open your quest tab")) {
        //             openQuestTab();
        //             return true;
        //         }
        //         
        //         if (text.contains("climb down the ladder")) {
        //             climbDownLadder();
        //             return true;
        //         }
        //     }
        // }
        return false;
    }

    @Override
    protected void handleDialogue() {
        if (Dialogues.canContinue()) {
            Dialogues.continueDialogue();
            Sleep.sleep(600, 900);
        } else if (Dialogues.getOptions() != null && Dialogues.getOptions().length > 0) {
            // Select first option for tutorial simplicity
            Dialogues.chooseOption(1);
            Sleep.sleep(600, 900);
        }
    }

    private void enterQuestGuideHouse() {
        Logger.log("Entering Quest Guide house.");
        
        // Check if we're already inside
        if (QUEST_GUIDE_AREA.contains(Players.getLocal())) {
            Logger.log("Already inside Quest Guide house.");
            return;
        }

        // Walk to door
        if (Players.getLocal().distance(QUEST_DOOR_TILE) > 1) {
            Walking.walk(QUEST_DOOR_TILE);
            Sleep.sleepUntil(() -> Players.getLocal().distance(QUEST_DOOR_TILE) <= 1, 3000);
            return;
        }

        // Open door
        GameObject door = GameObjects.closest(obj -> 
            obj.getTile().equals(QUEST_DOOR_TILE) && obj.hasAction("Open"));
        if (door != null) {
            if (door.interact("Open")) {
                Sleep.sleepUntil(() -> QUEST_GUIDE_AREA.contains(Players.getLocal()), 5000);
            }
        } else {
            Logger.log("Could not find Quest Guide house door.");
        }
    }

    private void talkToQuestGuide() {
        Logger.log("Talking to Quest Guide.");
        NPC guide = NPCs.closest(QUEST_GUIDE_NAME);
        if (guide != null && guide.canReach()) {
            if (guide.interact("Talk-to")) {
                Sleep.sleepUntil(Dialogues::inDialogue, 3000);
            }
        } else {
            Logger.log("Could not find Quest Guide.");
        }
    }

    private void openQuestTab() {
        Logger.log("Opening quest tab.");
        if (!Tabs.isOpen(Tab.QUEST)) {
            Tabs.open(Tab.QUEST);
            Sleep.sleep(600, 900);
        }
    }

    private void talkToQuestGuideAfterQuests() {
        Logger.log("Talking to Quest Guide after opening quest tab.");
        talkToQuestGuide();
    }

    private void climbDownLadder() {
        Logger.log("Climbing down ladder to mining area.");
        
        // Walk to ladder if not close enough
        if (Players.getLocal().distance(LADDER_TILE) > 1) {
            Walking.walk(LADDER_TILE);
            Sleep.sleepUntil(() -> Players.getLocal().distance(LADDER_TILE) <= 1, 3000);
            return;
        }

        // Climb down ladder
        GameObject ladder = GameObjects.closest(obj -> 
            obj.getTile().equals(LADDER_TILE) && obj.hasAction("Climb-down"));
        
        if (ladder != null) {
            if (ladder.interact("Climb-down")) {
                Sleep.sleepUntil(() -> getProgress() > 250, 5000);
            }
        } else {
            Logger.log("Could not find ladder.");
        }
    }

    @Override
    public String getTaskName() {
        return "Quest Guide";
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getConfig(281);
    }
}