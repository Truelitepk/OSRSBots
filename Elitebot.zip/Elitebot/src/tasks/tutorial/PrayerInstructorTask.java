package tasks.tutorial;

import antiban.AntibanManager;
import antiban.AdvancedAntibanManager;
import framework.Task;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.items.Item;

public class PrayerInstructorTask extends TutorialIslandAntibanTask {

    private static final String PRAYER_INSTRUCTOR_NAME = "Brother Brace";
    private static final Tile PRAYER_INSTRUCTOR_TILE = new Tile(3129, 3124, 0);
    private static final Area PRAYER_AREA = new Area(3122, 3123, 3129, 3128, 0);
    private static final Area MAGIC_AREA = new Area(3135, 3105, 3142, 3115, 0);
    private static final String TUTOR_NAME = "Brother Brace";

    // Items
    private static final String BONES = "Bones";

    // Progress tracking
    private boolean talkedToInstructor = false;
    private boolean openedPrayerTab = false;
    private boolean buriedBones = false;
    private boolean openedSocialTabs = false;
    private boolean completed = false;

    private static final int VARBIT_PRAYER_START = 640;
    private static final int VARBIT_PRAYER_END = 700;

    private AdvancedAntibanManager antibanManager;

    public PrayerInstructorTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }

    @Override
    public boolean canExecute() {
        return getProgress() >= 550 && getProgress() <= 610;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
            antibanManager.tick();
        }

        int currentProgress = getProgress();
        
        if (Dialogues.inDialogue()) {
            handleDialogue();
            return antibanManager != null ? antibanManager.sleepMedium() : 600;
        }

        switch (currentProgress) {
            case 0:
                return handleInitialDialogue();
            case 1:
                return handlePrayerTraining();
            case 2:
                return handleFriendsList();
            case 3:
                return handleIgnoredList();
            default:
                Logger.log("PrayerInstructorTask in unexpected state with progress: " + currentProgress);
                return 1000;
        }
    }

    @Override
    public String getTaskName() {
        return "Prayer Instructor";
    }

    @Override
    protected void handleDialogue() {
        if (Dialogues.canContinue()) {
            Dialogues.continueDialogue();
            Sleep.sleep(600, 900);
        } else if (Dialogues.getOptions() != null && Dialogues.getOptions().length > 0) {
            // Select first option for tutorial simplicity
            Dialogues.chooseOption(1);
            Sleep.sleep(600, 900);
        }
    }

    private void talkToPrayerInstructor() {
        Logger.log("Talking to Prayer Instructor.");
        NPC instructor = NPCs.closest(PRAYER_INSTRUCTOR_NAME);
        if (instructor != null && instructor.canReach()) {
            if (instructor.interact("Talk-to")) {
                Sleep.sleepUntil(Dialogues::inDialogue, 3000);
            }
        } else {
            Logger.log("Could not find Prayer Instructor.");
        }
    }

    private void openPrayerTab() {
        Logger.log("Opening prayer tab.");
        if (!Tabs.isOpen(Tab.PRAYER)) {
            Tabs.open(Tab.PRAYER);
            Sleep.sleep(600, 900);
        }
    }

    private void buryBones() {
        Logger.log("Burying bones.");
        
        Item bones = Inventory.get("Bones");
        if (bones != null) {
            if (bones.interact("Bury")) {
                Sleep.sleepUntil(() -> !Inventory.contains(BONES), 3000);
            }
        } else {
            Logger.log("No bones found in inventory.");
        }
    }

    private void openFriendsList() {
        Logger.log("Opening friends list.");
        if (!Tabs.isOpen(Tab.FRIENDS)) {
            Tabs.open(Tab.FRIENDS);
        }
    }

    private void openIgnoreList() {
        Logger.log("Opening ignore list. (No direct tab in DreamBot API)");
    }

    private void exitPrayerArea() {
        Logger.log("Exiting prayer area.");
        
        // Check if we're already outside
        if (!PRAYER_AREA.contains(Players.getLocal())) {
            Logger.log("Already outside prayer area.");
            return;
        }

        // Find and open door
        GameObject door = GameObjects.closest(obj -> 
            obj.getName().equalsIgnoreCase("Door") && obj.hasAction("Open"));
        
        if (door != null) {
            if (door.interact("Open")) {
                Sleep.sleepUntil(() -> !PRAYER_AREA.contains(Players.getLocal()), 5000);
            }
        } else {
            Logger.log("Could not find door to exit.");
        }
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getConfig(281);
    }

    private int handleInitialDialogue() {
        // Handle initial dialogue with prayer instructor
        return antibanManager != null ? antibanManager.sleepMedium() : 600;
    }
    
    private int handlePrayerTraining() {
        // Handle prayer training logic
        return antibanManager != null ? antibanManager.sleepMedium() : 600;
    }
    
    private int handleFriendsList() {
        // Handle friends list interaction
        return antibanManager != null ? antibanManager.sleepMedium() : 600;
    }
    
    private int handleIgnoredList() {
        // Handle ignored list interaction
        return antibanManager != null ? antibanManager.sleepMedium() : 600;
    }
}
