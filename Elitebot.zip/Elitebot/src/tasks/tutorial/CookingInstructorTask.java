package tasks.tutorial;

import antiban.AdvancedAntibanManager;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.items.Item;

public class CookingInstructorTask extends TutorialIslandAntibanTask {

    // Area and tile constants
    private static final Area COOKS_HOUSE_AREA = new Area(3072, 3080, 3080, 3091);
    private static final Tile ENTRANCE_DOOR_TILE = new Tile(3079, 3084, 0);
    private static final Tile EXIT_DOOR_TILE = new Tile(3072, 3090, 0);
    private static final Tile RANGE_TILE = new Tile(3075, 3081, 0);

    // Item constants
    private static final String POT_OF_FLOUR = "Pot of flour";
    private static final String BUCKET_OF_WATER = "Bucket of water";
    private static final String BREAD_DOUGH = "Bread dough";
    private static final String BREAD = "Bread";

    // NPC name
    private static final String MASTER_CHEF_NAME = "Master Chef";

    private final AdvancedAntibanManager antibanManager;

    public CookingInstructorTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }

    @Override
    public boolean canExecute() {
        return getProgress() >= 130 && getProgress() <= 250;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
            antibanManager.tick();
        }

        // Add task logic here

        if (antibanManager != null) {
            return antibanManager.sleepShort();
        }
        return 600;
    }

    @Override
    public String getTaskName() {
        return "Cooking Instructor";
    }

    private boolean handleTutorialDialogue() {
        // Check for tutorial dialogue widget (always present during tutorial)
        // TODO: Widget handling needs update for current DreamBot API
        // Widget widget = Widgets.getWidget(263);
        // WidgetChild tutorialWidget = widget != null ? widget.getChild(1) : null;
        // if (tutorialWidget != null && tutorialWidget.isVisible()) {
        //     String text = tutorialWidget.getText();
        //     if (text != null) {
        //         Logger.log("Tutorial dialogue: " + text);
        //         
        //         // Handle different tutorial prompts
        //         if (text.contains("click here to continue")) {
        //             tutorialWidget.interact();
        //             Sleep.sleep(300, 600);
        //             return true;
        //         }
        //         
        //         if (text.contains("enter the door")) {
        //             enterCooksHouse();
        //             return true;
        //         }
        //         
        //         if (text.contains("talk to the Master Chef")) {
        //             talkToMasterChef();
        //             return true;
        //         }
        //         
        //         if (text.contains("use the pot of flour on the bucket of water")) {
        //             makeBreadDough();
        //             return true;
        //         }
        //         
        //         if (text.contains("cook the bread dough on the range")) {
        //             cookBread();
        //             return true;
        //         }
        //         
        //         if (text.contains("go through the door")) {
        //             exitCooksHouse();
        //             return true;
        //         }
        //     }
        // }
        return false;
    }

    @Override
    protected void handleDialogue() {
        if (Dialogues.canContinue()) {
            Dialogues.continueDialogue();
            Sleep.sleep(600, 900);
        } else if (Dialogues.getOptions() != null && Dialogues.getOptions().length > 0) {
            // Select first option for tutorial simplicity
            Dialogues.chooseOption(1);
            Sleep.sleep(600, 900);
        }
    }

    private void enterCooksHouse() {
        Logger.log("Entering cook's house.");
        
        // Check if we're already inside
        if (COOKS_HOUSE_AREA.contains(Players.getLocal())) {
            Logger.log("Already inside cook's house.");
            return;
        }

        // Walk to entrance door
        if (Players.getLocal().distance(ENTRANCE_DOOR_TILE) > 1) {
            Walking.walk(ENTRANCE_DOOR_TILE);
            Sleep.sleepUntil(() -> Players.getLocal().distance(ENTRANCE_DOOR_TILE) <= 1, 3000);
            return;
        }

        // Open entrance door
        GameObject entranceDoor = GameObjects.closest(obj -> 
            obj.getTile().equals(ENTRANCE_DOOR_TILE) && obj.hasAction("Open"));
        if (entranceDoor != null) {
            if (entranceDoor.interact("Open")) {
                Sleep.sleepUntil(() -> COOKS_HOUSE_AREA.contains(Players.getLocal()), 5000);
            }
        } else {
            Logger.log("Could not find entrance door.");
        }
    }

    private void talkToMasterChef() {
        Logger.log("Talking to Master Chef.");
        NPC chef = NPCs.closest(MASTER_CHEF_NAME);
        if (chef != null && chef.canReach()) {
            if (chef.interact("Talk-to")) {
                Sleep.sleepUntil(Dialogues::inDialogue, 3000);
            }
        } else {
            Logger.log("Could not find Master Chef.");
        }
    }

    private void makeBreadDough() {
        Logger.log("Making bread dough.");
        
        // Get pot of flour if we don't have it
        if (!Inventory.contains(POT_OF_FLOUR)) {
            GameObject flour = GameObjects.closest(obj -> 
                obj.getName().equalsIgnoreCase(POT_OF_FLOUR) && obj.hasAction("Take"));
            if (flour != null) {
                flour.interact("Take");
                Sleep.sleepUntil(() -> Inventory.contains(POT_OF_FLOUR), 3000);
                return;
            } else {
                Logger.log("Could not find pot of flour.");
                return;
            }
        }

        // Get bucket of water if we don't have it
        if (!Inventory.contains(BUCKET_OF_WATER)) {
            GameObject water = GameObjects.closest(obj -> 
                obj.getName().equalsIgnoreCase(BUCKET_OF_WATER) && obj.hasAction("Take"));
            if (water != null) {
                water.interact("Take");
                Sleep.sleepUntil(() -> Inventory.contains(BUCKET_OF_WATER), 3000);
                return;
            } else {
                Logger.log("Could not find bucket of water.");
                return;
            }
        }

        // Make bread dough
        if (Inventory.contains(POT_OF_FLOUR) && Inventory.contains(BUCKET_OF_WATER)) {
            Item flour = Inventory.get(POT_OF_FLOUR);
            Item water = Inventory.get(BUCKET_OF_WATER);
            
            if (flour != null && water != null) {
                flour.useOn(water);
                Sleep.sleepUntil(() -> Inventory.contains(BREAD_DOUGH), 3000);
            }
        }
    }

    private void cookBread() {
        Logger.log("Cooking bread.");
        
        if (!Inventory.contains(BREAD_DOUGH)) {
            Logger.log("No bread dough to cook.");
            return;
        }

        // Walk to range if not close enough
        if (Players.getLocal().distance(RANGE_TILE) > 1) {
            Walking.walk(RANGE_TILE);
            Sleep.sleepUntil(() -> Players.getLocal().distance(RANGE_TILE) <= 1, 3000);
            return;
        }

        // Cook bread dough on range
        Item dough = Inventory.get(BREAD_DOUGH);
        GameObject range = GameObjects.closest(obj -> 
            obj.getName().equalsIgnoreCase("Range") && obj.getTile().equals(RANGE_TILE));
        
        if (dough != null && range != null) {
            dough.useOn(range);
            Sleep.sleepUntil(() -> Inventory.contains(BREAD), 5000);
        } else {
            Logger.log("Could not find bread dough or range.");
        }
    }

    private void exitCooksHouse() {
        Logger.log("Exiting cook's house.");
        
        // Check if we're already outside
        if (!COOKS_HOUSE_AREA.contains(Players.getLocal())) {
            Logger.log("Already outside cook's house.");
            return;
        }

        // Walk to exit door
        if (Players.getLocal().distance(EXIT_DOOR_TILE) > 1) {
            Walking.walk(EXIT_DOOR_TILE);
            Sleep.sleepUntil(() -> Players.getLocal().distance(EXIT_DOOR_TILE) <= 1, 3000);
            return;
        }

        // Open exit door
        GameObject exitDoor = GameObjects.closest(obj -> 
            obj.getTile().equals(EXIT_DOOR_TILE) && obj.hasAction("Open"));
        if (exitDoor != null) {
            if (exitDoor.interact("Open")) {
                Sleep.sleepUntil(() -> !COOKS_HOUSE_AREA.contains(Players.getLocal()), 5000);
            }
        } else {
            Logger.log("Could not find exit door.");
        }
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getConfig(281);
    }
} 