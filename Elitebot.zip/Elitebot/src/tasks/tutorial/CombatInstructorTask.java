package tasks.tutorial;

import antiban.AdvancedAntibanManager;
import antiban.UUIDProfileCache;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.container.impl.equipment.EquipmentSlot;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.interactive.NPC;
import java.util.UUID;

public class CombatInstructorTask extends TutorialIslandAntibanTask {

    private final UUIDProfileCache profileCache;
    
    // Item names
    private static final String BRONZE_DAGGER = "Bronze dagger";
    private static final String BRONZE_SWORD = "Bronze sword";
    private static final String WOODEN_SHIELD = "Wooden shield";
    private static final String SHORTBOW = "Shortbow";
    private static final String BRONZE_ARROW = "Bronze arrow";

    // NPC name
    private static final String COMBAT_INSTRUCTOR_NAME = "Combat Instructor";
    private static final String GIANT_RAT_NAME = "Giant rat";

    // Areas
    private static final Area RAT_PEN_AREA = new Area(3108, 9516, 3112, 9520, 0);

    // Gates
    private static final String RAT_PEN_GATE_NAME = "Gate";

    private final AdvancedAntibanManager antibanManager;

    public CombatInstructorTask(AdvancedAntibanManager antibanManager, UUIDProfileCache profileCache) {
        super(antibanManager);
        this.antibanManager = antibanManager;
        this.profileCache = profileCache;
    }

    @Override
    public boolean canExecute() {
        // This task is now controlled by the state machine in execute().
        // We return true here to ensure the handler can always run this task
        // when it's supposed to, letting the state machine handle the logic.
        return true;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
            antibanManager.tick();
        }

        // --- Dialogue Handling: HIGHEST PRIORITY ---
        if (Dialogues.inDialogue()) {
            handleDialogue();
            return antibanManager.sleepShort();
        }
        
        // --- State Machine Logic ---
        int combatStep = profileCache.getCombatInstructorProgress();
        Logger.log("[CombatState] Executing phase " + combatStep);

        switch (combatStep) {
            case 0: // Initial melee setup and first kill
                executeInitialMeleePhase();
                break;
            case 1: // Get bow from instructor
                executeGetBowPhase();
                break;
            case 2: // Ranged kill
                executeRangedPhase();
                break;
            case 3: // Task complete, exit area
                exitCombatArea();
                break;
            default:
                Logger.log("Unknown combat instructor step: " + combatStep);
                Sleep.sleep(1000, 2000);
                break;
        }

        return antibanManager.sleepShort();
    }
    
    private void executeInitialMeleePhase() {
        // Phase completion condition
        if (Skills.getExperience(Skill.ATTACK) > 0) {
            profileCache.setCombatInstructorProgress(1);
            profileCache.forceSave();
            Logger.log("[CombatState] Progress updated to 1: Melee kill complete.");
            return;
        }

        // Get dagger if we don't have one (or a sword)
        if (!Inventory.contains(BRONZE_DAGGER) && !Inventory.contains(BRONZE_SWORD)) {
            talkToCombatInstructor();
            return;
        }

        // Open equipment tab and equip dagger
        if (Inventory.contains(BRONZE_DAGGER) && !Equipment.contains(BRONZE_DAGGER)) {
            openEquipmentTabAndStats();
            equipBronzeDagger();
            return;
        }
        
        // Get sword and shield
        if (Equipment.contains(BRONZE_DAGGER) && !Inventory.contains(BRONZE_SWORD)) {
            talkToCombatInstructor();
            return;
        }

        // Equip sword and shield
        if (Inventory.contains(BRONZE_SWORD) && !Equipment.contains(BRONZE_SWORD)) {
            openCombatStylesTab();
            equipSwordAndShield();
            return;
        }

        // If fully equipped for melee, fight.
        if (Equipment.contains(BRONZE_SWORD) && Equipment.contains(WOODEN_SHIELD)) {
            if (!RAT_PEN_AREA.contains(Players.getLocal())) {
                enterRatPen();
            } else {
                attackRatWithMelee();
            }
        }
    }

    private void executeGetBowPhase() {
        // Phase completion condition
        if (Inventory.contains(SHORTBOW)) {
            profileCache.setCombatInstructorProgress(2);
            profileCache.forceSave();
            Logger.log("[CombatState] Progress updated to 2: Bow acquired.");
            return;
        }

        // Get out of the pen before talking
        if (RAT_PEN_AREA.contains(Players.getLocal())) {
            exitRatPen();
            return;
        }
        
        // Talk to get the bow
        talkToCombatInstructor();
    }
    
    private void executeRangedPhase() {
        // Phase completion condition
        if (Skills.getExperience(Skill.RANGED) > 0) {
            profileCache.setCombatInstructorProgress(3);
            profileCache.forceSave();
            Logger.log("[CombatState] Progress updated to 3: Ranged kill complete.");
            return;
        }

        // Equip bow and arrows
        if (!Equipment.contains(SHORTBOW) || !Equipment.contains(BRONZE_ARROW)) {
            equipBowAndArrows();
            return;
        }

        // If equipped, go fight.
        if (!RAT_PEN_AREA.contains(Players.getLocal())) {
            enterRatPen();
        } else {
            attackRatWithRanged();
        }
    }

    @Override
    public String getTaskName() {
        return "Combat Instructor";
    }

    @Override
    protected void handleDialogue() {
        if (Dialogues.canContinue()) {
            Dialogues.continueDialogue();
            Sleep.sleep(600, 900);
        } else if (Dialogues.getOptions() != null && Dialogues.getOptions().length > 0) {
            // Select first option for tutorial simplicity
            Dialogues.chooseOption(1);
            Sleep.sleep(600, 900);
        }
    }

    private boolean talkToCombatInstructor() {
        // Logger.log("Talking to Combat Instructor.");
        NPC instructor = NPCs.closest(COMBAT_INSTRUCTOR_NAME);
        if (instructor != null && instructor.canReach()) {
            if (instructor.interact("Talk-to")) {
                Sleep.sleepUntil(Dialogues::inDialogue, 3000);
                return true;
            }
        }
        // Logger.log("Could not find Combat Instructor.");
        return false;
    }

    private boolean openEquipmentTab() {
        if (!Tabs.isOpen(Tab.EQUIPMENT)) {
            Tabs.open(Tab.EQUIPMENT);
            Sleep.sleepUntil(() -> Tabs.isOpen(Tab.EQUIPMENT), 2000);
        }
        return true;
    }

    private boolean openEquipmentTabAndStats() {
        if (!Tabs.isOpen(Tab.EQUIPMENT)) {
            Tabs.open(Tab.EQUIPMENT);
            Sleep.sleepUntil(() -> Tabs.isOpen(Tab.EQUIPMENT), 2000);
        }
        
        // Click the flashing "Worn Equipment" button after opening the tab.
        // Widget 84, child 1 is a common one for this.
        if (Widgets.getWidget(84) != null) {
            if(Widgets.getWidget(84).getChild(1).interact("View equipment stats")) {
                Sleep.sleep(600, 900);
                return true;
            }
        }
        return false;
    }

    private boolean equipBronzeDagger() {
        // Logger.log("Equipping bronze dagger.");
        if (Inventory.contains(BRONZE_DAGGER) && !Equipment.contains(BRONZE_DAGGER)) {
            Equipment.equip(EquipmentSlot.WEAPON, BRONZE_DAGGER);
            return Sleep.sleepUntil(() -> Equipment.contains(BRONZE_DAGGER), 3000);
        }
        return true;
    }

    private boolean equipSwordAndShield() {
        // Logger.log("Equipping sword and shield.");
        if (Inventory.contains(BRONZE_SWORD) && !Equipment.contains(BRONZE_SWORD)) {
            Equipment.equip(EquipmentSlot.WEAPON, BRONZE_SWORD);
            Sleep.sleepUntil(() -> Equipment.contains(BRONZE_SWORD), 3000);
        }
        if (Inventory.contains(WOODEN_SHIELD) && !Equipment.contains(WOODEN_SHIELD)) {
            Equipment.equip(EquipmentSlot.SHIELD, WOODEN_SHIELD);
            Sleep.sleepUntil(() -> Equipment.contains(WOODEN_SHIELD), 3000);
        }
        return true;
    }

    private boolean openCombatStylesTab() {
        // Logger.log("Opening combat styles tab.");
        if (!Tabs.isOpen(Tab.COMBAT)) {
            Tabs.open(Tab.COMBAT);
            Sleep.sleep(600, 900);
        }
        return true;
    }

    private boolean enterRatPen() {
        // Logger.log("Entering rat pen.");
        if (RAT_PEN_AREA.contains(Players.getLocal())) return true;

        GameObject gate = GameObjects.closest(obj -> 
            obj.getName().equalsIgnoreCase(RAT_PEN_GATE_NAME) && obj.hasAction("Open"));
        
        if (gate != null) {
            if (gate.interact("Open")) {
                return Sleep.sleepUntil(() -> RAT_PEN_AREA.contains(Players.getLocal()), 5000);
            }
        }
        return false;
    }

    private boolean attackRatWithMelee() {
        // Logger.log("Attacking rat with melee.");
        if (Players.getLocal().isInCombat()) return true;

        NPC rat = NPCs.closest(npc -> 
            npc != null && 
            npc.getName().equalsIgnoreCase(GIANT_RAT_NAME) && 
            RAT_PEN_AREA.contains(npc.getTile()) &&
            !npc.isInCombat());
        
        if (rat != null) {
            if (rat.interact("Attack")) {
                return Sleep.sleepUntil(() -> !rat.exists() || Players.getLocal().isInCombat(), 10000);
            }
        }
        return false;
    }

    private boolean exitRatPen() {
        // Logger.log("Exiting rat pen.");
        if (!RAT_PEN_AREA.contains(Players.getLocal())) return true;

        GameObject gate = GameObjects.closest(obj -> 
            obj.getName().equalsIgnoreCase(RAT_PEN_GATE_NAME) && obj.hasAction("Open"));
        
        if (gate != null) {
            if (gate.interact("Open")) {
                return Sleep.sleepUntil(() -> !RAT_PEN_AREA.contains(Players.getLocal()), 5000);
            }
        }
        return false;
    }

    private boolean equipBowAndArrows() {
        // Logger.log("Equipping bow and arrows.");
        if (Inventory.contains(SHORTBOW) && !Equipment.contains(SHORTBOW)) {
            Equipment.equip(EquipmentSlot.WEAPON, SHORTBOW);
            Sleep.sleepUntil(() -> Equipment.contains(SHORTBOW), 3000);
        }
        if (Inventory.contains(BRONZE_ARROW) && !Equipment.contains(BRONZE_ARROW)) {
            Equipment.equip(EquipmentSlot.ARROWS, BRONZE_ARROW);
            Sleep.sleepUntil(() -> Equipment.contains(BRONZE_ARROW), 3000);
        }
        return true;
    }

    private boolean attackRatWithRanged() {
        // Logger.log("Attacking rat with ranged.");
        if (Players.getLocal().isInCombat()) return true;
        
        NPC rat = NPCs.closest(npc -> 
            npc != null && 
            npc.getName().equalsIgnoreCase(GIANT_RAT_NAME) && 
            !npc.isInCombat());
        
        if (rat != null) {
            if (rat.interact("Attack")) {
                return Sleep.sleepUntil(() -> !rat.exists() || Players.getLocal().isInCombat(), 10000);
            }
        }
        return false;
    }

    private void exitCombatArea() {
        // Logger.log("Climbing ladder to exit combat area.");
        GameObject ladder = GameObjects.closest(obj -> 
            obj.getName().equalsIgnoreCase("Ladder") && 
            obj.hasAction("Climb-up"));
        
        if (ladder != null) {
            if (ladder.interact("Climb-up")) {
                Sleep.sleepUntil(() -> getProgress() > 500, 5000);
            }
        } else {
            // Logger.log("Could not find ladder to exit.");
        }
    }

    @Override
    public String getName() {
        return "Combat Instructor";
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getConfig(281);
    }
} 