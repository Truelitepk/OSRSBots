package tasks.tutorial;

import antiban.AdvancedAntibanManager;
import framework.Task;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.items.Item;

public class BankingInstructorTask extends TutorialIslandAntibanTask {

    // NPC name
    private static final String BANKING_INSTRUCTOR_NAME = "Banking Instructor";
    private static final String BANKER_NAME = "Banker";

    // Areas
    private static final Area BANK_AREA = new Area(3120, 3120, 3125, 3124, 0);

    // Objects
    private static final String BANK_BOOTH_NAME = "Bank booth";
    private static final String POLL_BOOTH_NAME = "Poll booth";

    private final AdvancedAntibanManager antibanManager;

    public BankingInstructorTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }

    @Override
    public boolean canExecute() {
        return getProgress() >= 510 && getProgress() <= 540;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
            antibanManager.tick();
        }

        // Add task logic here

        if (antibanManager != null) {
            return antibanManager.sleepShort();
        }
        return 600;
    }

    @Override
    public String getTaskName() {
        return "Banking Instructor";
    }

    private boolean handleTutorialDialogue() {
        // TODO: Widget handling needs update for current DreamBot API
        // Widget widget = Widgets.getWidget(263);
        // WidgetChild tutorialWidget = widget != null ? widget.getChild(1) : null;
        // Widget pollWidget = Widgets.getWidget(310);
        // WidgetChild closeButton = pollWidget.getChild(16);
        return false;
    }

    @Override
    protected void handleDialogue() {
        if (Dialogues.canContinue()) {
            Dialogues.continueDialogue();
            Sleep.sleep(600, 900);
        } else if (Dialogues.getOptions() != null && Dialogues.getOptions().length > 0) {
            // Select first option for tutorial simplicity
            Dialogues.chooseOption(1);
            Sleep.sleep(600, 900);
        }
    }

    private void talkToBankingInstructor() {
        Logger.log("Talking to Banking Instructor.");
        NPC instructor = NPCs.closest(BANKING_INSTRUCTOR_NAME);
        if (instructor != null && instructor.canReach()) {
            if (instructor.interact("Talk-to")) {
                Sleep.sleepUntil(Dialogues::inDialogue, 3000);
            }
        } else {
            Logger.log("Could not find Banking Instructor.");
        }
    }

    private void openBankBooth() {
        Logger.log("Opening bank booth.");
        
        if (Bank.isOpen()) {
            Logger.log("Bank is already open.");
            return;
        }

        GameObject bankBooth = GameObjects.closest(obj -> 
            obj.getName().equalsIgnoreCase(BANK_BOOTH_NAME) && obj.hasAction("Use"));
        
        if (bankBooth != null) {
            if (bankBooth.interact("Use")) {
                Sleep.sleepUntil(Bank::isOpen, 3000);
            }
        } else {
            Logger.log("Could not find bank booth.");
        }
    }

    private void depositItems() {
        Logger.log("Depositing items into bank.");
        
        if (!Bank.isOpen()) {
            Logger.log("Bank is not open.");
            return;
        }

        if (!Inventory.isEmpty()) {
            Bank.depositAllItems();
            Sleep.sleepUntil(Inventory::isEmpty, 3000);
        } else {
            Logger.log("Inventory is already empty.");
        }
    }

    private void closeBank() {
        Logger.log("Closing bank.");
        
        if (Bank.isOpen()) {
            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
        } else {
            Logger.log("Bank is already closed.");
        }
    }

    private void usePollBooth() {
        Logger.log("Using poll booth.");
        
        GameObject pollBooth = GameObjects.closest(obj -> 
            obj.getName().equalsIgnoreCase(POLL_BOOTH_NAME) && obj.hasAction("Use"));
        
        if (pollBooth != null) {
            if (pollBooth.interact("Use")) {
                Sleep.sleep(1000, 2000);
                // Close poll interface if it opens
                // TODO: Widget handling needs update for current DreamBot API
                // Widget pollWidget = Widgets.getWidget(310);
                // WidgetChild closeButton = pollWidget.getChild(16);
                // if (closeButton != null && closeButton.isVisible()) {
                //     closeButton.interact();
                //     Sleep.sleep(600, 900);
                // }
            }
        } else {
            Logger.log("Could not find poll booth.");
        }
    }

    private void exitBankArea() {
        Logger.log("Exiting bank area.");
        
        // Check if we're already outside
        if (!BANK_AREA.contains(Players.getLocal())) {
            Logger.log("Already outside bank area.");
            return;
        }

        // Find and open door
        GameObject door = GameObjects.closest(obj -> 
            obj.getName().equalsIgnoreCase("Door") && obj.hasAction("Open"));
        
        if (door != null) {
            if (door.interact("Open")) {
                Sleep.sleepUntil(() -> !BANK_AREA.contains(Players.getLocal()), 5000);
            }
        } else {
            Logger.log("Could not find door to exit.");
        }
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getConfig(281);
    }
}
