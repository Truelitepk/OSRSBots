package tasks.tutorial;

import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;

import antiban.AdvancedAntibanManager;

public class AccountManagementTask extends TutorialIslandAntibanTask {

    // NPC name
    private static final String ACCOUNT_GUIDE_NAME = "Account Guide";

    // Areas
    private static final Area ACCOUNT_MANAGEMENT_AREA = new Area(3125, 3125, 3130, 3130, 0);

    // Exit objects
    private static final String LADDER_NAME = "Ladder";

    private final AdvancedAntibanManager antibanManager;

    public AccountManagementTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }

    @Override
    public boolean canExecute() {
        return getProgress() >= 550 && getProgress() <= 610;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
            antibanManager.tick();
        }

        // Add task logic here

        if (antibanManager != null) {
            return antibanManager.sleepShort();
        }
        return 600;
    }

    @Override
    public String getTaskName() {
        return "Account Management";
    }

    private boolean handleTutorialDialogue() {
        // Check for tutorial dialogue widget (always present during tutorial)
        // TODO: Widget handling needs update for current DreamBot API
        // Widget widget = Widgets.getWidget(263);
        // WidgetChild tutorialWidget = widget != null ? widget.getChild(1) : null;
        // if (tutorialWidget != null && tutorialWidget.isVisible()) {
        //     String text = tutorialWidget.getText();
        //     if (text != null) {
        //         Logger.log("Tutorial dialogue: " + text);
        //         
        //         // Handle different tutorial prompts
        //         if (text.contains("click here to continue")) {
        //             tutorialWidget.interact();
        //             Sleep.sleep(300, 600);
        //             return true;
        //         }
        //         
        //         if (text.contains("talk to the Account Guide")) {
        //             talkToAccountGuide();
        //             return true;
        //         }
        //         
        //         if (text.contains("open your account management tab")) {
        //             openAccountManagementTab();
        //             return true;
        //         }
        //         
        //         if (text.contains("climb down the ladder")) {
        //             exitTutorialIsland();
        //             return true;
        //         }
        //     }
        // }
        return false;
    }

    @Override
    protected void handleDialogue() {
        if (Dialogues.canContinue()) {
            Dialogues.continueDialogue();
            Sleep.sleep(600, 900);
        } else if (Dialogues.getOptions() != null && Dialogues.getOptions().length > 0) {
            // Select first option for tutorial simplicity
            Dialogues.chooseOption(1);
            Sleep.sleep(600, 900);
        }
    }

    private void talkToAccountGuide() {
        Logger.log("Talking to Account Guide.");
        NPC guide = NPCs.closest(ACCOUNT_GUIDE_NAME);
        if (guide != null && guide.canReach()) {
            if (guide.interact("Talk-to")) {
                Sleep.sleepUntil(Dialogues::inDialogue, 3000);
            }
        } else {
            Logger.log("Could not find Account Guide.");
        }
    }

    private void openAccountManagementTab() {
        Logger.log("Opening account management tab.");
        if (!Tabs.isOpen(Tab.OPTIONS)) {
            Tabs.open(Tab.OPTIONS);
            Sleep.sleep(600, 900);
        }
    }

    private void manageAccountSettings() {
        // Implementation needed
    }

    private void completeAccountManagement() {
        // Implementation needed
    }

    private void exitTutorialIsland() {
        Logger.log("Exiting Tutorial Island via ladder.");
        
        GameObject ladder = GameObjects.closest(obj -> 
            obj.getName().equalsIgnoreCase(LADDER_NAME) && obj.hasAction("Climb-down"));
        
        if (ladder != null) {
            if (ladder.interact("Climb-down")) {
                Sleep.sleepUntil(() -> getProgress() > 630, 5000);
            }
        } else {
            Logger.log("Could not find ladder to exit Tutorial Island.");
        }
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getBitValue(281);
    }
}
