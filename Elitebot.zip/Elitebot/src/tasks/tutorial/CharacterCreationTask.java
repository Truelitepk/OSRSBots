package tasks.tutorial;

import antiban.AdvancedAntibanManager;
import framework.Task;
import namegen.VeteranNameGenerator;
import org.dreambot.api.input.Keyboard;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.MethodProvider;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.wrappers.widgets.WidgetChild;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.methods.settings.PlayerSettings;

import java.util.Random;

/**
 * Advanced Character Creation Task for Tutorial Island
 * Handles sophisticated character creation with personality-based name generation
 * and gender-specific customization
 * 
 * Varbit range: 0-1
 * Features:
 * - Personality-driven name generation
 * - Gender-specific name pools
 * - Advanced character appearance randomization
 * - Intelligent dialogue handling
 * - Name validation and retry logic
 */
public class CharacterCreationTask extends Task {

    // Widget IDs for character creation interface
    private static final int CHARACTER_DESIGN_WIDGET_ID = 269;
    private static final int NAME_SELECTION_WIDGET_ID = 558;
    private static final int TUTORIAL_DIALOGUE_WIDGET = 263;

    // Character design components
    private static final int GENDER_MALE_BUTTON = 143;
    private static final int GENDER_FEMALE_BUTTON = 144;
    private static final int RANDOMIZE_BUTTON_START = 108;
    private static final int RANDOMIZE_BUTTON_STRIDE = 6;
    private static final int ACCEPT_DESIGN_BUTTON = 107;

    // Name selection components
    private static final int NAME_INPUT_FIELD = 7;
    private static final int SET_NAME_BUTTON = 13;
    private static final int NAME_TAKEN_MESSAGE = 17;

    // Character customization categories
    private static final int[] APPEARANCE_CATEGORIES = {
        0,  // Hair style
        1,  // Hair color
        2,  // Face style
        3,  // Body style
        4,  // Top style
        5,  // Arm style
        6,  // Wrist style
        7,  // Leg style
        8,  // Feet style
        9   // Skin color
    };

    private final Random random = new Random();
    private VeteranNameGenerator.Gender selectedGender = VeteranNameGenerator.Gender.MALE;
    private String generatedName;
    private int nameAttempts = 0;
    private static final int MAX_NAME_ATTEMPTS = 8;
    private boolean characterDesigned = false;
    private int designStep = 0;

    // Personality-based name generation weights
    private static final double[] PERSONALITY_WEIGHTS = {
        0.15, // EFFICIENT
        0.12, // CHILL
        0.10, // VETERAN
        0.12, // CASUAL
        0.10, // SKILLER
        0.10, // PVMER
        0.08, // PKER
        0.08, // IRONMAN
        0.15  // NEWBIE
    };

    private final AdvancedAntibanManager antibanManager;

    public CharacterCreationTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }

    @Override
    public boolean canExecute() {
        return getProgress() >= 0 && getProgress() <= 1;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
        antibanManager.tick();
        }

        // Handle different states of character creation
        if (Dialogues.inDialogue() || isWidgetVisible(TUTORIAL_DIALOGUE_WIDGET)) {
            handleDialogue();
        } else if (isWidgetVisible(CHARACTER_DESIGN_WIDGET_ID)) {
            handleCharacterDesign();
        } else if (isWidgetVisible(NAME_SELECTION_WIDGET_ID)) {
            handleNameSelection();
        } else {
            Logger.log("Character creation: Waiting for interface to appear...");
            antibanManager.sleep(1000, 2000);
        }
        
        return antibanManager != null ? antibanManager.sleepShort() : 600;
    }
    
    @Override
    public String getTaskName() {
        return "Character Creation";
    }

    @Override
    public int getPriority() {
        return 1;
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getBitValue(281);
    }

    @Override
    protected void handleDialogue() {
        // More robust dialogue handling to prevent StackOverflowError
        if (Dialogues.isProcessing()) {
            antibanManager.sleep(200, 400); // Wait if dialogue is already being handled
            return;
        }

        if (Dialogues.canContinue()) {
            Logger.log("Continuing dialogue...");
            if (Dialogues.continueDialogue()) {
                antibanManager.sleep(600, 900);
            }
        } else if (Dialogues.getOptions() != null && Dialogues.getOptions().length > 0) {
            Logger.log("Choosing dialogue option...");
            // Choose option based on personality
            int choice = getPersonalityBasedChoice(Dialogues.getOptions().length);
            if (Dialogues.chooseOption(choice)) {
                antibanManager.sleep(800, 1200);
            }
        } else {
            // This case might be hit if a dialogue box is open but has no options or continue button
            // We'll add a small sleep to prevent a tight loop if the state is unusual
            antibanManager.sleep(300, 500);
        }
    }

    private int getPersonalityBasedChoice(int numOptions) {
        String personality = getPersonalityFromAntiban();
        
        // Personality-based dialogue choices
        switch (personality) {
            case "EFFICIENT":
                return 1; // Usually the most direct option
            case "CHILL":
                return numOptions > 1 ? 2 : 1; // Often the more relaxed option
            case "VETERAN":
                return 1; // Experienced players usually pick the standard option
            case "CASUAL":
                return random.nextInt(numOptions) + 1; // Random choice
            case "SKILLER":
                return 1; // Focus on efficiency
            case "PVMER":
                return 1; // Standard choice
            case "PKER":
                return 1; // Aggressive but standard
            case "IRONMAN":
                return 1; // Self-sufficient choice
            case "NEWBIE":
                return 1; // Safe default
            default:
                return 1;
        }
    }

    private boolean isWidgetVisible(int widgetId) {
        // TODO: Widget handling needs update for current DreamBot API
        // Widget widget = Widgets.getWidget(widgetId);
        return false;
    }

    private void clickWidgetChild(int parentId, int childId) {
        // TODO: Widget handling needs update for current DreamBot API
        // Widget widget = Widgets.getWidget(parentId);
        // Widget child = widget.getChild(childId);
        // if (child != null && child.isVisible()) {
        //     child.interact();
        //     antibanManager.sleep(200, 400);
        // }
    }

    private void handleCharacterDesign() {
        if (!characterDesigned) {
            Logger.log("Starting character design process...");
            selectGender();
            antibanManager.sleep(800, 1200);
            
            customizeAppearance();
            antibanManager.sleep(1000, 1500);
            
            acceptDesign();
            characterDesigned = true;
        }
    }

    private void selectGender() {
        Logger.log("Selecting character gender...");
        
        // Personality-based gender selection
        String personality = getPersonalityFromAntiban();
        boolean chooseMale = true;
        
        switch (personality) {
            case "EFFICIENT":
                chooseMale = random.nextDouble() < 0.7; // Slight male preference
                break;
            case "CHILL":
                chooseMale = random.nextDouble() < 0.5; // Equal preference
                break;
            case "VETERAN":
                chooseMale = random.nextDouble() < 0.8; // Strong male preference
                break;
            case "CASUAL":
                chooseMale = random.nextDouble() < 0.6; // Slight male preference
                break;
            case "SKILLER":
                chooseMale = random.nextDouble() < 0.65; // Moderate male preference
                break;
            case "PVMER":
                chooseMale = random.nextDouble() < 0.75; // Strong male preference
                break;
            case "PKER":
                chooseMale = random.nextDouble() < 0.9; // Very strong male preference
                break;
            case "IRONMAN":
                chooseMale = random.nextDouble() < 0.7; // Moderate male preference
                break;
            case "NEWBIE":
                chooseMale = random.nextDouble() < 0.5; // Equal preference
                break;
        }
        
        if (chooseMale) {
            clickWidgetChild(CHARACTER_DESIGN_WIDGET_ID, GENDER_MALE_BUTTON);
            selectedGender = VeteranNameGenerator.Gender.MALE;
            Logger.log("Selected male character");
        } else {
            clickWidgetChild(CHARACTER_DESIGN_WIDGET_ID, GENDER_FEMALE_BUTTON);
            selectedGender = VeteranNameGenerator.Gender.FEMALE;
            Logger.log("Selected female character");
        }
    }

    private void customizeAppearance() {
        Logger.log("Customizing character appearance...");
        
        String personality = getPersonalityFromAntiban();
        
        for (int category : APPEARANCE_CATEGORIES) {
            int randomizations = getPersonalityBasedRandomizations(personality);
            
            for (int i = 0; i < randomizations; i++) {
                int buttonId = RANDOMIZE_BUTTON_START + (category * RANDOMIZE_BUTTON_STRIDE);
                clickWidgetChild(CHARACTER_DESIGN_WIDGET_ID, buttonId);
                antibanManager.sleep(150, 300);
            }
            
            // Add some variation between categories
            antibanManager.sleep(200, 400);
        }
    }

    private int getPersonalityBasedRandomizations(String personality) {
        switch (personality) {
            case "EFFICIENT":
                return 1 + random.nextInt(2); // Minimal customization
            case "CHILL":
                return 2 + random.nextInt(3); // Moderate customization
            case "VETERAN":
                return 1 + random.nextInt(2); // Efficient but some variety
            case "CASUAL":
                return 2 + random.nextInt(4); // More experimentation
            case "SKILLER":
                return 1 + random.nextInt(3); // Some customization
            case "PVMER":
                return 1 + random.nextInt(2); // Standard approach
            case "PKER":
                return 1 + random.nextInt(2); // Quick setup
            case "IRONMAN":
                return 2 + random.nextInt(3); // Personal touch
            case "NEWBIE":
                return 1 + random.nextInt(3); // Some experimentation
            default:
                return 2 + random.nextInt(2);
        }
    }

    private void acceptDesign() {
        Logger.log("Accepting character design...");
        clickWidgetChild(CHARACTER_DESIGN_WIDGET_ID, ACCEPT_DESIGN_BUTTON);
        antibanManager.sleep(1000, 2000);
    }

    private void handleNameSelection() {
        Logger.log("Handling name selection. Attempt: " + (nameAttempts + 1));
        
        // Check if name is taken
        // TODO: Widget handling needs update for current DreamBot API
        // Widget nameTakenWidget = Widgets.getWidget(NAME_SELECTION_WIDGET_ID);
        if (isWidgetVisible(NAME_SELECTION_WIDGET_ID)) {
            handleNameSelection();
        } else {
            Logger.log("Name is taken, generating new name.");
            nameAttempts++;
            generatedName = null;
            antibanManager.sleep(1000, 2000);
            return;
        }
            
        if (generatedName == null) {
            if (nameAttempts >= MAX_NAME_ATTEMPTS) {
                Logger.log("Max name attempts reached, using fallback name.");
                generatedName = generateFallbackName();
            } else {
                generatedName = generatePersonalityBasedName();
            }
            Logger.log("Generated name: " + generatedName);
            enterName(generatedName);
        } else {
            clickWidgetChild(NAME_SELECTION_WIDGET_ID, SET_NAME_BUTTON);
            antibanManager.sleep(1000, 2000);
        }
    }
    
    private void enterName(String name) {
        // TODO: Widget handling needs update for current DreamBot API
        // Widget nameInputWidget = Widgets.getWidget(NAME_SELECTION_WIDGET_ID);
        if (isWidgetVisible(NAME_SELECTION_WIDGET_ID)) {
            WidgetChild nameInput = null; // Assuming nameInputWidget.getChild(NAME_INPUT_FIELD);
            if (nameInput != null && nameInput.isVisible()) {
                nameInput.interact();
                antibanManager.sleep(500, 1000);
                
                // Clear existing text first
                Keyboard.type("", true);
                antibanManager.sleep(200, 400);
                
                // Type the new name
                Keyboard.type(name, true);
                antibanManager.sleep(1000, 2000);
            }
        }
    }
    
    private String generatePersonalityBasedName() {
        String personalityType = getPersonalityFromAntiban();
        Logger.log("Generating name for personality type: " + personalityType + " and gender: " + selectedGender);
        
        // Use the VeteranNameGenerator with personality and gender
        String generatedName = VeteranNameGenerator.generateFromPersonality(personalityType, selectedGender);
        
        // Add some personality-specific modifications
        return applyPersonalityModifications(generatedName, personalityType);
    }

    private String applyPersonalityModifications(String baseName, String personality) {
        switch (personality) {
            case "EFFICIENT":
                // Keep it simple and clean
                return baseName.length() > 12 ? baseName.substring(0, 12) : baseName;
            case "CHILL":
                // Add some casual elements
                if (random.nextDouble() < 0.3) {
                    return baseName + random.nextInt(100);
                }
                return baseName;
            case "VETERAN":
                // Add some veteran-style elements
                if (random.nextDouble() < 0.2) {
                    return baseName + "_" + (2000 + random.nextInt(24));
                }
                return baseName;
            case "CASUAL":
                // More casual modifications
                if (random.nextDouble() < 0.4) {
                    return baseName.toLowerCase();
                }
                return baseName;
            case "SKILLER":
                // Skill-focused names
                if (random.nextDouble() < 0.25) {
                    return baseName + "Skill";
                }
                return baseName;
            case "PVMER":
                // PvM focused names
                if (random.nextDouble() < 0.25) {
                    return baseName + "PvM";
                }
                return baseName;
            case "PKER":
                // PvP focused names
                if (random.nextDouble() < 0.3) {
                    return baseName + "PK";
                }
                return baseName;
            case "IRONMAN":
                // Ironman specific names
                if (random.nextDouble() < 0.3) {
                    return "Iron" + baseName;
                }
                return baseName;
            case "NEWBIE":
                // Newbie friendly names
                if (random.nextDouble() < 0.2) {
                    return baseName + "Noob";
                }
                return baseName;
            default:
                return baseName;
        }
    }

    private String generateFallbackName() {
        String[] fallbackPrefixes = {"Player", "User", "Gamer", "Rune", "Scape"};
        String[] fallbackSuffixes = {"", "123", "2024", "RS", "OSRS"};
        
        String prefix = fallbackPrefixes[random.nextInt(fallbackPrefixes.length)];
        String suffix = fallbackSuffixes[random.nextInt(fallbackSuffixes.length)];
        int number = random.nextInt(9999);
        
        return prefix + number + suffix;
    }

    private String getPersonalityFromAntiban() {
        try {
            if (antibanManager != null && antibanManager.getProfile() != null) {
                return antibanManager.getProfile().getCurrentPersonality();
            }
        } catch (Exception e) {
            Logger.log("Could not determine personality from profile, using weighted random: " + e.getMessage());
        }
        
        // Weighted personality selection based on our weights
        double rand = Math.random();
        double cumulative = 0.0;
        
        String[] personalities = {
            "EFFICIENT", "CHILL", "VETERAN", "CASUAL", 
            "SKILLER", "PVMER", "PKER", "IRONMAN", "NEWBIE"
        };
        
        for (int i = 0; i < personalities.length; i++) {
            cumulative += PERSONALITY_WEIGHTS[i];
            if (rand < cumulative) {
                return personalities[i];
            }
        }
        
        return "CASUAL"; // Fallback
    }
} 