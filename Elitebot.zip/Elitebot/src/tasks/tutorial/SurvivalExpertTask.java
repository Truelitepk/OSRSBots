package tasks.tutorial;

import antiban.UUIDProfileCache;
import org.dreambot.api.input.Keyboard;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.items.Item;
// import org.dreambot.api.wrappers.widgets.Widget;
// import org.dreambot.api.wrappers.widgets.WidgetChild;
import java.awt.event.KeyEvent;

import antiban.AdvancedAntibanManager;

public class SurvivalExpertTask extends TutorialIslandAntibanTask {

    // Item constants
    private static final String FISHING_NET = "Small fishing net";
    private static final String RAW_SHRIMPS = "Raw shrimps";
    private static final String SHRIMPS = "Shrimps";
    private static final String BRONZE_AXE = "Bronze axe";
    private static final String TINDERBOX = "Tinderbox";
    private static final String LOGS = "Logs";

    // NPC and object names
    private static final String SURVIVAL_EXPERT_NAME = "Survival Expert";
    private static final String GATE_NAME = "Gate";

    // Survival area bounds
    private static final Area SURVIVAL_AREA = new Area(
        new Tile(3097, 3090, 0),
        new Tile(3108, 3105, 0)
    );

    // Progress tracking
    private boolean hasTalkedToExpert = false;
    private boolean hasOpenedInventory = false;
    private boolean hasFished = false;
    private boolean hasOpenedSkills = false;
    private boolean hasChoppedTree = false;
    private boolean hasLitFire = false;
    private boolean hasCookedShrimp = false;
    private boolean hasExitedArea = false;

    // Dialogue stuck detection
    private int dialogueStuckCounter = 0;
    private static final int DIALOGUE_STUCK_THRESHOLD = 5;

    // Track if we've handled the "open skills tab" step after catching shrimp
    private boolean hasOpenedSkillsTabAfterShrimp = false;
    private boolean hasReturnedToInventoryAfterShrimp = false;

    // Track if we already opened the gate and walked out
    private boolean hasUsedGateAfterShrimp = false;

    // NEW: Explicit completion tracking
    private boolean completed = false;

    private final AdvancedAntibanManager antibanManager;

    public SurvivalExpertTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }

    @Override
    public boolean canExecute() {
        return getProgress() >= 10 && getProgress() <= 120;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
            antibanManager.tick();
        }

        // Add task logic here

        if (antibanManager != null) {
            return antibanManager.sleepShort();
        }
        return 600;
    }

    @Override
    public String getTaskName() {
        return "Survival Expert";
    }

    private boolean handleTutorialDialogue() {
        // Check for tutorial dialogue widget (always present during tutorial)
        // Widget widget = Widgets.getWidget(263);
        // WidgetChild tutorialWidget = widget != null ? widget.getChild(1) : null;
        // if (tutorialWidget != null && tutorialWidget.isVisible()) {
        //     String text = tutorialWidget.getText();
        //     if (text != null) {
        //         Logger.log("Tutorial dialogue: " + text);
        //         
        //         // Handle different tutorial prompts
        //         if (text.contains("click here to continue")) {
        //             tutorialWidget.interact();
        //             Sleep.sleep(300, 600);
        //             return true;
        //         }
        //         
        //         if (text.contains("open your inventory")) {
        //             if (!Tabs.isOpen(Tab.INVENTORY)) {
        //                 Tabs.open(Tab.INVENTORY);
        //                 Sleep.sleep(600, 900);
        //             }
        //             return true;
        //         }
        //         
        //         if (text.contains("open your skills tab")) {
        //             if (!Tabs.isOpen(Tab.SKILLS)) {
        //                 Tabs.open(Tab.SKILLS);
        //                 Sleep.sleep(600, 900);
        //             }
        //             return true;
        //         }
        //         
        //         if (text.contains("use your fishing net on the fishing spot")) {
        //             fishAtSpot();
        //             return true;
        //         }
        //         
        //         if (text.contains("chop down the tree")) {
        //             chopTree();
        //             return true;
        //         }
        //         
        //         if (text.contains("use your tinderbox on the logs")) {
        //             lightFire();
        //             return true;
        //         }
        //         
        //         if (text.contains("cook the raw shrimps on the fire")) {
        //             cookShrimp();
        //             return true;
        //         }
        //         
        //         if (text.contains("click on the gate")) {
        //             exitSurvivalArea();
        //             return true;
        //         }
        //     }
        // }
        return false;
    }

    @Override
    protected void handleDialogue() {
        if (Dialogues.canContinue()) {
            Dialogues.continueDialogue();
            Sleep.sleep(600, 900);
        } else if (Dialogues.getOptions() != null && Dialogues.getOptions().length > 0) {
            // Select first option for tutorial simplicity
            Dialogues.chooseOption(1);
            Sleep.sleep(600, 900);
        }
    }

    private void talkToSurvivalExpert() {
        Logger.log("Talking to Survival Expert.");
        NPC expert = NPCs.closest(SURVIVAL_EXPERT_NAME);
        if (expert != null && expert.canReach()) {
            if (expert.interact("Talk-to")) {
                Sleep.sleepUntil(Dialogues::inDialogue, 3000);
            }
        } else {
            Logger.log("Could not find Survival Expert.");
        }
    }

    private void openInventoryTab() {
        Logger.log("Opening inventory tab.");
        if (!Tabs.isOpen(Tab.INVENTORY)) {
            Tabs.open(Tab.INVENTORY);
            Sleep.sleep(600, 900);
        }
    }

    private void fishAtSpot() {
        Logger.log("Fishing at fishing spot.");
        
        // First, get fishing net if we don't have it
        if (!Inventory.contains(FISHING_NET)) {
            // Look for net on ground
            GameObject groundNet = GameObjects.closest(obj -> 
                obj.getName().equals(FISHING_NET) && obj.hasAction("Take"));
            if (groundNet != null) {
                groundNet.interact("Take");
                Sleep.sleepUntil(() -> Inventory.contains(FISHING_NET), 3000);
                return;
            }
            
            // If no net on ground, talk to expert to get it
            talkToSurvivalExpert();
            return;
        }

        // Find fishing spot and fish
        NPC fishingSpot = NPCs.closest(npc ->
            npc != null &&
            npc.getName() != null &&
            npc.getName().toLowerCase().contains("fishing spot") &&
            npc.hasAction("Net")
        );
        
        if (fishingSpot != null) {
            if (fishingSpot.interact("Net")) {
                Sleep.sleepUntil(() -> Inventory.contains(RAW_SHRIMPS), 8000);
            }
        } else {
            Logger.log("Could not find fishing spot.");
        }
    }

    private void openSkillsTab() {
        Logger.log("Opening skills tab.");
        if (!Tabs.isOpen(Tab.SKILLS)) {
            Tabs.open(Tab.SKILLS);
            Sleep.sleep(600, 900);
        }
    }

    private void talkToSurvivalExpertAfterSkills() {
        Logger.log("Talking to Survival Expert after opening skills tab.");
        talkToSurvivalExpert();
    }

    private void chopTree() {
        Logger.log("Chopping tree for logs.");
        
        // Get axe if we don't have it
        if (!Inventory.contains(BRONZE_AXE)) {
            GameObject groundAxe = GameObjects.closest(obj -> 
                obj.getName().equals(BRONZE_AXE) && obj.hasAction("Take"));
            if (groundAxe != null) {
                groundAxe.interact("Take");
                Sleep.sleepUntil(() -> Inventory.contains(BRONZE_AXE), 3000);
                return;
            }
        }
        
        // Get tinderbox if we don't have it
        if (!Inventory.contains(TINDERBOX)) {
            GameObject groundTinder = GameObjects.closest(obj -> 
                obj.getName().equals(TINDERBOX) && obj.hasAction("Take"));
            if (groundTinder != null) {
                groundTinder.interact("Take");
                Sleep.sleepUntil(() -> Inventory.contains(TINDERBOX), 3000);
                return;
            }
        }

        // Chop tree
        GameObject tree = GameObjects.closest(obj -> 
            obj.hasAction("Chop down") && obj.getName().equals("Tree"));
        if (tree != null) {
            if (tree.interact("Chop down")) {
                Sleep.sleepUntil(() -> Inventory.contains(LOGS), 6000);
            }
        } else {
            Logger.log("Could not find tree to chop.");
        }
    }

    private void lightFire() {
        Logger.log("Lighting fire with logs and tinderbox.");
        
        if (!Inventory.contains(LOGS)) {
            Logger.log("No logs available for fire.");
            return;
        }
        
        if (!Inventory.contains(TINDERBOX)) {
            Logger.log("No tinderbox available for fire.");
            return;
        }

        Item tinderbox = Inventory.get(TINDERBOX);
        Item logs = Inventory.get(LOGS);
        
        if (tinderbox != null && logs != null) {
            tinderbox.useOn(logs);
            Sleep.sleepUntil(() -> findNearbyFire() != null, 5000);
        }
    }

    private void cookShrimp() {
        Logger.log("Cooking shrimp on fire.");
        
        if (!Inventory.contains(RAW_SHRIMPS)) {
            Logger.log("No raw shrimps to cook.");
            return;
        }

        GameObject fire = findNearbyFire();
        if (fire == null) {
            Logger.log("No fire available for cooking.");
            return;
        }

        Item shrimps = Inventory.get(RAW_SHRIMPS);
        if (shrimps != null) {
            shrimps.useOn(fire);
            Sleep.sleepUntil(() -> Inventory.contains(SHRIMPS), 7000);
        }
    }

    private void exitSurvivalArea() {
        Logger.log("Exiting survival area through gate.");
        GameObject gate = GameObjects.closest(obj -> 
            obj.hasAction("Open") && obj.getName().equalsIgnoreCase(GATE_NAME));
        
        if (gate != null) {
            if (gate.interact("Open")) {
                Sleep.sleepUntil(() -> getProgress() > 120, 5000);
            }
        } else {
            Logger.log("Could not find gate to exit.");
        }
    }

    private GameObject findNearbyFire() {
        return GameObjects.closest(obj -> obj.getName().equals("Fire"));
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getConfig(281);
    }
}