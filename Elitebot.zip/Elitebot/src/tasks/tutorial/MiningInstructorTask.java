package tasks.tutorial;

import antiban.AdvancedAntibanManager;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.methods.widget.helpers.Smithing;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;

public class MiningInstructorTask extends TutorialIslandAntibanTask {

    // Object IDs
    private static final int COPPER_ROCK_ID = 10079;
    private static final int TIN_ROCK_ID = 10080;
    private static final int FURNACE_ID = 9739;
    private static final int ANVIL_ID = 9722;

    // Item names
    private static final String BRONZE_PICKAXE = "Bronze pickaxe";
    private static final String TIN_ORE = "Tin ore";
    private static final String COPPER_ORE = "Copper ore";
    private static final String BRONZE_BAR = "Bronze bar";
    private static final String BRONZE_DAGGER = "Bronze dagger";

    // NPC name
    private static final String MINING_INSTRUCTOR_NAME = "Mining Instructor";

    // Exit gate
    private static final String EXIT_GATE_NAME = "Gate";

    private final AdvancedAntibanManager antibanManager;

    public MiningInstructorTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }

    @Override
    public boolean canExecute() {
        return getProgress() >= 370 && getProgress() <= 500;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
            antibanManager.tick();
        }

        // Add task logic here

        if (antibanManager != null) {
            return antibanManager.sleepShort();
        }
        return 600;
    }

    @Override
    public String getTaskName() {
        return "Mining Instructor";
    }

    private boolean handleTutorialDialogue() {
        // Check for tutorial dialogue widget (always present during tutorial)
        // TODO: Widget handling needs update for current DreamBot API
        // Widget widget = Widgets.getWidget(263);
        // WidgetChild tutorialWidget = widget != null ? widget.getChild(1) : null;
        // if (tutorialWidget != null && tutorialWidget.isVisible()) {
        //     String text = tutorialWidget.getText();
        //     if (text != null) {
        //         Logger.log("Tutorial dialogue: " + text);
        //         
        //         // Handle different tutorial prompts
        //         if (text.contains("click here to continue")) {
        //             tutorialWidget.interact();
        //             Sleep.sleep(300, 600);
        //             return true;
        //         }
        //         
        //         if (text.contains("talk to the Mining Instructor")) {
        //             talkToMiningInstructor();
        //             return true;
        //         }
        //         
        //         if (text.contains("mine the tin rock")) {
        //             mineTin();
        //             return true;
        //         }
        //         
        //         if (text.contains("mine the copper rock")) {
        //             mineCopper();
        //             return true;
        //         }
        //         
        //         if (text.contains("use the furnace")) {
        //             smeltBronzeBar();
        //             return true;
        //         }
        //         
        //         if (text.contains("use the anvil")) {
        //             smithBronzeDagger();
        //             return true;
        //         }
        //         
        //         if (text.contains("go through the gate")) {
        //             exitMiningArea();
        //             return true;
        //         }
        //     }
        // }
        return false;
    }

    @Override
    protected void handleDialogue() {
        if (Dialogues.canContinue()) {
            Dialogues.continueDialogue();
            Sleep.sleep(600, 900);
        } else if (Dialogues.getOptions() != null && Dialogues.getOptions().length > 0) {
            // Select first option for tutorial simplicity
            Dialogues.chooseOption(1);
            Sleep.sleep(600, 900);
        }
    }

    private void talkToMiningInstructor() {
        Logger.log("Talking to Mining Instructor.");
        NPC instructor = NPCs.closest(MINING_INSTRUCTOR_NAME);
        if (instructor != null && instructor.canReach()) {
            if (instructor.interact("Talk-to")) {
                Sleep.sleepUntil(Dialogues::inDialogue, 3000);
            }
        } else {
            Logger.log("Could not find Mining Instructor.");
        }
    }

    private void mineTin() {
        Logger.log("Mining tin ore.");
        
        // Get bronze pickaxe if we don't have it
        if (!Inventory.contains(BRONZE_PICKAXE)) {
            Logger.log("No bronze pickaxe available for mining.");
            return;
        }

        // Mine tin rock
        GameObject tinRock = GameObjects.closest(obj -> 
            obj.getID() == TIN_ROCK_ID && obj.hasAction("Mine"));
        
        if (tinRock != null) {
            if (tinRock.interact("Mine")) {
                Sleep.sleepUntil(() -> Inventory.contains(TIN_ORE), 8000);
            }
        } else {
            Logger.log("Could not find tin rock.");
        }
    }

    private void mineCopper() {
        Logger.log("Mining copper ore.");
        
        // Get bronze pickaxe if we don't have it
        if (!Inventory.contains(BRONZE_PICKAXE)) {
            Logger.log("No bronze pickaxe available for mining.");
            return;
        }

        // Mine copper rock
        GameObject copperRock = GameObjects.closest(obj -> 
            obj.getID() == COPPER_ROCK_ID && obj.hasAction("Mine"));
        
        if (copperRock != null) {
            if (copperRock.interact("Mine")) {
                Sleep.sleepUntil(() -> Inventory.contains(COPPER_ORE), 8000);
            }
        } else {
            Logger.log("Could not find copper rock.");
        }
    }

    private void smeltBronzeBar() {
        Logger.log("Smelting bronze bar.");
        
        if (!Inventory.contains(TIN_ORE) || !Inventory.contains(COPPER_ORE)) {
            Logger.log("Need both tin and copper ore to smelt bronze bar.");
            return;
        }

        // Use furnace
        GameObject furnace = GameObjects.closest(obj -> 
            obj.getID() == FURNACE_ID && obj.hasAction("Use"));
        
        if (furnace != null) {
            if (furnace.interact("Use")) {
                Sleep.sleepUntil(() -> Inventory.contains(BRONZE_BAR), 8000);
            }
        } else {
            Logger.log("Could not find furnace.");
        }
    }

    private void talkToMiningInstructorAfterSmelting() {
        Logger.log("Talking to Mining Instructor after smelting.");
        talkToMiningInstructor();
    }

    private void smithBronzeDagger() {
        Logger.log("Smithing bronze dagger.");
        
        if (!Inventory.contains(BRONZE_BAR)) {
            Logger.log("No bronze bar available for smithing.");
            return;
        }

        // Use anvil
        GameObject anvil = GameObjects.closest(obj -> 
            obj.getID() == ANVIL_ID && obj.hasAction("Smith"));
        
        if (anvil != null) {
            if (anvil.interact("Smith")) {
                Sleep.sleepUntil(Smithing::isOpen, 3000);
                
                // Find and click bronze dagger in smithing interface
                // TODO: Widget handling needs update for current DreamBot API
                // if (Smithing.isOpen()) {
                //     boolean clicked = false;
                //     for (int child = 0; child < 30; child++) {
                //         WidgetChild widgetChild = Widgets.get(312, child);
                //         if (widgetChild != null && widgetChild.isVisible()) {
                //             String text = widgetChild.getText();
                //             if (text != null && text.toLowerCase().contains("dagger")) {
                //                 widgetChild.interact();
                //                 clicked = true;
                //                 break;
                //             }
                //         }
                //     }
                //     if (!clicked) {
                //         Logger.log("Could not find bronze dagger in smithing interface.");
                //     }
                //     Sleep.sleepUntil(() -> Inventory.contains(BRONZE_DAGGER), 8000);
                // }
            }
        } else {
            Logger.log("Could not find anvil.");
        }
    }

    private void exitMiningArea() {
        Logger.log("Exiting mining area through gate.");
        
        GameObject gate = GameObjects.closest(obj -> 
            obj.getName().equalsIgnoreCase(EXIT_GATE_NAME) && obj.hasAction("Open"));
        
        if (gate != null) {
            if (gate.interact("Open")) {
                Sleep.sleepUntil(() -> getProgress() > 360, 5000);
            }
        } else {
            Logger.log("Could not find exit gate.");
        }
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getConfig(281);
    }
} 