package tasks.tutorial;

import antiban.AdvancedAntibanManager;
import framework.Task;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.magic.Magic;
import org.dreambot.api.methods.magic.Normal;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.NPC;

public class MagicInstructorTask extends TutorialIslandAntibanTask {

    private static final String MAGIC_INSTRUCTOR_NAME = "Magic Instructor";
    private static final Tile MAGIC_INSTRUCTOR_TILE = new Tile(3135, 3115, 0);
    private static final Area MAGIC_AREA = new Area(3135, 3105, 3142, 3115, 0);
    private static final String TUTOR_NAME = "Magic Instructor";
    private static final String CHICKEN_NAME = "Chicken";

    // Progress tracking
    private boolean talkedToInstructor = false;
    private boolean openedMagicTab = false;
    private boolean castWindStrike = false;
    private boolean completed = false;

    private final AdvancedAntibanManager antibanManager;

    public MagicInstructorTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }

    @Override
    public boolean canExecute() {
        return getProgress() >= 620 && getProgress() <= 670;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
            antibanManager.tick();
        }

        // Add task logic here

        if (antibanManager != null) {
            return antibanManager.sleepShort();
        }
        return 600;
    }

    @Override
    public String getTaskName() {
        return "Magic Instructor";
    }

    private boolean handleTutorialDialogue() {
        // Check for tutorial dialogue widget (always present during tutorial)
        // TODO: Widget handling needs update for current DreamBot API
        // Widget widget = Widgets.getWidget(263);
        // WidgetChild tutorialWidget = widget != null ? widget.getChild(1) : null;
        // if (tutorialWidget != null && tutorialWidget.isVisible()) {
        //     String text = tutorialWidget.getText();
        //     if (text != null) {
        //         Logger.log("Tutorial dialogue: " + text);
        //         
        //         // Handle different tutorial prompts
        //         if (text.contains("click here to continue")) {
        //             tutorialWidget.interact();
        //             Sleep.sleep(300, 600);
        //             return true;
        //         }
        //         
        //         if (text.contains("talk to the Magic Instructor")) {
        //             talkToMagicInstructor();
        //             return true;
        //         }
        //         
        //         if (text.contains("open your magic tab")) {
        //             openMagicTab();
        //             return true;
        //         }
        //         
        //         if (text.contains("cast wind strike on the chicken")) {
        //             castWindStrikeOnChicken();
        //             return true;
        //         }
        //         
        //         if (text.contains("leave the magic area")) {
        //             exitMagicArea();
        //             return true;
        //         }
        //     }
        // }
        return false;
    }

    @Override
    protected void handleDialogue() {
        if (Dialogues.canContinue()) {
            Dialogues.continueDialogue();
            Sleep.sleep(600, 900);
        } else if (Dialogues.getOptions() != null && Dialogues.getOptions().length > 0) {
            // Select first option for tutorial simplicity
            Dialogues.chooseOption(1);
            Sleep.sleep(600, 900);
        }
    }

    private void talkToMagicInstructor() {
        Logger.log("Talking to Magic Instructor.");
        NPC instructor = NPCs.closest(MAGIC_INSTRUCTOR_NAME);
        if (instructor != null && instructor.canReach()) {
            if (instructor.interact("Talk-to")) {
                Sleep.sleepUntil(Dialogues::inDialogue, 3000);
            }
        } else {
            Logger.log("Could not find Magic Instructor.");
        }
    }

    private void openMagicTab() {
        Logger.log("Opening magic tab.");
        if (!Tabs.isOpen(Tab.MAGIC)) {
            Tabs.open(Tab.MAGIC);
            Sleep.sleep(600, 900);
        }
    }

    private void castWindStrikeOnChicken() {
        Logger.log("Casting wind strike on chicken.");
        
        // Find a chicken to cast on
        NPC chicken = NPCs.closest(npc -> 
            npc != null && 
            npc.getName().equalsIgnoreCase(CHICKEN_NAME) && 
            npc.canReach() && 
            !npc.isInCombat());
        
        if (chicken != null) {
            if (Magic.castSpellOn(Normal.WIND_STRIKE, chicken)) {
                Sleep.sleepUntil(() -> chicken.getHealthPercent() == 0 || !chicken.exists(), 10000);
            }
        } else {
            Logger.log("Could not find chicken to cast on.");
        }
    }

    private void waitForChickenToDie() {
        Logger.log("Waiting for chicken to die.");
        // This is handled in the cast method, just wait a bit
        Sleep.sleep(1000, 2000);
    }

    private void talkToMagicInstructorAfterSpell() {
        Logger.log("Talking to Magic Instructor after casting spell.");
        talkToMagicInstructor();
    }

    private void exitMagicArea() {
        Logger.log("Exiting magic area.");
        
        // Check if we're already outside
        if (!MAGIC_AREA.contains(Players.getLocal())) {
            Logger.log("Already outside magic area.");
            return;
        }

        // Walk to exit area
        Walking.walk(MAGIC_AREA.getCenter());
        Sleep.sleepUntil(() -> !MAGIC_AREA.contains(Players.getLocal()), 5000);
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getConfig(281);
    }
}