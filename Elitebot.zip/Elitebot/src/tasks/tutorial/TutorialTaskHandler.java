package tasks.tutorial;

import antiban.AdvancedAntibanManager;
import antiban.AntibanManager;
import antiban.ChatGPTPersonalityEngine;
import antiban.MouseHeatmap;
import antiban.UUIDProfileCache;
import framework.Task;
import org.dreambot.api.methods.MethodProvider;
import org.dreambot.api.methods.input.Camera;
import org.dreambot.api.methods.input.Keyboard;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
// TODO: Widget handling needs update for current DreamBot API
// import org.dreambot.api.methods.widgets.Widget;
// import org.dreambot.api.methods.widgets.WidgetChild;
// Remove all Widget/WidgetChild code blocks
// Remove all Mouse import errors
// Remove all code that uses Widgets.getWidget or Widget/WidgetChild

import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.interactive.Player;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.wrappers.interactive.NPC;

/**
 * Enhanced Tutorial Task Handler with Auto-Save Integration
 * Handles the orchestration and execution of Tutorial Island tasks with progress persistence
 */
public class TutorialTaskHandler {

    private final List<Task> tasks = new ArrayList<>();
    private final AdvancedAntibanManager antibanManager;
    private final ChatGPTPersonalityEngine chatGPT;
    private final Random random = ThreadLocalRandom.current();
    private UUIDProfileCache profileCache;
    private MouseHeatmap mouseHeatmap;

    private int lastExecutedTaskIndex = -1;
    private Task currentTask;
    private boolean initialized = false;

    private long lastProgressSave = 0;
    private static final long PROGRESS_SAVE_INTERVAL = 15000; // 15 seconds
    private static final long ANTI_BAN_INTERVAL = 30000; // 30 seconds
    private long lastAntiBanAction = 0;

    /**
     * Constructs the handler with all required tasks.
     * @param antibanManager The antiban manager to use for all tasks.
     */
    public TutorialTaskHandler(AdvancedAntibanManager antibanManager) {
        if (antibanManager == null) throw new IllegalArgumentException("AntibanManager cannot be null");
        this.antibanManager = antibanManager;
        this.chatGPT = new ChatGPTPersonalityEngine();
        this.mouseHeatmap = new MouseHeatmap();
        // loadTasks(); // Moved to initialize() to ensure profileCache is not null.
    }

    /**
     * Initialize with profile cache and resume from saved progress
     */
    public void initialize(UUIDProfileCache profileCache) {
        this.profileCache = profileCache;
        loadTasks(); // Load tasks now that we have the profile cache.
        this.initialized = true;
        
        // Load saved progress
        int savedProgress = profileCache.getTutorialProgress();
        lastExecutedTaskIndex = Math.min(savedProgress, tasks.size() - 1);
        
        if (savedProgress > 0 && lastExecutedTaskIndex >= 0) {
            Logger.log("[TutorialHandler] Initialized with saved progress: " + savedProgress + 
                ", resuming at task: " + tasks.get(lastExecutedTaskIndex).getTaskName());
        } else {
            Logger.log("[TutorialHandler] No saved progress found, starting from the beginning");
        }
    }

    /**
     * Loads the tutorial tasks in the required order.
     */
    private void loadTasks() {
        if (this.antibanManager == null) {
            Logger.log("[TutorialTaskHandler] AntibanManager is null, cannot load tasks.");
            return;
        }
        
        tasks.add(new CharacterCreationTask(antibanManager));
        tasks.add(new IntroGuideTask(antibanManager));
        tasks.add(new SurvivalExpertTask(antibanManager));
        tasks.add(new CookingInstructorTask(antibanManager));
        tasks.add(new QuestGuideTask(antibanManager));
        tasks.add(new MiningInstructorTask(antibanManager));
        tasks.add(new CombatInstructorTask(antibanManager, profileCache));
        tasks.add(new BankingInstructorTask(antibanManager));
        tasks.add(new AccountManagementTask(antibanManager));
        tasks.add(new PrayerInstructorTask(antibanManager));
        tasks.add(new MagicInstructorTask(antibanManager));
    }

    /**
     * Executes the next available tutorial task with auto-save integration.
     * @return The sleep duration (in ms) after execution.
     */
    public int execute() {
        if (!initialized || profileCache == null) {
            Logger.log("[TutorialHandler] Not initialized properly!");
            return 300;
        }

        antibanManager.tick();
        // performAntiBanActions(); // Disabled this primitive anti-ban system to prevent overly random behavior.
        autoSaveProgress();

        // --- CORE LOGIC REWRITE ---
        // Get the single correct task based on our "reality check" detection.
        int correctTaskIndex = detectCurrentTask();

        // If detection fails, wait.
        if (correctTaskIndex < 0 || correctTaskIndex >= tasks.size()) {
            Logger.log("[TutorialHandler] No valid task detected. Waiting...");
            return 600;
        }

        Task taskToExecute = tasks.get(correctTaskIndex);

        // If we are switching to a new task, log it and save progress.
        if (correctTaskIndex != lastExecutedTaskIndex) {
            Logger.log("[TutorialHandler] Switching to new task: " + taskToExecute.getTaskName() + 
                " (was on: " + (lastExecutedTaskIndex >= 0 ? tasks.get(lastExecutedTaskIndex).getTaskName() : "none") + ")");
            lastExecutedTaskIndex = correctTaskIndex;
            currentTask = taskToExecute;
            saveProgress();
        }
        
        // Execute ONLY the correct task. No more looping.
        return taskToExecute.execute();
    }

    /**
     * Auto-save progress periodically
     */
    private void autoSaveProgress() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastProgressSave > PROGRESS_SAVE_INTERVAL) {
            saveProgress();
            lastProgressSave = currentTime;
        }
    }

    /**
     * Save current progress to profile
     */
    private void saveProgress() {
        if (profileCache != null) {
            profileCache.setTutorialProgress(lastExecutedTaskIndex);
            profileCache.autoSave();
            // Logger.log("[TutorialHandler] Auto-saved progress: " + lastExecutedTaskIndex); // Reduced log spam
        }
    }

    /**
     * Force save progress immediately
     */
    public void forceSaveProgress() {
        if (profileCache != null) {
            profileCache.setTutorialProgress(lastExecutedTaskIndex);
            profileCache.forceSave();
            lastProgressSave = System.currentTimeMillis();
            Logger.log("[TutorialHandler] Force saved progress: " + lastExecutedTaskIndex);
        }
    }

    /**
     * Get current task index
     */
    public int getCurrentTaskIndex() {
        return lastExecutedTaskIndex;
    }

    /**
     * Get current task name
     */
    public String getCurrentTaskName() {
        if (currentTask == null) {
            return "Initializing...";
        }
        
        // Return human-readable task names
        if (currentTask instanceof IntroGuideTask) return "Intro Guide";
        if (currentTask instanceof CharacterCreationTask) return "Character Creation";
        if (currentTask instanceof SurvivalExpertTask) return "Survival Expert";
        if (currentTask instanceof QuestGuideTask) return "Quest Guide";
        if (currentTask instanceof MiningInstructorTask) return "Mining Instructor";
        if (currentTask instanceof CombatInstructorTask) return "Combat Instructor";
        if (currentTask instanceof CookingInstructorTask) return "Cooking Instructor";
        if (currentTask instanceof PrayerInstructorTask) return "Prayer Instructor";
        if (currentTask instanceof MagicInstructorTask) return "Magic Instructor";
        if (currentTask instanceof BankingInstructorTask) return "Banking Instructor";
        if (currentTask instanceof AccountManagementTask) return "Account Management";
        
        return "Unknown Task";
    }

    /**
     * Get total tasks count
     */
    public int getTotalTasks() {
        return tasks.size();
    }

    /**
     * Get progress percentage
     */
    public double getProgressPercentage() {
        return (double) lastExecutedTaskIndex / tasks.size() * 100.0;
    }

    /**
     * Check if tutorial is complete
     */
    public boolean isTutorialComplete() {
        return lastExecutedTaskIndex >= tasks.size();
    }

    /**
     * Get current task object
     */
    public Task getCurrentTask() {
        return currentTask;
    }

    /**
     * Get all tasks
     */
    public List<Task> getAllTasks() {
        return new ArrayList<>(tasks);
    }

    /**
     * Reset progress (for testing or restart)
     */
    public void resetProgress() {
        lastExecutedTaskIndex = -1;
        if (profileCache != null) {
            profileCache.setTutorialProgress(-1);
            profileCache.forceSave();
        }
        Logger.log("[TutorialHandler] Progress reset to 0");
    }

    /**
     * Skip to specific task (for testing)
     */
    public void skipToTask(int taskIndex) {
        if (taskIndex >= -1 && taskIndex < tasks.size()) {
            lastExecutedTaskIndex = taskIndex;
            if (profileCache != null) {
                profileCache.setTutorialProgress(taskIndex);
                profileCache.forceSave();
            }
            Logger.log("[TutorialHandler] Skipped to task: " + taskIndex);
        }
    }

    /**
     * Get detailed progress information
     */
    public ProgressInfo getProgressInfo() {
        return new ProgressInfo(
            lastExecutedTaskIndex,
            getCurrentTaskName(),
            getProgressPercentage(),
            isTutorialComplete(),
            profileCache != null ? profileCache.getStatistics() : null
        );
    }

    /**
     * Progress information class
     */
    public static class ProgressInfo {
        public final int currentTaskIndex;
        public final String currentTaskName;
        public final double progressPercentage;
        public final boolean isComplete;
        public final UUIDProfileCache.ProfileStatistics profileStats;
        
        public ProgressInfo(int taskIndex, String taskName, double percentage, 
                           boolean complete, UUIDProfileCache.ProfileStatistics stats) {
            this.currentTaskIndex = taskIndex;
            this.currentTaskName = taskName;
            this.progressPercentage = percentage;
            this.isComplete = complete;
            this.profileStats = stats;
        }
        
        @Override
        public String toString() {
            return String.format("Task %d/%d (%.1f%%): %s", 
                currentTaskIndex + 1, 11, progressPercentage, currentTaskName);
        }
    }

    // --- Anti-ban methods ---
    private void performAntiBanActions() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastAntiBanAction > ANTI_BAN_INTERVAL) {
            // Random anti-ban actions
            int action = random.nextInt(5);
            switch (action) {
                case 0:
                    // Random camera movement
                    Camera.rotateToEntity(Players.closest(p -> p != Players.getLocal()));
                    break;
                case 1:
                    // Random mouse movement
                    if (antibanManager != null) {
                        Point randomPoint = new Point(random.nextInt(500), random.nextInt(400));
                        org.dreambot.api.input.Mouse.move(randomPoint);
                    }
                    break;
                case 2:
                    // Random keyboard press
                    Keyboard.type(" ");
                    break;
                case 3:
                    // Random tab switch
                    Tab[] tabs = Tab.values();
                    Tabs.open(tabs[random.nextInt(tabs.length)]);
                    break;
                case 4:
                    // Random widget interaction
                    // TODO: Widget handling needs update for current DreamBot API
                    // Widget widget = Widgets.getWidget(548);
                    // WidgetChild closeButton = widget != null ? widget.getChild(10) : null;
                    // if (closeButton != null) {
                    //     closeButton.interact();
                    // }
                    break;
            }
            lastAntiBanAction = currentTime;
        }
    }

    public Point getHeatmapBiasedClick(Rectangle area) {
        return mouseHeatmap.getBiasedClickPoint(area);
    }

    public void recordMouseClick(Point p) {
        mouseHeatmap.recordClick(p);
    }

    public ChatGPTPersonalityEngine getChatGPT() {
        return chatGPT;
    }

    public List<Task> getTasks() {
        return Collections.unmodifiableList(tasks);
    }

    public boolean isComplete() {
        return lastExecutedTaskIndex >= tasks.size();
    }

    public void addTask(Task task) {
        tasks.add(task);
    }

    public void removeTask(Task task) {
        tasks.remove(task);
    }

    private String getTaskStatus(Task task, int taskIndex) {
        String status;
        if (taskIndex < lastExecutedTaskIndex) {
            status = "COMPLETE";
        } else if (taskIndex == lastExecutedTaskIndex) {
            status = "IN PROGRESS";
        } else {
            status = "PENDING";
        }
        
        String taskName = task.getTaskName();
        if (task instanceof CharacterCreationTask) taskName = "Character Creation";
        // This can be expanded for other tasks if needed
        
        return String.format("  - %-25s (%s)", taskName, status);
    }

    private void performRandomAntiBan() {
        // ... (existing code)
        
        // Example of a random action
        if (random.nextInt(100) < 5) {
            switch (random.nextInt(5)) {
                case 0:
                    // Logger.log("[Anti-Ban] Performing random camera movement...");
                    Camera.rotateToYaw(Camera.getYaw() + random.nextInt(40) - 20);
                    break;
                case 1:
                    // Logger.log("[Anti-Ban] Performing random mouse movement...");
                    if (antibanManager != null) {
                        Point randomPoint = new Point(random.nextInt(500), random.nextInt(400));
                        org.dreambot.api.input.Mouse.move(randomPoint);
                    }
                    break;
                case 2:
                    // Logger.log("[Anti-Ban] Examining random player...");
                    Player randomPlayer = Players.closest(p -> p != null && !p.equals(Players.getLocal()));
                    if (randomPlayer != null) {
                        randomPlayer.interact("Examine");
                    }
                    break;
                case 3:
                     // Logger.log("[Anti-Ban] Hovering random skill...");
                     if (Tabs.open(Tab.SKILLS)) {
                         // Logic to hover a random skill
                     }
                     break;
                case 4:
                    // Logger.log("[Anti-Ban] Closing random widget...");
                    // TODO: Widget handling needs update for current DreamBot API
                    // Widget widget = Widgets.getWidget(548);
                    // WidgetChild closeButton = widget != null ? widget.getChild(10) : null;
                    // if (closeButton != null) {
                    //     closeButton.interact();
                    // }
                    break;
            }
        }
    }

    /**
     * Improved task detection using inventory, location, and varbit
     */
    private int detectCurrentTask() {
        int progress = PlayerSettings.getBitValue(281);
        Player player = Players.getLocal();
        if (player == null) return -1; // Cannot detect without player

        // --- Define Areas for each section ---
        Area survivalArea = new Area(3098, 3091, 3110, 3101);
        Area cookingArea = new Area(3072, 3082, 3080, 3090);
        Area questArea = new Area(3082, 3058, 3090, 3065);
        Area miningArea = new Area(3075, 9499, 3090, 9510);
        Area combatArea = new Area(3102, 9505, 3112, 9520);
        Area bankArea = new Area(3120, 3120, 3126, 3125);
        Area accountMgmtArea = new Area(3125, 3125, 3129, 3130);
        Area prayerArea = new Area(3122, 3103, 3129, 3109);
        Area magicArea = new Area(3137, 3085, 3143, 3090);
        
        // --- Reality Check Detection (Location/NPCs first, Varbit second) ---
        // This order is crucial. We check the most advanced tasks first.
        // This prevents false positives, e.g., being in the combat area with a pickaxe.

        if (magicArea.contains(player) || NPCs.closest("Magic Instructor") != null || progress >= 620) {
            return 10;
        }
        if (prayerArea.contains(player) || NPCs.closest("Brother Brace") != null || progress >= 550) {
            return 9;
        }
        if (accountMgmtArea.contains(player) || progress >= 510) {
            return 8;
        }
        if (bankArea.contains(player) || NPCs.closest("Financial Advisor") != null || progress >= 470) {
            return 7;
        }
        if (combatArea.contains(player) || NPCs.closest("Combat Instructor") != null || progress >= 370) {
            return 6;
        }
        if (miningArea.contains(player) || NPCs.closest("Mining Instructor") != null || progress >= 260) {
            return 5;
        }
        if (questArea.contains(player) || NPCs.closest("Quest Guide") != null || progress >= 140) {
            return 4;
        }
        if (cookingArea.contains(player) || NPCs.closest("Master Chef") != null || progress >= 80) {
            return 3;
        }
        if (survivalArea.contains(player) || NPCs.closest("Survival Expert") != null || progress >= 20) {
            return 2;
        }
        
        // Only if we are not in any major area do we trust the low-level varbits.
        if (progress >= 2) {
            return 1;
        }

        // If all other checks fail, it must be character creation.
        return 0;
    }

    /**
     * Fallback method to get task index purely from varbit.
     * Less reliable but better than nothing.
     */
    private int getTaskIndexFromVarbit(int varbit) {
        if (varbit >= 620) return 10; // Magic
        if (varbit >= 550) return 9;  // Prayer
        if (varbit >= 510) return 8;  // Account
        if (varbit >= 470) return 7;  // Banking
        if (varbit >= 370) return 6;  // Combat
        if (varbit >= 260) return 5;  // Mining
        if (varbit >= 140) return 4;  // Quest
        if (varbit >= 80) return 3;   // Cooking
        if (varbit >= 20) return 2;   // Survival
        if (varbit >= 2) return 1;    // Intro
        return 0; // Character Creation
    }
}