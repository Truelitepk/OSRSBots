package tasks.tutorial;

import antiban.AdvancedAntibanManager;
import framework.Task;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.methods.settings.PlayerSettings;

import java.awt.Point;
import java.awt.Rectangle;

/**
 * Base class for Tutorial Island tasks with anti-ban integration
 */
public abstract class TutorialIslandAntibanTask extends Task {
    
    private static final int TUTORIAL_ISLAND_PROGRESS_VAR = 281;
    
    protected final AdvancedAntibanManager antibanManager;
    
    public TutorialIslandAntibanTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }
    
    @Override
    public int getPriority() {
        return 0; // Default priority, can be overridden
    }
    
    /**
     * Handle dialogue with standard interaction
     */
    @Override
    protected void handleDialogue() {
        // Basic dialogue handling, can be overridden
        if (antibanManager != null) {
            antibanManager.sleep(600, 1200);
        }
    }
    
    /**
     * Click on an NPC with anti-ban integration
     */
    protected boolean clickNPC(NPC npc, String action) {
        if (npc != null && npc.hasAction(action)) {
            return npc.interact(action);
        }
        return false;
    }
    
    /**
     * Click on a GameObject with anti-ban integration
     */
    protected boolean clickGameObject(GameObject obj, String action) {
        if (obj != null && obj.hasAction(action)) {
            return obj.interact(action);
        }
        return false;
    }
    
    /**
     * Walk to a specific tile with anti-ban integration
     */
    protected void walkToTile(Tile tile) {
        if (tile != null) {
            Walking.walk(tile);
            Sleep.sleep(600, 1200);
        }
    }
    
    /**
     * Walk to an NPC with anti-ban integration
     */
    protected void walkToNPC(NPC npc) {
        if (npc != null) {
            Walking.walk(npc);
            Sleep.sleep(600, 1200);
        }
    }
    
    /**
     * Perform random anti-ban actions
     */
    protected void performRandomAntiBan() {
        antibanManager.performRandomAction();
    }
    
    /**
     * Get current progress from varbit 281
     */
    @Override
    protected int getProgress() {
        return PlayerSettings.getBitValue(TUTORIAL_ISLAND_PROGRESS_VAR);
    }
    
    /**
     * Check if task is completed
     */
    protected boolean isCompleted() {
        return getProgress() > 1000; // Tutorial Island complete
    }
    
    /**
     * Set task as completed
     */
    protected void setCompleted(boolean completed) {
        // This can be overridden by subclasses if needed
    }
    
    /**
     * Get heatmap biased click point
     */
    protected Point getHeatmapBiasedClick(Rectangle area) {
        return antibanManager.getHeatmapBiasedClick(area);
    }
    
    /**
     * Execute human-like click
     */
    protected void executeHumanClick(Point target) {
        antibanManager.executeHumanClick(target);
    }
} 