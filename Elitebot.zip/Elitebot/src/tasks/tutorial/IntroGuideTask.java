package tasks.tutorial;

import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.widgets.WidgetChild;

import antiban.AdvancedAntibanManager;

public class IntroGuideTask extends TutorialIslandAntibanTask {

    private static final String GUIDE_NAME = "Gielinor Guide";
    private static final String DOOR_OBJECT_NAME = "Door";

    private final AdvancedAntibanManager antibanManager;

    public IntroGuideTask(AdvancedAntibanManager antibanManager) {
        super(antibanManager);
        this.antibanManager = antibanManager;
    }

    @Override
    public boolean canExecute() {
        return getProgress() >= 2 && getProgress() <= 3;
    }

    @Override
    public int execute() {
        if (antibanManager != null) {
            antibanManager.tick();
        }
        
        NPC guide = NPCs.closest("Gielinor Guide");
        if (guide != null) {
            guide.interact("Talk-to");
            if (antibanManager != null) {
                antibanManager.sleep(1000, 2000);
            }
        }
        
        if (antibanManager != null) {
            return antibanManager.sleepShort();
        }
        return 600;
    }

    @Override
    public String getTaskName() {
        return "Intro Guide";
    }

    private void talkToGuide() {
        NPC guide = NPCs.closest(GUIDE_NAME);
        if (guide != null && guide.canReach()) {
            if (guide.interact("Talk-to")) {
                Sleep.sleepUntil(Dialogues::inDialogue, 3000);
            }
        } else {
            Logger.log("Could not find Gielinor Guide.");
            // Consider walking closer if guide is not found but should be there.
        }
    }

    private void openSettingsTab() {
        Logger.log("Opening settings tab as requested by guide.");
        if (Tabs.open(Tab.OPTIONS)) {
            Sleep.sleep(600, 1200);
            // The dialogue with the guide should continue automatically after this.
            // If not, the talkToGuide will be triggered on the next tick by progress 7.
        }
    }
    
    @Override
    protected void handleDialogue() {
        if (Dialogues.canContinue()) {
            Dialogues.continueDialogue();
            Sleep.sleep(600, 900);
        } else if (Dialogues.getOptions() != null) {
            // Just select the first option for simplicity in tutorial.
            Dialogues.chooseOption(1);
            Sleep.sleep(600, 900);
        }
    }

    @Override
    protected int getProgress() {
        return PlayerSettings.getBitValue(281);
    }
}