package elitecore;

import org.dreambot.api.utilities.Logger;
import org.dreambot.api.methods.MethodProvider;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;

public class OSRSPriceAPI {
    
    private final Random random = ThreadLocalRandom.current();
    private final ExecutorService executorService = Executors.newCachedThreadPool();
    
    // API endpoints
    private static final String OSRS_WIKI_API = "https://prices.runescape.wiki/api/v1/osrs";
    private static final String LATEST_PRICES = "/latest";
    private static final String MAPPING_DATA = "/mapping";
    private static final String TIMESERIES = "/timeseries";
    
    // Data storage
    private final Map<Integer, ItemPrice> itemPrices = new ConcurrentHashMap<>();
    private final Map<String, ItemMapping> itemMappings = new ConcurrentHashMap<>();
    private final Map<Integer, PriceHistory> priceHistory = new ConcurrentHashMap<>();
    private final Map<String, Integer> nameToId = new ConcurrentHashMap<>();
    
    // Cache management
    private final Map<Integer, Long> lastUpdateTime = new ConcurrentHashMap<>();
    private final Map<Integer, Double> priceAlerts = new ConcurrentHashMap<>();
    private final Set<Integer> watchedItems = new HashSet<>();
    
    // State tracking
    private boolean autoUpdateEnabled = true;
    private long lastFullUpdate;
    private int totalItemsTracked;
    private int totalPriceUpdates;
    private double averageUpdateTime;
    
    // Configuration
    private static final long CACHE_DURATION = 300000; // 5 minutes
    private static final long FULL_UPDATE_INTERVAL = 600000; // 10 minutes
    private static final int MAX_RETRIES = 3;
    private static final long RETRY_DELAY = 5000; // 5 seconds
    
    public OSRSPriceAPI() {
        initializePriceAPI();
        startAutoUpdate();
        Logger.log("OSRS Price API initialized");
    }
    
    private void initializePriceAPI() {
        // Initialize with common items
        CompletableFuture.runAsync(() -> {
            try {
                fetchLatestPrices();
                fetchItemMappings();
                Logger.log("Initial price data loaded");
            } catch (Exception e) {
                Logger.log("Error initializing price API: " + e.getMessage());
            }
        }, executorService);
    }
    
    public CompletableFuture<Map<Integer, ItemPrice>> fetchLatestPrices() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String url = OSRS_WIKI_API + LATEST_PRICES;
                String response = makeHttpRequest(url);
                
                if (response != null) {
                    return parseLatestPrices(response);
                }
            } catch (Exception e) {
                Logger.log("Error fetching latest prices: " + e.getMessage());
            }
            return new HashMap<>();
        }, executorService);
    }
    
    public CompletableFuture<Map<String, ItemMapping>> fetchItemMappings() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String url = OSRS_WIKI_API + MAPPING_DATA;
                String response = makeHttpRequest(url);
                
                if (response != null) {
                    return parseItemMappings(response);
                }
            } catch (Exception e) {
                Logger.log("Error fetching item mappings: " + e.getMessage());
            }
            return new HashMap<>();
        }, executorService);
    }
    
    private String makeHttpRequest(String urlString) {
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("User-Agent", "EliteBot/1.0");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                
                int responseCode = connection.getResponseCode();
                if (responseCode == 200) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    
                    return response.toString();
                } else {
                    Logger.log("HTTP request failed with code: " + responseCode);
                }
            } catch (Exception e) {
                Logger.log("HTTP request attempt " + attempt + " failed: " + e.getMessage());
                if (attempt < MAX_RETRIES) {
                    try {
                        Thread.sleep(RETRY_DELAY);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }
        return null;
    }
    
    private Map<Integer, ItemPrice> parseLatestPrices(String jsonResponse) {
        Map<Integer, ItemPrice> prices = new HashMap<>();
        
        try {
            // Simple JSON parsing (in production, use a proper JSON library)
            // This is a simplified version - you'd want to use Gson or Jackson
            
            // Extract price data from JSON
            String[] lines = jsonResponse.split("\n");
            for (String line : lines) {
                if (line.contains("\"id\":") && line.contains("\"high\":")) {
                    // Parse item price data
                    // This is a simplified parser - implement proper JSON parsing
                    ItemPrice price = parseItemPriceFromLine(line);
                    if (price != null) {
                        prices.put(price.getItemId(), price);
                        itemPrices.put(price.getItemId(), price);
                        lastUpdateTime.put(price.getItemId(), System.currentTimeMillis());
                    }
                }
            }
            
            totalPriceUpdates += prices.size();
            Logger.log("Parsed " + prices.size() + " item prices");
            
        } catch (Exception e) {
            Logger.log("Error parsing price data: " + e.getMessage());
        }
        
        return prices;
    }
    
    private ItemPrice parseItemPriceFromLine(String line) {
        try {
            // Simplified parsing - implement proper JSON parsing
            // Extract item ID, high price, low price, etc.
            
            // This is a placeholder - implement actual JSON parsing
            int itemId = extractIntValue(line, "id");
            int highPrice = extractIntValue(line, "high");
            int lowPrice = extractIntValue(line, "low");
            long timestamp = extractLongValue(line, "timestamp");
            
            if (itemId > 0) {
                return new ItemPrice(itemId, highPrice, lowPrice, timestamp);
            }
        } catch (Exception e) {
            Logger.log("Error parsing item price line: " + e.getMessage());
        }
        return null;
    }
    
    private int extractIntValue(String line, String key) {
        try {
            String pattern = "\"" + key + "\":\\s*(\\d+)";
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(line);
            if (m.find()) {
                return Integer.parseInt(m.group(1));
            }
        } catch (Exception e) {
            // Ignore parsing errors
        }
        return 0;
    }
    
    private long extractLongValue(String line, String key) {
        try {
            String pattern = "\"" + key + "\":\\s*(\\d+)";
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(line);
            if (m.find()) {
                return Long.parseLong(m.group(1));
            }
        } catch (Exception e) {
            // Ignore parsing errors
        }
        return 0;
    }
    
    private Map<String, ItemMapping> parseItemMappings(String jsonResponse) {
        Map<String, ItemMapping> mappings = new HashMap<>();
        
        try {
            // Parse item mapping data
            String[] lines = jsonResponse.split("\n");
            for (String line : lines) {
                if (line.contains("\"id\":") && line.contains("\"name\":")) {
                    ItemMapping mapping = parseItemMappingFromLine(line);
                    if (mapping != null) {
                        mappings.put(mapping.getName(), mapping);
                        itemMappings.put(mapping.getName(), mapping);
                        nameToId.put(mapping.getName().toLowerCase(), mapping.getId());
                    }
                }
            }
            
            totalItemsTracked = mappings.size();
            Logger.log("Parsed " + mappings.size() + " item mappings");
            
        } catch (Exception e) {
            Logger.log("Error parsing item mappings: " + e.getMessage());
        }
        
        return mappings;
    }
    
    private ItemMapping parseItemMappingFromLine(String line) {
        try {
            // Simplified parsing - implement proper JSON parsing
            int id = extractIntValue(line, "id");
            String name = extractStringValue(line, "name");
            boolean members = extractBooleanValue(line, "members");
            
            if (id > 0 && name != null) {
                return new ItemMapping(id, name, members);
            }
        } catch (Exception e) {
            Logger.log("Error parsing item mapping line: " + e.getMessage());
        }
        return null;
    }
    
    private String extractStringValue(String line, String key) {
        try {
            String pattern = "\"" + key + "\":\\s*\"([^\"]+)\"";
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(line);
            if (m.find()) {
                return m.group(1);
            }
        } catch (Exception e) {
            // Ignore parsing errors
        }
        return null;
    }
    
    private boolean extractBooleanValue(String line, String key) {
        try {
            String pattern = "\"" + key + "\":\\s*(true|false)";
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(line);
            if (m.find()) {
                return Boolean.parseBoolean(m.group(1));
            }
        } catch (Exception e) {
            // Ignore parsing errors
        }
        return false;
    }
    
    private void startAutoUpdate() {
        CompletableFuture.runAsync(() -> {
            while (autoUpdateEnabled) {
                try {
                    long currentTime = System.currentTimeMillis();
                    
                    // Full update every 10 minutes
                    if (currentTime - lastFullUpdate > FULL_UPDATE_INTERVAL) {
                        fetchLatestPrices();
                        fetchItemMappings();
                        lastFullUpdate = currentTime;
                        Logger.log("Performed full price update");
                    }
                    
                    // Update watched items more frequently
                    updateWatchedItems();
                    
                    try {
                        Thread.sleep(60000); // Check every minute
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                } catch (Exception e) {
                    Logger.log("Error in auto update: " + e.getMessage());
                }
            }
        }, executorService);
    }
    
    private void updateWatchedItems() {
        for (Integer itemId : watchedItems) {
            long lastUpdate = lastUpdateTime.getOrDefault(itemId, 0L);
            if (System.currentTimeMillis() - lastUpdate > CACHE_DURATION) {
                updateItemPrice(itemId);
            }
        }
    }
    
    private void updateItemPrice(int itemId) {
        CompletableFuture.runAsync(() -> {
            try {
                // Fetch specific item price
                String url = OSRS_WIKI_API + LATEST_PRICES + "?id=" + itemId;
                String response = makeHttpRequest(url);
                
                if (response != null) {
                    Map<Integer, ItemPrice> prices = parseLatestPrices(response);
                    if (prices.containsKey(itemId)) {
                        ItemPrice price = prices.get(itemId);
                        checkPriceAlerts(itemId, price);
                    }
                }
            } catch (Exception e) {
                Logger.log("Error updating item price: " + e.getMessage());
            }
        }, executorService);
    }
    
    private void checkPriceAlerts(int itemId, ItemPrice price) {
        Double alertPrice = priceAlerts.get(itemId);
        if (alertPrice != null) {
            if (price.getHighPrice() >= alertPrice || price.getLowPrice() <= alertPrice) {
                Logger.log("Price alert for item " + itemId + ": " + price.getHighPrice() + "/" + price.getLowPrice());
                // Trigger alert action
            }
        }
    }
    
    // Public API methods
    
    public ItemPrice getItemPrice(int itemId) {
        return itemPrices.get(itemId);
    }
    
    public ItemPrice getItemPrice(String itemName) {
        Integer itemId = nameToId.get(itemName.toLowerCase());
        if (itemId != null) {
            return getItemPrice(itemId);
        }
        return null;
    }
    
    public void watchItem(int itemId) {
        watchedItems.add(itemId);
        Logger.log("Now watching item: " + itemId);
    }
    
    public void watchItem(String itemName) {
        Integer itemId = nameToId.get(itemName.toLowerCase());
        if (itemId != null) {
            watchItem(itemId);
        }
    }
    
    public void setPriceAlert(int itemId, double price) {
        priceAlerts.put(itemId, price);
        Logger.log("Set price alert for item " + itemId + " at " + price);
    }
    
    public void setPriceAlert(String itemName, double price) {
        Integer itemId = nameToId.get(itemName.toLowerCase());
        if (itemId != null) {
            setPriceAlert(itemId, price);
        }
    }
    
    public List<ItemPrice> getTopGainers(int count) {
        return itemPrices.values().stream()
            .sorted((a, b) -> Double.compare(b.getPriceChange(), a.getPriceChange()))
            .limit(count)
            .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }
    
    public List<ItemPrice> getTopLosers(int count) {
        return itemPrices.values().stream()
            .sorted((a, b) -> Double.compare(a.getPriceChange(), b.getPriceChange()))
            .limit(count)
            .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }
    
    public Map<String, Object> getMarketStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalItems", totalItemsTracked);
        stats.put("totalUpdates", totalPriceUpdates);
        stats.put("lastUpdate", lastFullUpdate);
        stats.put("watchedItems", watchedItems.size());
        stats.put("averageUpdateTime", averageUpdateTime);
        return stats;
    }
    
    // Configuration methods
    
    public void setAutoUpdateEnabled(boolean enabled) {
        this.autoUpdateEnabled = enabled;
        Logger.log("Auto update " + (enabled ? "enabled" : "disabled"));
    }
    
    public boolean isAutoUpdateEnabled() {
        return autoUpdateEnabled;
    }
    
    // Inner classes
    
    public static class ItemPrice {
        private final int itemId;
        private final int highPrice;
        private final int lowPrice;
        private final long timestamp;
        private final double priceChange;
        
        public ItemPrice(int itemId, int highPrice, int lowPrice, long timestamp) {
            this.itemId = itemId;
            this.highPrice = highPrice;
            this.lowPrice = lowPrice;
            this.timestamp = timestamp;
            this.priceChange = calculatePriceChange();
        }
        
        private double calculatePriceChange() {
            // Calculate price change percentage
            if (highPrice > 0 && lowPrice > 0) {
                return ((double) (highPrice - lowPrice) / lowPrice) * 100;
            }
            return 0.0;
        }
        
        // Getters
        public int getItemId() { return itemId; }
        public int getHighPrice() { return highPrice; }
        public int getLowPrice() { return lowPrice; }
        public long getTimestamp() { return timestamp; }
        public double getPriceChange() { return priceChange; }
        public int getAveragePrice() { return (highPrice + lowPrice) / 2; }
    }
    
    public static class ItemMapping {
        private final int id;
        private final String name;
        private final boolean members;
        
        public ItemMapping(int id, String name, boolean members) {
            this.id = id;
            this.name = name;
            this.members = members;
        }
        
        // Getters
        public int getId() { return id; }
        public String getName() { return name; }
        public boolean isMembers() { return members; }
    }
    
    public static class PriceHistory {
        private final List<ItemPrice> prices;
        private final long startTime;
        
        public PriceHistory() {
            this.prices = new ArrayList<>();
            this.startTime = System.currentTimeMillis();
        }
        
        public void addPrice(ItemPrice price) {
            prices.add(price);
        }
        
        // Getters
        public List<ItemPrice> getPrices() { return new ArrayList<>(prices); }
        public long getStartTime() { return startTime; }
    }
} 