package elitecore;

import org.dreambot.api.utilities.Timer;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;

public class PaintOverlay {

    private boolean showOverlay = true;
    private final Timer runtime;
    private String currentTask = "Initializing...";
    private String antiBanStatus = "Monitoring...";
    private double progressPercent = 0;

    // --- Style & Color ---
    private final Font titleFont = new Font("Verdana", Font.BOLD, 12);
    private final Font textFont = new Font("Verdana", Font.PLAIN, 10);
    private final Color backgroundColor = new Color(0, 0, 0, 150);
    private final Color borderColor = new Color(70, 130, 180, 200); // SteelBlue
    private final Color textColor = Color.WHITE;
    private final Color valueColor = new Color(255, 179, 0); // Orange
    private final Color progressBarBg = new Color(80, 80, 80, 180);
    private final Color progressBarFill = new Color(28, 168, 26, 220);

    // --- Layout ---
    private final Rectangle paintArea = new Rectangle(5, 5, 250, 130);
    private final Rectangle hideShowButtonArea;

    public PaintOverlay() {
        this.runtime = new Timer();
        this.hideShowButtonArea = new Rectangle(paintArea.x + paintArea.width - 60, paintArea.y + 5, 55, 20);
    }
    
    public void handleMouseClick(MouseEvent e) {
        if (hideShowButtonArea.contains(e.getPoint())) {
            showOverlay = !showOverlay;
            e.consume();
        }
    }
    
    public void setTask(String task) { this.currentTask = task; }
    public void setAntiBanStatus(String status) { this.antiBanStatus = status; }
    public void setProgress(double percent) { this.progressPercent = percent; }

    public void onPaint(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // --- Draw Hide/Show Button ---
        g2d.setColor(backgroundColor);
        g2d.fillRoundRect(hideShowButtonArea.x, hideShowButtonArea.y, hideShowButtonArea.width, hideShowButtonArea.height, 5, 5);
        g2d.setColor(borderColor);
        g2d.drawRoundRect(hideShowButtonArea.x, hideShowButtonArea.y, hideShowButtonArea.width, hideShowButtonArea.height, 5, 5);
        g2d.setColor(textColor);
        g2d.setFont(textFont);
        String buttonText = showOverlay ? "Hide" : "Show";
        g2d.drawString(buttonText, hideShowButtonArea.x + 15, hideShowButtonArea.y + 15);

        if (!showOverlay) {
            return; // Don't draw the rest of the paint
        }

        // --- Draw Main Panel ---
        g2d.setColor(backgroundColor);
        g2d.fillRoundRect(paintArea.x, paintArea.y, paintArea.width, paintArea.height, 10, 10);
        g2d.setColor(borderColor);
        g2d.drawRoundRect(paintArea.x, paintArea.y, paintArea.width, paintArea.height, 10, 10);
        
        // --- Draw Title ---
        g2d.setFont(titleFont);
        g2d.setColor(textColor);
        g2d.drawString("EliteBot - Tutorial", paintArea.x + 10, paintArea.y + 20);
        g2d.drawLine(paintArea.x + 5, paintArea.y + 28, paintArea.x + paintArea.width - 5, paintArea.y + 28);

        // --- Draw Information ---
        g2d.setFont(textFont);
        int yPos = paintArea.y + 45;
        drawInfoLine(g2d, "Runtime:", runtime.formatTime(), yPos);
        drawInfoLine(g2d, "Task:", currentTask, yPos + 20);
        drawInfoLine(g2d, "Anti-Ban:", antiBanStatus, yPos + 40);

        // --- Draw Progress Bar ---
        int barX = paintArea.x + 10;
        int barY = yPos + 60;
        int barWidth = paintArea.width - 20;
        int barHeight = 15;

        // Background
        g2d.setColor(progressBarBg);
        g2d.fillRoundRect(barX, barY, barWidth, barHeight, 5, 5);

        // Fill
        g2d.setColor(progressBarFill);
        g2d.fillRoundRect(barX, barY, (int)(barWidth * (progressPercent / 100.0)), barHeight, 5, 5);

        // Border
        g2d.setColor(borderColor);
        g2d.drawRoundRect(barX, barY, barWidth, barHeight, 5, 5);

        // Percentage Text
        String progressText = String.format("%.1f%%", progressPercent);
        g2d.setColor(textColor);
        g2d.drawString(progressText, barX + barWidth / 2 - 15, barY + 12);
    }
    
    private void drawInfoLine(Graphics2D g, String label, String value, int y) {
        g.setColor(textColor);
        g.drawString(label, paintArea.x + 15, y);
        g.setColor(valueColor);
        g.drawString(value, paintArea.x + 85, y);
    }
} 