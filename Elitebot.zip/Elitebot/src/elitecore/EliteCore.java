package elitecore;

import org.dreambot.api.Client;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;

import antiban.AdvancedAntibanManager;
import antiban.ChatGPTPersonalityEngine;
import antiban.ChatMonitor;
import antiban.UUIDProfileCache;
import tasks.tutorial.TutorialTaskHandler;
import framework.Task;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import org.dreambot.api.methods.interactive.Players;

/**
 * EliteBot - Complete Tutorial Island Automation
 * Advanced OSRS Tutorial Island bot with comprehensive anti-ban, auto-save, and behavioral modeling
 */
@ScriptManifest(
    name = "EliteBot - Tutorial Island",
    description = "Complete Tutorial Island automation with advanced anti-ban, auto-save, and human-like behavior. Features all tutorial tasks with seamless progress resumption.",
    author = "EliteBot Team",
    version = 2.0,
    category = Category.MISC
)
public class EliteCore extends AbstractScript implements MouseListener {

    private PaintOverlay paintOverlay;
    private boolean initialized = false;
    private UUIDProfileCache profileCache;
    private AdvancedAntibanManager antibanManager;
    private TutorialTaskHandler tutorialHandler;
    private ChatMonitor chatMonitor;
    
    private long scriptStartTime;
    private String currentUsername;

    @Override
    public void onStart() {
        if (!initialized) {
            profileCache = new UUIDProfileCache();
            antibanManager = new AdvancedAntibanManager(this, profileCache);
            tutorialHandler = new TutorialTaskHandler(antibanManager);
            chatMonitor = new ChatMonitor(new ChatGPTPersonalityEngine(), profileCache);
            paintOverlay = new PaintOverlay();
            
            tutorialHandler.initialize(profileCache);
            
            initialized = true;
        }
        Logger.log("EliteBot Started!");
        scriptStartTime = System.currentTimeMillis();
        
        // Get player name and initialize profile
        currentUsername = Players.getLocal().getName();
        if (currentUsername == null || currentUsername.isEmpty()) {
            Logger.log("[ERROR] Could not get player name!");
            stop();
            return;
        }
        
        profileCache = UUIDProfileCache.loadOrCreate(currentUsername);
        Logger.log("EliteBot profile loaded for: " + currentUsername);
        
        Logger.log("[EliteCore] Auto-save: " + profileCache.isAutoSaveEnabled());
        Logger.log("[EliteCore] Personality: " + profileCache.getCurrentPersonality());
        
        showWelcomeMessage();
    }

    @Override
    public int onLoop() {
        if (!initialized || tutorialHandler == null) {
            Logger.log("Still initializing...");
            return 1000;
        }
        
        int sleepTime = tutorialHandler.execute();
        
        // chatMonitor.checkChat();

        // Update paint with the latest info
        if (paintOverlay != null && tutorialHandler.getCurrentTask() != null) {
            paintOverlay.setTask(tutorialHandler.getCurrentTask().getTaskName());
            paintOverlay.setProgress(tutorialHandler.getProgressPercentage());
            paintOverlay.setAntiBanStatus("Surveillance level " + antibanManager.getSurveillanceLevel());
        }

        if (sleepTime == -1) {
            Logger.log("All tasks completed or script is stopping.");
            return -1;
        }
        
        return sleepTime;
    }

    @Override
    public void onExit() {
        // If you have a saveProgress method, you can call it here.
        // if (tutorialHandler != null) {
        //     tutorialHandler.saveProgress();
        // }
        Logger.log("EliteBot Stopped!");
        
        // Save final progress
        if (profileCache != null) {
            profileCache.forceSave();
            Logger.log("[EliteCore] Final progress saved.");
        }
        
        // Log session statistics
        long sessionTime = System.currentTimeMillis() - scriptStartTime;
        Logger.log("[EliteCore] Session duration: " + formatTime(sessionTime));
    }

    @Override
    public void onPaint(Graphics g) {
        if (paintOverlay != null) {
            paintOverlay.onPaint(g);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (paintOverlay != null) {
            paintOverlay.handleMouseClick(e);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        // Not used
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // Not used
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // Not used
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // Not used
    }

    /**
     * Show welcome message based on personality
     */
    private void showWelcomeMessage() {
        // This is now silent to reduce log spam. Can be re-enabled for debugging.
    }

    /**
     * Format time duration
     */
    private String formatTime(long milliseconds) {
        long seconds = milliseconds / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        
        if (hours > 0) {
            return String.format("%dh %dm %ds", hours, minutes % 60, seconds % 60);
        } else if (minutes > 0) {
            return String.format("%dm %ds", minutes, seconds % 60);
        } else {
            return String.format("%ds", seconds);
        }
    }

    // Getter methods for components
    public AdvancedAntibanManager getAntibanManager() { return antibanManager; }
    public TutorialTaskHandler getTutorialHandler() { return tutorialHandler; }
    public UUIDProfileCache getProfileCache() { return profileCache; }
    public ChatMonitor getChatMonitor() { return chatMonitor; }
    public long getScriptStartTime() { return scriptStartTime; }
    public String getCurrentUsername() { return currentUsername; }
}