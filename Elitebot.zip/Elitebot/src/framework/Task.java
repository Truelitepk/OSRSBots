package framework;

import antiban.AdvancedAntibanManager;

public abstract class Task {
    protected final AdvancedAntibanManager antibanManager;

    public Task(AdvancedAntibanManager antibanManager) {
        this.antibanManager = antibanManager;
    }

    public abstract boolean canExecute();
    public abstract int execute();
    public abstract String getTaskName();
    public abstract int getPriority();
    
    // Core methods that all tasks need
    protected abstract int getProgress();
    protected abstract void handleDialogue();
    
    // Additional methods that some tasks use
    public boolean accept() {
        return canExecute();
    }
    
    public String getName() {
        return getTaskName();
    }
}
