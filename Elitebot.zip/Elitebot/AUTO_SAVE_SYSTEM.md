# EliteBot Auto-Save System Documentation

## Overview

The EliteBot Auto-Save System provides comprehensive progress tracking and seamless resumption capabilities for Tutorial Island automation. Each account maintains its own persistent profile that evolves over time, ensuring that progress is never lost and personality development continues across sessions.

## Key Features

### 🔄 **Automatic Progress Persistence**
- **Auto-save every 30 seconds** during active gameplay
- **Immediate save** when switching between tutorial tasks
- **Force save** on script shutdown and critical events
- **Session tracking** with total time accumulation across multiple runs

### 👤 **Per-Account Profile System**
- **Unique profile per username** stored in `elitebot_profiles/` directory
- **Personality persistence** - each account maintains its evolving personality
- **Behavioral consistency tracking** - scores how well the bot maintains its personality
- **Evolution stages** - tracks personality development over time

### 📊 **Comprehensive Progress Tracking**
- **Tutorial progress** - exact stage in Tutorial Island (0-11)
- **Session statistics** - total time, last activity, behavioral scores
- **Personality evolution** - how the bot's personality has developed
- **Profile age** - how long the profile has been active

### 🎯 **Seamless Resumption**
- **Automatic detection** of existing profiles on script start
- **Progress restoration** - resumes from exact tutorial stage
- **Personality continuity** - maintains evolved personality traits
- **Session continuation** - adds to total session time

## Technical Implementation

### Profile Storage Structure
```
elitebot_profiles/
├── username1.properties
├── username2.properties
└── username3.properties
```

### Profile Data Fields
```properties
# Tutorial Progress
tutorial_progress=5

# Session Tracking
session_start_time=1703123456789
total_session_time=1800000
last_activity_time=1703125256789

# Personality & Behavior
personalityType=casual_player
behavioral_consistency_score=0.85
personality_evolution_stage=2

# Anti-Ban Settings
reactionMin=80
reactionMax=220
misclickChance=15
afkTendency=3000
cameraActivity=2000
```

### Auto-Save Triggers
1. **Periodic Auto-Save** - Every 30 seconds during active gameplay
2. **Task Transition** - Immediately when switching tutorial tasks
3. **Script Shutdown** - Force save before exit
4. **Manual Trigger** - Available through API for testing

## Usage Examples

### Starting a New Account
```java
// Profile automatically created on first run
UUIDProfileCache profile = UUIDProfileCache.loadOrCreate("newplayer123");
// Profile starts with randomized personality and progress = 0
```

### Resuming an Existing Account
```java
// Profile automatically loaded with saved progress
UUIDProfileCache profile = UUIDProfileCache.loadOrCreate("existingplayer456");
int savedProgress = profile.getTutorialProgress(); // Returns saved stage
String personality = profile.getCurrentPersonality(); // Returns evolved personality
```

### Monitoring Progress
```java
// Get comprehensive progress information
UUIDProfileCache.ProfileStatistics stats = profile.getStatistics();
System.out.println("Progress: " + stats.tutorialProgress + "/11");
System.out.println("Personality: " + stats.personality);
System.out.println("Total Time: " + stats.totalSessionTime + "ms");
```

## Personality Evolution System

### Available Personalities
- `casual_player` - Relaxed, takes time to explore
- `efficient_player` - Fast, goal-oriented
- `newbie` - Learning, asks questions
- `veteran` - Experienced, confident
- `social_player` - Friendly, interacts with others
- `lone_wolf` - Independent, prefers solitude
- `helpful_player` - Assists other players
- `pker` - Combat-focused
- `pvmer` - PvM specialist
- `skiller` - Skill-focused
- `quest_hunter` - Quest completionist
- `clan_member` - Team-oriented
- `ironman` - Self-sufficient
- `hardcore_ironman` - Risk-taking
- `merchant` - Economy-focused
- `minigame_player` - Minigame enthusiast
- `achievement_hunter` - Achievement-focused
- `competitive_player` - Performance-driven
- `chill_player` - Relaxed, no rush
- `roleplayer` - Character immersion
- `speedrunner` - Speed optimization
- `collector` - Item collection
- `explorer` - Discovery-focused
- `builder` - Construction-focused
- `farmer` - Farming specialist

### Evolution Stages
1. **Stage 0** - Fresh profile, basic personality
2. **Stage 1** - Tutorial completed, personality developing
3. **Stage 2** - Multiple sessions, personality maturing
4. **Stage 3+** - Experienced profile, fully evolved personality

## GUI Integration

### Auto-Save Status Display
- **Enabled/Disabled indicator** with color coding
- **Last save time** showing when profile was last updated
- **Save frequency** indicating if auto-save is due
- **Profile statistics** showing personality and progress

### Progress Visualization
- **Progress bar** showing tutorial completion percentage
- **Current task** display with human-readable names
- **Session time** tracking current and total runtime
- **Profile age** showing how long the profile has existed

## Anti-Ban Integration

### Behavioral Consistency
- **Personality-driven actions** based on saved profile
- **Consistent timing patterns** maintained across sessions
- **Evolving behavior** that adapts over time
- **Detection evasion** through personality-based randomization

### Mouse Heatmap Persistence
- **Click patterns** saved and restored across sessions
- **Heatmap evolution** based on personality preferences
- **Consistent mouse behavior** for each account

## Error Handling

### Profile Corruption
- **Automatic backup** of profiles before major changes
- **Fallback to defaults** if profile is corrupted
- **Error logging** for debugging profile issues

### Save Failures
- **Retry mechanism** for failed saves
- **Graceful degradation** if auto-save is disabled
- **Manual save options** for critical situations

## Performance Considerations

### Save Frequency
- **30-second intervals** balance data safety with performance
- **Immediate saves** only for critical events
- **Background saving** to avoid blocking main thread

### Storage Efficiency
- **Compressed properties** format for minimal disk usage
- **Cleanup routines** for old/unused profiles
- **Size monitoring** to prevent excessive storage

## Future Enhancements

### Planned Features
- **Cloud synchronization** for profile backup
- **Profile migration** between accounts
- **Advanced analytics** for personality development
- **Cross-script compatibility** for other bot scripts

### Advanced Tracking
- **Skill progression** tracking across sessions
- **Quest completion** history
- **Achievement tracking** and personality adaptation
- **Social interaction** history and evolution

## Configuration Options

### Auto-Save Settings
```java
// Enable/disable auto-save
profileCache.setAutoSaveEnabled(true);

// Set custom save interval (in milliseconds)
profileCache.setAutoSaveInterval(45000); // 45 seconds

// Force immediate save
profileCache.forceSave();
```

### Profile Management
```java
// Reset progress (for testing)
tutorialHandler.resetProgress();

// Skip to specific task
tutorialHandler.skipToTask(5);

// Get detailed progress info
TutorialTaskHandler.ProgressInfo info = tutorialHandler.getProgressInfo();
```

## Best Practices

### Profile Management
1. **Never delete profiles** unless absolutely necessary
2. **Backup profiles** before major updates
3. **Monitor profile size** to prevent storage issues
4. **Use unique usernames** for each account

### Auto-Save Usage
1. **Keep auto-save enabled** for production use
2. **Monitor save frequency** for performance impact
3. **Test profile restoration** after updates
4. **Validate profile integrity** periodically

### Development
1. **Test with fresh profiles** for new features
2. **Validate profile compatibility** across versions
3. **Log profile operations** for debugging
4. **Handle profile errors** gracefully

## Troubleshooting

### Common Issues
- **Profile not loading** - Check file permissions and path
- **Progress not saving** - Verify auto-save is enabled
- **Personality not evolving** - Check evolution stage logic
- **Save failures** - Monitor disk space and permissions

### Debug Commands
```java
// Check profile status
UUIDProfileCache.ProfileStatistics stats = profile.getStatistics();
System.out.println(stats.toString());

// Force save and verify
profile.forceSave();
System.out.println("Profile saved: " + profile.getTutorialProgress());

// Reset for testing
tutorialHandler.resetProgress();
```

This auto-save system ensures that EliteBot provides a seamless, persistent experience that evolves with each account, making it the most advanced Tutorial Island bot available. 