import namegen.VeteranNameGenerator;
import namegen.VeteranNameGenerator.PersonalityType;

public class NameGeneratorDemo {
    public static void main(String[] args) {
        System.out.println("=== Personality-Based Name Generator Demo ===\n");
        
        PersonalityType[] types = {
            PersonalityType.EFFICIENT, PersonalityType.CHILL, PersonalityType.VETERAN,
            PersonalityType.NEWBIE, PersonalityType.CASUAL, PersonalityType.PKER,
            PersonalityType.PVMER, PersonalityType.SKILLER, PersonalityType.IRONMAN
        };
        
        for (PersonalityType type : types) {
            System.out.println(type.name() + " Names:");
            for (int i = 0; i < 5; i++) {
                String name = VeteranNameGenerator.generate(type);
                System.out.println("  " + name);
            }
            System.out.println();
        }
        
        System.out.println("Random Personality Names:");
        for (int i = 0; i < 10; i++) {
            String name = VeteranNameGenerator.generate();
            System.out.println("  " + name);
        }
    }
} 